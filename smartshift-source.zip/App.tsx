import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  CalendarDays, 
  Receipt, 
  Settings, 
  Menu, 
  ArrowLeft, 
  Printer, 
  X,
  ShieldCheck,
  Sparkles,
  Plus,
  Trash2,
  Clock,
  Sun,
  Moon
} from 'lucide-react';
import { UserData, Language, ShiftType, SalaryBreakdown, ThemeMode } from './types';
import { loadUserData, saveUserData } from './services/storage';
import { calculatePayroll } from './services/payrollEngine';
import { translations, TranslationKey } from './translations';
import { applyTheme, getSystemTheme } from './utils/themeUtils';
import YazakiLogo from './components/YazakiLogo';
import Dashboard from './components/Dashboard';
import WeeklyPlanning from './components/WeeklyPlanning';
import Calendar from './components/Calendar';
import EarningsDetails from './components/EarningsDetails';
import SettingsView from './components/SettingsView';
import NavigationDrawer from './components/NavigationDrawer';
import PayrollReport from './components/PayrollReport';
import SplashScreen from './components/SplashScreen';

type AppTab = 'home' | 'calendar' | 'payroll' | 'settings';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [calendarViewMode, setCalendarViewMode] = useState<'weekly' | 'monthly'>('weekly');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  
  // Real-time anchor: Home and Payroll ALWAYS anchor strictly to current month
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  // Current month's primary userData and payroll calculation
  const [userData, setUserData] = useState<UserData>(() => loadUserData(currentYear, currentMonth));
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  // Decoupled planning calendar month state
  const [planningDate, setPlanningDate] = useState<Date>(() => new Date());
  const planningYear = planningDate.getFullYear();
  const planningMonth = planningDate.getMonth();
  const isPlanningCurrentMonth = planningYear === currentYear && planningMonth === currentMonth;

  // Cache/load user data for other months navigated specifically in planning
  const [otherMonthUserData, setOtherMonthUserData] = useState<UserData | null>(null);

  // Print modal configuration (supports both current month and any navigated month in planning)
  const currentPayroll = useMemo(() => calculatePayroll(currentYear, currentMonth, userData), [currentYear, currentMonth, userData]);
  const [printModalConfig, setPrintModalConfig] = useState<{
    isOpen: boolean;
    payroll: SalaryBreakdown;
    userData: UserData;
    month: number;
    year: number;
  }>({
    isOpen: false,
    payroll: currentPayroll,
    userData: userData,
    month: currentMonth,
    year: currentYear
  });

  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang][key] || key;
  const isRTL = translations[lang].dir === 'rtl';

  useEffect(() => {
    const handleViewportChange = () => {
      if (window.visualViewport) {
        const isKeyboardUp = window.visualViewport.height < window.innerHeight * 0.8;
        setIsKeyboardVisible(isKeyboardUp);
      }
    };
    window.visualViewport?.addEventListener('resize', handleViewportChange);
    return () => window.visualViewport?.removeEventListener('resize', handleViewportChange);
  }, []);

  // Save current month user data when updated
  useEffect(() => {
    saveUserData(currentYear, currentMonth, userData);
  }, [userData, currentYear, currentMonth]);

  // Synchronize active theme (light / dark / system) with DOM
  useEffect(() => {
    applyTheme(userData.theme);
  }, [userData.theme]);

  // Listen to system OS dark mode preference when mode is set to 'system'
  useEffect(() => {
    if (userData.theme === 'system') {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme('system');
      mq.addEventListener('change', listener);
      return () => mq.removeEventListener('change', listener);
    }
  }, [userData.theme]);

  // Quick theme toggle handler for the header bar
  const handleToggleTheme = () => {
    const currentTheme = userData.theme || 'light';
    const effectiveIsDark = currentTheme === 'dark' || (currentTheme === 'system' && getSystemTheme() === 'dark');
    const nextTheme: ThemeMode = effectiveIsDark ? 'light' : 'dark';
    setUserData(prev => ({ ...prev, theme: nextTheme }));
  };

  // When viewing another month in Planning, load that specific month's data
  useEffect(() => {
    if (!isPlanningCurrentMonth) {
      setOtherMonthUserData(loadUserData(planningYear, planningMonth));
    } else {
      setOtherMonthUserData(null);
    }
  }, [planningYear, planningMonth, isPlanningCurrentMonth]);

  // If the user navigates away from the planning section, automatically reset planning back to the current month!
  useEffect(() => {
    if (activeTab !== 'calendar') {
      setPlanningDate(new Date());
    }
  }, [activeTab]);

  const toggleDay = (iso: string, category: 'worked' | 'absence', targetYear?: number, targetMonth?: number) => {
    const isTargetingCurrent = targetYear === undefined || (targetYear === currentYear && targetMonth === currentMonth);

    if (isTargetingCurrent) {
      setUserData(prev => {
        const next = { ...prev };
        const d = new Date(iso);
        const isSunday = d.getDay() === 0;

        if (isSunday) {
          next.specialDaysWorked = next.specialDaysWorked.includes(iso) 
            ? next.specialDaysWorked.filter(item => item !== iso) 
            : [...next.specialDaysWorked, iso];
          next.absences = next.absences.filter(item => item !== iso);
        } else {
          if (category === 'worked') {
            next.holidaysWorked = next.holidaysWorked.includes(iso)
              ? next.holidaysWorked.filter(item => item !== iso)
              : [...next.holidaysWorked, iso];
            next.absences = next.absences.filter(item => item !== iso);
          } else {
            next.absences = next.absences.includes(iso)
              ? next.absences.filter(item => item !== iso)
              : [...next.absences, iso];
            next.holidaysWorked = next.holidaysWorked.filter(item => item !== iso);
          }
        }
        return next;
      });
    } else {
      setOtherMonthUserData(prev => {
        const base = prev || loadUserData(targetYear!, targetMonth!);
        const next = { ...base };
        const d = new Date(iso);
        const isSunday = d.getDay() === 0;

        if (isSunday) {
          next.specialDaysWorked = next.specialDaysWorked.includes(iso) 
            ? next.specialDaysWorked.filter(item => item !== iso) 
            : [...next.specialDaysWorked, iso];
          next.absences = next.absences.filter(item => item !== iso);
        } else {
          if (category === 'worked') {
            next.holidaysWorked = next.holidaysWorked.includes(iso)
              ? next.holidaysWorked.filter(item => item !== iso)
              : [...next.holidaysWorked, iso];
            next.absences = next.absences.filter(item => item !== iso);
          } else {
            next.absences = next.absences.includes(iso)
              ? next.absences.filter(item => item !== iso)
              : [...next.absences, iso];
            next.holidaysWorked = next.holidaysWorked.filter(item => item !== iso);
          }
        }
        saveUserData(targetYear!, targetMonth!, next);
        return next;
      });
    }
  };

  const handlePrevPlanningMonth = () => {
    setPlanningDate(new Date(planningYear, planningMonth - 1, 1));
  };

  const handleNextPlanningMonth = () => {
    setPlanningDate(new Date(planningYear, planningMonth + 1, 1));
  };

  const handleResetPlanningMonth = () => {
    setPlanningDate(new Date());
  };

  // Open official print payslip for current month
  const handleOpenCurrentPrint = () => {
    setPrintModalConfig({
      isOpen: true,
      payroll: currentPayroll,
      userData: userData,
      month: currentMonth,
      year: currentYear
    });
  };

  // Open official print payslip for any navigated month in planning
  const handleShowMonthPayroll = (targetYear: number, targetMonth: number) => {
    const dataForMonth = (targetYear === currentYear && targetMonth === currentMonth)
      ? userData
      : (otherMonthUserData && targetYear === planningYear && targetMonth === planningMonth
        ? otherMonthUserData
        : loadUserData(targetYear, targetMonth));
    const payrollForMonth = calculatePayroll(targetYear, targetMonth, dataForMonth);
    setPrintModalConfig({
      isOpen: true,
      payroll: payrollForMonth,
      userData: dataForMonth,
      month: targetMonth,
      year: targetYear
    });
  };


  // Bottom dock tabs config
  const navTabs = [
    { id: 'home' as AppTab, label: lang === 'ar' ? 'الرئيسية' : lang === 'fr' ? 'Accueil' : 'Home', icon: Home },
    { id: 'calendar' as AppTab, label: lang === 'ar' ? 'المصفوفة' : lang === 'fr' ? 'Matrice' : 'Planning', icon: CalendarDays },
    { id: 'payroll' as AppTab, label: lang === 'ar' ? 'الأجرة' : lang === 'fr' ? 'Paie' : 'Payroll', icon: Receipt },
    { id: 'settings' as AppTab, label: lang === 'ar' ? 'الإعدادات' : lang === 'fr' ? 'Config' : 'Config', icon: Settings },
  ];

  // Onboarding screen if user is first time
  if (!userData.onboarded) {
    return (
      <div className={`min-h-screen bg-[#f8f9fa] flex items-center justify-center p-4 sm:p-6 ${translations[lang].font}`} dir={isRTL ? 'rtl' : 'ltr'}>
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="bg-white rounded-[24px] p-6 sm:p-8 max-w-lg w-full shadow-lg border border-gray-100 space-y-6"
        >
          {/* Yazaki Logo in Onboarding */}
          <div className="flex justify-center mb-2">
            <YazakiLogo size="lg" />
          </div>

          <div className="text-center">
            <h1 className="text-xl sm:text-2xl font-black text-gray-900">
              {lang === 'ar' ? 'تهيئة نظام سمارت شيفت يازاكي' : lang === 'fr' ? 'Configuration SmartShift Yazaki' : 'SmartShift Yazaki Setup'}
            </h1>
            <p className="text-xs text-gray-400 font-medium mt-1">
              {lang === 'ar' ? 'يرجى إدخال بيانات المشغل للبدء' : lang === 'fr' ? 'Gestion des plannings & calcul de paie Maroc' : 'Shift and payroll tracking for Moroccan manufacturing'}
            </p>
          </div>

          {/* Language Selector */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2 text-center">
              Language / Langue / اللغة
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['fr', 'ar', 'en'] as Language[]).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setUserData({ ...userData, language: l })}
                  className={`py-2 rounded-xl text-xs font-bold transition-all ${
                    userData.language === l
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {l === 'fr' ? 'Français' : l === 'ar' ? 'العربية' : 'English'}
                </button>
              ))}
            </div>
          </div>

          {/* Operator Name */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">
              {lang === 'ar' ? 'اسم المشغل' : lang === 'fr' ? 'Nom du Collaborateur' : 'Operator Name'}
            </label>
            <input
              type="text"
              id="onboarding_collaborateur_name"
              name="collaborateur_fullname"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              value={userData.name}
              onChange={(e) => setUserData({ ...userData, name: e.target.value })}
              placeholder={lang === 'ar' ? 'أدخل اسم المشغل' : lang === 'fr' ? 'Saisir le nom du collaborateur' : 'Enter operator name'}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Salary Protocol */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">
              {lang === 'ar' ? 'نوع الأجر' : lang === 'fr' ? 'Régime de Paie' : 'Salary Scheme'}
            </label>
            <div className="grid grid-cols-2 gap-2 bg-gray-100 p-1 rounded-2xl mb-2">
              <button
                type="button"
                onClick={() => setUserData({ ...userData, salaryType: 'hourly' })}
                className={`py-2 rounded-xl text-xs font-black ${
                  userData.salaryType === 'hourly' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500'
                }`}
              >
                {lang === 'ar' ? 'سعر بالساعة' : lang === 'fr' ? 'Taux Horaire' : 'Hourly Rate'}
              </button>
              <button
                type="button"
                onClick={() => setUserData({ ...userData, salaryType: 'fixed' })}
                className={`py-2 rounded-xl text-xs font-black ${
                  userData.salaryType === 'fixed' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500'
                }`}
              >
                {lang === 'ar' ? 'راتب شهري ثابت' : lang === 'fr' ? 'Salaire Fixe' : 'Fixed Monthly'}
              </button>
            </div>

            <div className="relative">
              <input
                type="number"
                step="0.01"
                value={userData.salaryType === 'hourly' ? userData.hourlyRate : userData.baseSalary}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  setUserData(prev => ({
                    ...prev,
                    [prev.salaryType === 'hourly' ? 'hourlyRate' : 'baseSalary']: val
                  }));
                }}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm font-black text-gray-900 focus:outline-none focus:border-purple-500 pr-16"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-gray-400">
                {userData.salaryType === 'hourly' ? 'MAD/H' : 'MAD'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              if (!userData.name) {
                alert(lang === 'ar' ? 'يرجى إدخال اسم المشغل' : lang === 'fr' ? 'Veuillez saisir un nom' : 'Please enter a name');
                return;
              }
              setUserData(prev => ({ ...prev, onboarded: true }));
              setActiveTab('home');
            }}
            className="w-full py-4 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-sm shadow-lg shadow-purple-600/30 transition-all active:scale-95"
          >
            {lang === 'ar' ? 'دخول لوحة التحكم' : lang === 'fr' ? 'Accéder à Optibus' : 'Enter Dashboard'}
          </button>
        </motion.div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <motion.div
            key="home"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-4 sm:space-y-6"
          >
            {/* Dashboard Hero & 2-Column Metrics always on current month */}
            <Dashboard 
              payroll={currentPayroll}
              userData={userData}
              onNavigateToTab={(tab) => setActiveTab(tab)}
            />
          </motion.div>
        );

      case 'calendar':
        return (
          <motion.div
            key="calendar"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-4 sm:space-y-6"
          >
            {calendarViewMode === 'weekly' ? (
              <WeeklyPlanning 
                userData={userData}
                onUpdateUserData={setUserData}
                onToggleDay={toggleDay}
                onSwitchToMonthly={() => setCalendarViewMode('monthly')}
              />
            ) : (
              <Calendar 
                year={planningYear}
                month={planningMonth}
                userData={isPlanningCurrentMonth ? userData : (otherMonthUserData || userData)}
                onToggleDay={(iso, cat) => toggleDay(iso, cat, planningYear, planningMonth)}
                onPrevMonth={handlePrevPlanningMonth}
                onNextMonth={handleNextPlanningMonth}
                onResetMonth={handleResetPlanningMonth}
                onShowMonthPayroll={handleShowMonthPayroll}
                onSwitchToWeekly={() => setCalendarViewMode('weekly')}
              />
            )}
          </motion.div>
        );

      case 'payroll':
        return (
          <motion.div
            key="payroll"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-4 sm:space-y-6"
          >
            {/* Payroll always anchors to current month */}
            <EarningsDetails 
              payroll={currentPayroll}
              userData={userData}
              onOpenPrint={handleOpenCurrentPrint}
            />
          </motion.div>
        );

      case 'settings':
        return (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="space-y-4 sm:space-y-6"
          >
            <SettingsView 
              userData={userData}
              onUpdateUserData={setUserData}
            />
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div 
      className={`min-h-screen bg-[#f8f9fa] dark:bg-[#090d16] text-gray-900 dark:text-slate-100 safe-pb overflow-x-hidden transition-colors duration-200 ${translations[lang].font}`} 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* 0. Launch / Splash Screen (Screenshot 2) */}
      <AnimatePresence>
        {showSplash && (
          <SplashScreen onComplete={() => setShowSplash(false)} />
        )}
      </AnimatePresence>

      {/* 1. Top Header Bar */}
      <header className="sticky top-0 z-30 bg-[#f8f9fa]/90 dark:bg-[#090d16]/90 backdrop-blur-md border-b border-gray-200/60 dark:border-slate-800/80 px-4 sm:px-6 py-3 transition-all">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          {/* Left: Back Button when not in Home */}
          <div className="flex items-center gap-2 min-w-[44px]">
            {activeTab !== 'home' ? (
              <button
                onClick={() => setActiveTab('home')}
                className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-gray-200/80 dark:border-slate-700/80 shadow-2xs hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center justify-center text-gray-700 dark:text-slate-200 active:scale-95 transition-all"
                aria-label="Back to home"
              >
                <ArrowLeft className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            ) : null}
          </div>

          {/* Center: Clean Yazaki Logo */}
          <div className="flex items-center justify-center w-[150px] px-2 cursor-pointer" onClick={() => setShowSplash(true)} title="Cliquez pour rejouer l'animation de démarrage">
            <YazakiLogo size="md" showSubtitle={false} />
          </div>

          {/* Right: Quick Dark/Light Mode Toggle */}
          <div className="min-w-[44px] flex items-center justify-end">
            <button
              onClick={handleToggleTheme}
              className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-gray-200/80 dark:border-slate-700/80 shadow-2xs hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center justify-center text-gray-700 dark:text-amber-400 active:scale-95 transition-all cursor-pointer"
              title={userData.theme === 'dark' ? (lang === 'ar' ? 'الوضع الفاتح' : 'Mode Clair') : (lang === 'ar' ? 'الوضع الداكن' : 'Mode Sombre')}
              aria-label="Toggle Dark Mode"
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={userData.theme === 'dark' ? 'dark-icon' : 'light-icon'}
                  initial={{ rotate: -90, opacity: 0, scale: 0.7 }}
                  animate={{ rotate: 0, opacity: 1, scale: 1 }}
                  exit={{ rotate: 90, opacity: 0, scale: 0.7 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center justify-center"
                >
                  {userData.theme === 'dark' ? (
                    <Sun className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Moon className="w-4 h-4 text-slate-700 dark:text-slate-300" />
                  )}
                </motion.div>
              </AnimatePresence>
            </button>
          </div>
        </div>
      </header>

      {/* 2. Main Content Container */}
      <main className="max-w-2xl mx-auto px-3.5 sm:px-6 pt-4 sm:pt-6 pb-36 sm:pb-40">
        <AnimatePresence mode="wait">
          {renderContent()}
        </AnimatePresence>
      </main>

      {/* 3. Floating Bottom Navigation Dock with Motion & Dark Mode Support */}
      {!isKeyboardVisible && (
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 z-40 pointer-events-none pb-[max(env(safe-area-inset-bottom,0px),16px)] px-3 sm:px-6 mb-2 sm:mb-4"
        >
          <nav className="pointer-events-auto max-w-sm sm:max-w-md mx-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-gray-200/90 dark:border-slate-800/90 rounded-full py-2 px-2.5 flex justify-around items-center shadow-[0_10px_35px_rgba(0,0,0,0.12)] dark:shadow-[0_10px_35px_rgba(0,0,0,0.5)] transition-colors">
            {navTabs.map(tab => {
              const Icon = tab.icon;
              const isSelected = activeTab === tab.id;
              return (
                <motion.button
                  key={tab.id}
                  whileTap={{ scale: 0.92 }}
                  onClick={() => {
                    setActiveTab(tab.id);
                    if (tab.id === 'calendar') setCalendarViewMode('weekly');
                  }}
                  className={`relative flex flex-col items-center gap-1 py-1.5 px-3.5 min-h-[46px] justify-center transition-colors rounded-full ${
                    isSelected
                      ? 'text-slate-900 dark:text-white font-extrabold'
                      : 'text-gray-400 dark:text-slate-500 hover:text-gray-700 dark:hover:text-slate-300'
                  }`}
                >
                  {isSelected && (
                    <motion.div
                      layoutId="activeTabBadge"
                      className="absolute inset-0 bg-gray-100/90 dark:bg-slate-800/90 rounded-full shadow-2xs -z-10"
                      transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                    />
                  )}
                  <Icon className={`w-5 h-5 ${isSelected ? 'text-slate-900 dark:text-white stroke-[2.5]' : 'stroke-[1.8]'}`} />
                  <span className="text-[9px] font-extrabold uppercase tracking-wider whitespace-nowrap">
                    {tab.label}
                  </span>
                </motion.button>
              );
            })}
          </nav>
        </motion.div>
      )}

      {/* 4. Dark Navigation Drawer (☰) */}
      <NavigationDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'calendar') setCalendarViewMode('weekly');
        }}
        userData={userData}
        onUpdateUserData={setUserData}
        onOpenPrint={handleOpenCurrentPrint}
      />

      {/* 5. Print / Export Official Payslip Modal */}
      {printModalConfig.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-6 overflow-y-auto print-modal-overlay">
          <div className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[95vh] overflow-y-auto p-3 sm:p-6 shadow-2xl print-modal-content">
            <PayrollReport
              payroll={printModalConfig.payroll}
              userData={printModalConfig.userData}
              month={printModalConfig.month}
              year={printModalConfig.year}
              onClose={() => setPrintModalConfig(prev => ({ ...prev, isOpen: false }))}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
