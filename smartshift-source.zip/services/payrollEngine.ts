
import { ShiftType, UserData, SalaryBreakdown, ShiftInfo } from '../types';
import { OVERTIME_THRESHOLD, SHIFT_CONFIG } from '../constants';
import { getShiftForDate, getHolidayName, formatDateISO, getShiftDayForTime } from '../utils/dateUtils';

export const calculatePayroll = (year: number, month: number, userData: UserData): SalaryBreakdown => {
  const rate = userData.salaryType === 'fixed' 
    ? ((userData.baseSalary && userData.baseSalary > 0 ? userData.baseSalary : 3422.72) / 191) 
    : (userData.hourlyRate && userData.hourlyRate > 0 ? userData.hourlyRate : 17.92);

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const now = new Date();
  const currentShiftDay = getShiftDayForTime(now);

  let actualRegularHours = 0;
  let actualK3Hours = 0;
  let actualSundayPay = 0;
  let actualSundayHours = 0;
  let actualSundayDaysCount = 0;
  let actualHolidayWorkedBonus = 0;
  let actualHolidayDaysCount = 0;
  let actualHolidayBasePay = 0;

  // Projected Hours Calculation
  let projRegularHours = 0;
  let projK3Hours = 0;
  let projSundayHours = 0;
  
  const absencesInMonth = userData.absences.filter(a => {
    const d = new Date(a);
    return d.getFullYear() === year && d.getMonth() === month;
  });

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    const iso = formatDateISO(date);
    const isPastShiftDay = iso < currentShiftDay;
    const isCurrentShiftDay = iso === currentShiftDay;
    const isAbsence = userData.absences.includes(iso);
    
    if (userData.nextMonthDays.includes(iso)) continue;

    const shift = getShiftForDate(date, userData);
    const isHoliday = !!getHolidayName(date);
    const isSunday = date.getDay() === 0;

    const config = SHIFT_CONFIG[shift];
    const shiftStart = new Date(date);
    shiftStart.setHours(config.start, 0, 0, 0);
    const shiftEnd = new Date(date);
    if (config.end < config.start) shiftEnd.setDate(shiftEnd.getDate() + 1);
    shiftEnd.setHours(config.end, 0, 0, 0);

    const isShiftFullyCompleted = now > shiftEnd;
    const isShiftCurrentlyRunning = now >= shiftStart && now < shiftEnd;

    // Projected (Simplified calculation for the full month assuming no future absences)
    if (!isAbsence) {
      if (isSunday) {
        // Only project Sunday if it's already marked as worked (we don't assume future Sundays)
        if (userData.specialDaysWorked.includes(iso)) {
          projSundayHours += 8;
        }
      } else {
        if (shift !== ShiftType.OFF) {
          projRegularHours += 8;
          if (shift === ShiftType.K3 && !isHoliday) projK3Hours += 8;
        }
      }
    }

    // Actuals
    if (!isAbsence) {
      const isHolidayPaidDay = isHoliday && shift !== ShiftType.OFF;

      if (isPastShiftDay || (isCurrentShiftDay && isShiftFullyCompleted)) {
        if (isSunday) {
          if (userData.specialDaysWorked.includes(iso)) {
            actualSundayHours += 8;
            actualSundayPay += 8 * rate * (1 + userData.sundayRate);
            actualSundayDaysCount++;
          }
        } else if (isHolidayPaidDay) {
          actualRegularHours += 8;
          if (userData.holidaysWorked.includes(iso)) {
            actualHolidayWorkedBonus += 8 * rate;
            actualHolidayDaysCount++;
          }
        } else if (shift !== ShiftType.OFF) {
          actualRegularHours += 8;
          if (shift === ShiftType.K3) actualK3Hours += 8;
        }
      } else if (isCurrentShiftDay && isShiftCurrentlyRunning) {
        const elapsedHours = Math.max(0, Math.min(8, (now.getTime() - shiftStart.getTime()) / (1000 * 60 * 60)));
        if (isSunday && userData.specialDaysWorked.includes(iso)) {
          actualSundayHours += elapsedHours;
          actualSundayPay += elapsedHours * rate * (1 + userData.sundayRate);
          actualSundayDaysCount++;
        } else if (isHolidayPaidDay) {
          actualRegularHours += elapsedHours;
          if (userData.holidaysWorked.includes(iso)) {
            actualHolidayWorkedBonus += elapsedHours * rate;
            actualHolidayDaysCount++;
          }
        } else if (shift !== ShiftType.OFF) {
          actualRegularHours += elapsedHours;
          if (shift === ShiftType.K3) actualK3Hours += elapsedHours;
        }
      }
    }
  }

  // Calculate actual bonuses
  const effectiveBaseSalary = userData.salaryType === 'fixed'
    ? (userData.baseSalary && userData.baseSalary > 0 ? userData.baseSalary : 3422.72)
    : (rate * 191);

  const baseSalaryComponent = userData.salaryType === 'fixed' 
    ? effectiveBaseSalary * (actualRegularHours / 191) 
    : (actualRegularHours * rate);

  const k3Bonus = actualK3Hours * rate * userData.k3Rate;
  const overtimeHours = Math.max(0, actualRegularHours - OVERTIME_THRESHOLD);
  const overtimeBonus = overtimeHours * rate * userData.overtimeRate;
  
  const seniorityBase = Math.min(actualRegularHours, OVERTIME_THRESHOLD) * rate + overtimeBonus + actualSundayPay + actualHolidayWorkedBonus;
  const seniorityBonus = seniorityBase * userData.seniorityRate;
  
  const attendanceBonus = (absencesInMonth.length === 0) 
    ? (userData.attendanceBonusValue !== undefined ? userData.attendanceBonusValue : 300) 
    : 0;

  const deductibleBase = baseSalaryComponent + actualSundayPay + actualHolidayWorkedBonus + overtimeBonus;
  const currentSubTotal = baseSalaryComponent + k3Bonus + actualSundayPay + actualHolidayWorkedBonus + overtimeBonus + seniorityBonus;
  const customBonusTotal = userData.customPercentageBonuses.reduce((acc, bonus) => {
    return acc + (bonus.type === 'percentage' ? currentSubTotal * bonus.value : bonus.value);
  }, 0);

  const grossTotal = currentSubTotal + attendanceBonus + customBonusTotal;

  // Calculate projected gross
  const projK3Bonus = projK3Hours * rate * userData.k3Rate;
  const projOvertimeHours = Math.max(0, projRegularHours - OVERTIME_THRESHOLD);
  const projOvertimeBonus = projOvertimeHours * rate * userData.overtimeRate;
  const projSundayPay = projSundayHours * rate * (1 + userData.sundayRate);
  
  const projBaseSalary = userData.salaryType === 'fixed' 
    ? effectiveBaseSalary 
    : (projRegularHours * rate);
    
  const projSeniorityBase = Math.min(projRegularHours, OVERTIME_THRESHOLD) * rate + projOvertimeBonus + projSundayPay;
  const projSeniorityBonus = projSeniorityBase * userData.seniorityRate;
  
  // Custom bonus for projection (approximated)
  const projSubTotal = projBaseSalary + projK3Bonus + projSundayPay + projOvertimeBonus + projSeniorityBonus;
  const projCustomBonusTotal = userData.customPercentageBonuses.reduce((acc, bonus) => {
    return acc + (bonus.type === 'percentage' ? projSubTotal * bonus.value : bonus.value);
  }, 0);

  const projectedGrossTotal = projSubTotal + attendanceBonus + projCustomBonusTotal;

  const customDeductionTotal = userData.customDeductions.reduce((acc, ded) => {
    return acc + (ded.type === 'percentage' ? deductibleBase * ded.value : ded.value);
  }, 0);

  // Statutory & Contractual Deductions:
  // CNSS: 4.48% (capped at 6000 MAD)
  // Private Health Insurance (Mutuelle): 1.8% (default) or AMO (2.26%)
  const cnssDeduction = Math.min(deductibleBase, 6000) * 0.0448;
  const healthInsuranceRate = userData.healthInsuranceRate !== undefined ? userData.healthInsuranceRate : 0.018;
  const healthInsuranceDeduction = deductibleBase * healthInsuranceRate;
  const amoDeduction = healthInsuranceDeduction; // maintain compatibility
  
  const healthInsuranceLabel = userData.healthInsuranceType === 'amo'
    ? 'AMO (2.26%)'
    : `Assurance Maladie Privée (${(healthInsuranceRate * 100).toFixed(1)}%)`;

  const netTotal = Math.max(0, grossTotal - cnssDeduction - healthInsuranceDeduction - customDeductionTotal);

  // Projected deductions calculation
  const projDeductibleBase = projBaseSalary + projSundayPay + projOvertimeBonus;
  const projCnss = Math.min(projDeductibleBase, 6000) * 0.0448;
  const projHealthInsurance = projDeductibleBase * healthInsuranceRate;
  const projCustomDeduction = userData.customDeductions.reduce((acc, ded) => {
    return acc + (ded.type === 'percentage' ? projDeductibleBase * ded.value : ded.value);
  }, 0);
  const projectedNetSalary = Math.max(0, projectedGrossTotal - projCnss - projHealthInsurance - projCustomDeduction);

  return {
    regularHours: actualRegularHours,
    regularPay: baseSalaryComponent,
    holidayBasePay: 0,
    k3Hours: actualK3Hours,
    k3Bonus,
    sundayHours: actualSundayHours,
    sundayPay: actualSundayPay,
    sundayDaysCount: actualSundayDaysCount,
    holidayWorkedBonus: actualHolidayWorkedBonus,
    holidayDaysCount: actualHolidayDaysCount,
    overtimeHours,
    overtimeBonus,
    seniorityBase,
    seniorityBonus,
    attendanceBonus,
    customBonusTotal,
    customDeductionTotal,
    grossTotal,
    cnssDeduction,
    amoDeduction,
    healthInsuranceDeduction,
    healthInsuranceRate,
    healthInsuranceLabel,
    netTotal,
    netSalary: netTotal,
    projectedGrossTotal,
    projectedNetSalary,
    projectedHours: projRegularHours
  };
};

export const getCurrentShiftInfo = (userData: UserData): ShiftInfo => {
  const now = new Date();
  const shiftDayISO = getShiftDayForTime(now);
  const [y, m, d] = shiftDayISO.split('-').map(Number);
  const shiftDay = new Date(y, m - 1, d);
  
  const isAbsence = userData.absences.includes(shiftDayISO);
  const todayShift = isAbsence ? ShiftType.OFF : getShiftForDate(shiftDay, userData);
  const config = SHIFT_CONFIG[todayShift];
  
  const start = new Date(shiftDay);
  start.setHours(config.start, 0, 0, 0);
  const end = new Date(shiftDay);
  if (config.end < config.start) end.setDate(end.getDate() + 1);
  end.setHours(config.end, 0, 0, 0);

  const active = now >= start && now < end && todayShift !== ShiftType.OFF;
  const progress = active ? ((now.getTime() - start.getTime()) / (end.getTime() - start.getTime())) * 100 : 0;

  let nextShiftStart: Date | undefined;
  let nextShiftType: ShiftType | undefined;
  let nextShiftIsSunday: boolean | undefined;
  let nextShiftIsHoliday: boolean | undefined;
  let nextShiftHolidayName: string | undefined;
  let nextShiftDateStr: string | undefined;

  if (!active) {
    // Scan next 14 days to find the earliest upcoming shift
    for (let i = 0; i < 14; i++) {
      const scanDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      scanDay.setDate(scanDay.getDate() + i);
      const scanISO = formatDateISO(scanDay);
      
      if (userData.absences.includes(scanISO)) continue;

      const scanShift = getShiftForDate(scanDay, userData);
      if (scanShift !== ShiftType.OFF) {
        const scanConfig = SHIFT_CONFIG[scanShift];
        const scanStart = new Date(scanDay);
        scanStart.setHours(scanConfig.start, 0, 0, 0);
        
        if (scanStart > now) {
          nextShiftStart = scanStart;
          nextShiftType = scanShift;
          nextShiftIsSunday = scanDay.getDay() === 0;
          const holiday = getHolidayName(scanDay);
          nextShiftIsHoliday = !!holiday;
          nextShiftHolidayName = holiday;
          nextShiftDateStr = scanISO;
          break;
        }
      }
    }
  }

  return { 
    type: todayShift, 
    start, 
    end, 
    active, 
    progress, 
    nextShiftStart, 
    nextShiftType,
    nextShiftIsSunday,
    nextShiftIsHoliday,
    nextShiftHolidayName,
    nextShiftDateStr
  };
};
