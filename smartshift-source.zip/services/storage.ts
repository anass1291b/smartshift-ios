
import { UserData, ShiftType } from '../types';

const BASE_KEY = 'smartShiftData_v3';

/**
 * Automatically purges shift exceptions whose date is strictly before today.
 * Ensures planning exceptions are removed immediately after their period ends.
 */
export const cleanExpiredExceptions = (exceptions: Record<string, ShiftType> | undefined): Record<string, ShiftType> => {
  if (!exceptions) return {};
  const today = new Date();
  const todayISO = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  
  const cleaned: Record<string, ShiftType> = {};
  for (const [dateStr, shift] of Object.entries(exceptions)) {
    if (dateStr >= todayISO) {
      cleaned[dateStr] = shift;
    }
  }
  return cleaned;
};

export const saveUserData = (year: number, month: number, data: UserData) => {
  const cleanedExceptions = cleanExpiredExceptions(data.shiftExceptions);
  const dataToSave = { ...data, shiftExceptions: cleanedExceptions };

  const monthKey = `${BASE_KEY}_${year}_${month}`;
  localStorage.setItem(monthKey, JSON.stringify(dataToSave));
  
  // Persist core profile settings globally to avoid loss during month navigation
  const profile = {
    name: dataToSave.name,
    language: dataToSave.language || 'fr',
    salaryType: dataToSave.salaryType,
    baseSalary: dataToSave.baseSalary,
    hourlyRate: dataToSave.hourlyRate,
    attendanceBonusValue: dataToSave.attendanceBonusValue,
    healthInsuranceType: dataToSave.healthInsuranceType || 'private',
    healthInsuranceRate: dataToSave.healthInsuranceRate !== undefined ? dataToSave.healthInsuranceRate : 0.018,
    shiftMode: dataToSave.shiftMode || (dataToSave.shiftCycle?.length === 2 ? '2shifts' : '3shifts'),
    currentShift: dataToSave.currentShift,
    shiftCycle: dataToSave.shiftCycle,
    shiftExceptions: dataToSave.shiftExceptions,
    cycleAnchorMonday: dataToSave.cycleAnchorMonday,
    currentWeekIndex: dataToSave.currentWeekIndex,
    onboarded: dataToSave.onboarded,
    theme: dataToSave.theme,
    k3Rate: dataToSave.k3Rate,
    seniorityRate: dataToSave.seniorityRate,
    overtimeRate: dataToSave.overtimeRate,
    sundayRate: dataToSave.sundayRate,
    customPercentageBonuses: dataToSave.customPercentageBonuses,
    customDeductions: dataToSave.customDeductions
  };
  localStorage.setItem(`${BASE_KEY}_profile`, JSON.stringify(profile));
};

export const loadUserData = (year: number, month: number): UserData => {
  const monthKey = `${BASE_KEY}_${year}_${month}`;
  const profileKey = `${BASE_KEY}_profile`;
  
  const savedMonth = localStorage.getItem(monthKey);
  const savedProfile = localStorage.getItem(profileKey);
  
  const now = new Date();
  const currentMonday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const currentDayOffset = currentMonday.getDay() === 0 ? 6 : currentMonday.getDay() - 1;
  currentMonday.setDate(currentMonday.getDate() - currentDayOffset);
  const defaultAnchor = `${currentMonday.getFullYear()}-${String(currentMonday.getMonth() + 1).padStart(2, '0')}-${String(currentMonday.getDate()).padStart(2, '0')}`;

  const defaults: UserData = {
    onboarded: false,
    name: '',
    language: 'fr',
    salaryType: 'hourly',
    baseSalary: 3422.72,
    hourlyRate: 17.92,
    attendanceBonusValue: 300,
    healthInsuranceType: 'private',
    healthInsuranceRate: 0.018,
    shiftCycle: [ShiftType.K1, ShiftType.K2, ShiftType.K3],
    shiftExceptions: {},
    cycleAnchorMonday: defaultAnchor,
    currentWeekIndex: 0,
    specialDaysWorked: [],
    holidaysWorked: [],
    absences: [],
    nextMonthDays: [],
    customPercentageBonuses: [],
    customDeductions: [],
    k3Rate: 0.20,
    seniorityRate: 0.05,
    overtimeRate: 0.25,
    sundayRate: 1.0,
    theme: 'light'
  };

  const profile = savedProfile ? JSON.parse(savedProfile) : {};
  const monthData = savedMonth ? JSON.parse(savedMonth) : {};

  // Profile configuration takes precedence over legacy month-specific snapshots
  const merged = { ...defaults, ...monthData, ...profile };
  if (!merged.theme || merged.theme === 'luxury') merged.theme = 'light';
  if (!merged.language) merged.language = 'fr';
  if (!merged.hourlyRate || merged.hourlyRate <= 0) merged.hourlyRate = 17.92;
  if (!merged.baseSalary || merged.baseSalary <= 0) merged.baseSalary = 3422.72;
  if (merged.attendanceBonusValue === undefined) merged.attendanceBonusValue = 300;
  if (!merged.healthInsuranceType) merged.healthInsuranceType = 'private';
  if (merged.healthInsuranceRate === undefined) merged.healthInsuranceRate = 0.018;

  // Clean expired exceptions upon load
  merged.shiftExceptions = cleanExpiredExceptions(merged.shiftExceptions);

  return merged;
};

