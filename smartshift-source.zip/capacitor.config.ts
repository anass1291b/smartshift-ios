import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.yazaki.smartshift',
  appName: 'SmartShift',
  webDir: 'dist'
};

export default config;
