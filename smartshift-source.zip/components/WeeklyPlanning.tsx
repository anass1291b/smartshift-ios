import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Calendar as CalendarIcon, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles,
  Layers,
  Check,
  X,
  Sun,
  Sunset,
  Moon,
  Coffee,
  Repeat
} from 'lucide-react';
import { ShiftType, UserData } from '../types';
import { getShiftForDate, getHolidayName, formatDateISO, formatTime13h, formatShiftRange13h } from '../utils/dateUtils';
import { SHIFT_CONFIG } from '../constants';
import { translations, TranslationKey } from '../translations';

interface WeeklyPlanningProps {
  userData: UserData;
  onUpdateUserData: (data: UserData) => void;
  onToggleDay: (date: string, type: 'worked' | 'absence') => void;
  onSwitchToMonthly: () => void;
}

export const WeeklyPlanning: React.FC<WeeklyPlanningProps> = ({
  userData,
  onUpdateUserData,
  onToggleDay,
  onSwitchToMonthly
}) => {
  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang][key] || key;
  const isRTL = translations[lang].dir === 'rtl';
  const localeStr = lang === 'ar' ? 'ar-MA' : lang === 'fr' ? 'fr-FR' : 'en-US';

  // Week offset state from current week (0 = current week)
  const [weekOffset, setWeekOffset] = useState(0);

  // Compute Monday of the selected week
  const now = new Date();
  const currentMonday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const dayOfWeek = currentMonday.getDay();
  const diffToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  currentMonday.setDate(currentMonday.getDate() + diffToMonday + (weekOffset * 7));
  currentMonday.setHours(0, 0, 0, 0);

  // Calculate week number
  const startOfYear = new Date(currentMonday.getFullYear(), 0, 1);
  const daysSinceStart = Math.floor((currentMonday.getTime() - startOfYear.getTime()) / (24 * 60 * 60 * 1000));
  const weekNumber = Math.ceil((daysSinceStart + startOfYear.getDay() + 1) / 7);

  // Week days array (Monday to Sunday)
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(currentMonday);
    d.setDate(currentMonday.getDate() + i);
    return d;
  });

  const weekStartDate = weekDays[0];
  const weekEndDate = weekDays[6];

  const weekRangeLabel = `${weekStartDate.toLocaleDateString(localeStr, { day: 'numeric', month: 'short' })} - ${weekEndDate.toLocaleDateString(localeStr, { day: 'numeric', month: 'short' })}`;
  
  // Clean day accent colors
  const dayAccentColors = [
    '#6c5ce7', // Monday: Purple
    '#1e293b', // Tuesday: Dark Slate
    '#334155', // Wednesday: Slate Navy
    '#0284c7', // Thursday: Sky Blue
    '#10b981', // Friday: Mint Green
    '#ef4444', // Saturday: Red
    '#f59e0b', // Sunday: Amber
  ];

  // Calculate which week in the cycle corresponds to the currently viewed week
  const anchorISO = userData.cycleAnchorMonday || '2026-07-06';
  const [ay, am, ad] = anchorISO.split('-').map(Number);
  const anchorMonday = new Date(ay, am - 1, ad);
  anchorMonday.setHours(0, 0, 0, 0);
  const diffMs = currentMonday.getTime() - anchorMonday.getTime();
  const diffWeeks = Math.round(diffMs / (7 * 24 * 60 * 60 * 1000));
  const cycleLength = userData.shiftCycle.length || 4;
  const activeCycleIndex = ((diffWeeks % cycleLength) + cycleLength) % cycleLength;

  const getNextShift = (current: ShiftType): ShiftType => {
    if (current === ShiftType.K1) return ShiftType.K2;
    if (current === ShiftType.K2) return ShiftType.K3;
    if (current === ShiftType.K3) return ShiftType.OFF;
    return ShiftType.K1;
  };

  // Formatted "Updated at" timestamp in 13h format
  const updatedDateStr = now.toLocaleDateString(localeStr, { day: '2-digit', month: '2-digit', year: 'numeric' });
  const updatedTimestamp = `${updatedDateStr} à ${formatTime13h(now)}`;

  const getShiftBadgeStyle = (shift: ShiftType) => {
    switch (shift) {
      case ShiftType.K1:
        return 'bg-purple-50 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-500/30';
      case ShiftType.K2:
        return 'bg-sky-50 dark:bg-sky-500/20 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-500/30';
      case ShiftType.K3:
        return 'bg-amber-50 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-500/30';
      case ShiftType.OFF:
      default:
        return 'bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400 border-gray-200 dark:border-slate-700';
    }
  };

  const handleSetDayShift = (iso: string, shift: ShiftType, isSunday: boolean, isHoliday: boolean) => {
    const nextExceptions = { ...userData.shiftExceptions, [iso]: shift };
    let nextSpecialWorked = [...(userData.specialDaysWorked || [])];
    let nextHolidaysWorked = [...(userData.holidaysWorked || [])];
    let nextAbsences = (userData.absences || []).filter(a => a !== iso);
    
    if (isSunday) {
      if (shift !== ShiftType.OFF) {
        if (!nextSpecialWorked.includes(iso)) {
          nextSpecialWorked.push(iso);
        }
      } else {
        nextSpecialWorked = nextSpecialWorked.filter(d => d !== iso);
      }
    } else if (isHoliday) {
      if (shift !== ShiftType.OFF) {
        if (!nextHolidaysWorked.includes(iso)) {
          nextHolidaysWorked.push(iso);
        }
      } else {
        nextHolidaysWorked = nextHolidaysWorked.filter(d => d !== iso);
      }
    } else {
      if (shift === ShiftType.OFF) {
        if (!nextAbsences.includes(iso)) {
          nextAbsences.push(iso);
        }
      }
    }

    onUpdateUserData({
      ...userData,
      specialDaysWorked: nextSpecialWorked,
      holidaysWorked: nextHolidaysWorked,
      shiftExceptions: nextExceptions,
      absences: nextAbsences
    });
  };

  return (
    <div className="space-y-4 sm:space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Top Unified Switcher Bar */}
      <div className="flex bg-gray-100/90 dark:bg-slate-900/90 p-1 rounded-2xl border border-gray-200/70 dark:border-slate-800 shadow-2xs transition-colors">
        <button
          type="button"
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-sm border border-gray-200/70 dark:border-slate-700"
        >
          <Clock className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
          <span>{lang === 'ar' ? 'تخطيطي الأسبوعي' : lang === 'fr' ? 'Mon Planning Hebdo' : 'My Weekly Planning'}</span>
        </button>
        <button
          type="button"
          onClick={onSwitchToMonthly}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white cursor-pointer"
        >
          <CalendarIcon className="w-3.5 h-3.5 text-gray-400 dark:text-slate-500" />
          <span>{lang === 'ar' ? 'شبكة الشهر' : lang === 'fr' ? 'Grille Mensuelle' : 'Month Grid'}</span>
        </button>
      </div>

      {/* Main Weekly Planning Card */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        {/* Week Navigator Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-slate-800">
          <button
            onClick={() => setWeekOffset(prev => prev - 1)}
            className="w-10 h-10 rounded-xl bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-200 flex items-center justify-center transition-colors active:scale-95 border border-gray-200/70 dark:border-slate-700 cursor-pointer"
            aria-label="Previous week"
          >
            <ChevronLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </button>

          <div className="text-center">
            <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white leading-tight">
              {lang === 'ar' ? `الأسبوع ${weekNumber}` : lang === 'fr' ? `Semaine ${weekNumber}` : `Week ${weekNumber}`}, {currentMonday.getFullYear()}
            </h2>
            <p className="text-xs font-semibold text-gray-400 dark:text-slate-400 mt-0.5" dir="ltr">
              <span className="inline-block tabular-nums">{weekRangeLabel}</span>
            </p>
          </div>

          <button
            onClick={() => setWeekOffset(prev => prev + 1)}
            className="w-10 h-10 rounded-xl bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-200 flex items-center justify-center transition-colors active:scale-95 border border-gray-200/70 dark:border-slate-700 cursor-pointer"
            aria-label="Next week"
          >
            <ChevronRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Section Title & Subtitle */}
        <div className="pt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'تخطيطي الأسبوعي' : lang === 'fr' ? 'Mon Planning Hebdomadaire' : 'My Weekly Planning'}
            </h3>
            <p className="text-[11px] font-medium text-gray-400 dark:text-slate-400">
              {lang === 'ar' ? 'تم التحديث في' : lang === 'fr' ? 'Mis à jour le' : 'Updated at'} {updatedTimestamp}
            </p>
          </div>

          {weekOffset !== 0 && (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => setWeekOffset(0)}
                className="text-[11px] font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-500/10 hover:bg-purple-100 dark:hover:bg-purple-500/20 px-3 py-1.5 rounded-xl transition-all ml-auto cursor-pointer"
              >
                {lang === 'ar' ? 'هذا الأسبوع' : lang === 'fr' ? 'Semaine actuelle' : 'Current Week'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Vertical List of Daily Shift Cards */}
      <motion.div 
        className="space-y-3"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {weekDays.map((date, index) => {
          const iso = formatDateISO(date);
          const shift = getShiftForDate(date, userData);
          const holiday = getHolidayName(date, lang);
          const isSunday = date.getDay() === 0;
          const isHoliday = !!holiday;
          const isWorked = isSunday 
            ? userData.specialDaysWorked.includes(iso) 
            : isHoliday 
            ? userData.holidaysWorked.includes(iso) 
            : (shift !== ShiftType.OFF && !userData.absences.includes(iso));
          const isAbsence = userData.absences.includes(iso);
          const isToday = formatDateISO(new Date()) === iso;
          
          const dayName = new Intl.DateTimeFormat(localeStr, { weekday: 'long' }).format(date);
          const dayNumber = date.getDate();
          const accentColor = dayAccentColors[index % dayAccentColors.length];

          return (
            <motion.div
              key={iso}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.04, type: 'spring', stiffness: 350, damping: 25 }}
              whileHover={{ scale: 1.01 }}
              className={`bg-white dark:bg-slate-900 rounded-[18px] p-4 sm:p-5 border transition-all duration-200 relative overflow-hidden shadow-sm ${
                isToday 
                  ? 'border-purple-300 dark:border-purple-500/50 ring-2 ring-purple-500/10' 
                  : isAbsence
                  ? 'border-rose-200 dark:border-rose-800/50 bg-rose-50/20 dark:bg-rose-950/20'
                  : (isSunday && isWorked)
                  ? 'border-emerald-200 dark:border-emerald-800/50 bg-emerald-50/20 dark:bg-emerald-950/20'
                  : 'border-gray-100 dark:border-slate-800'
              }`}
            >
              {/* Colored Accent Bar (RTL & LTR aware) */}
              <div 
                className={`absolute ${isRTL ? 'right-0 rounded-l-full' : 'left-0 rounded-r-full'} top-3 bottom-3 w-1.5`}
                style={{ backgroundColor: accentColor }}
              />

              <div className={`flex items-center justify-between ${isRTL ? 'pr-3 sm:pr-4' : 'pl-3 sm:pl-4'}`}>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white capitalize">
                      {dayName}, {dayNumber}
                    </h4>
                    {isToday && (
                      <span className="text-[10px] font-black uppercase tracking-wider bg-purple-100 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-full">
                        {lang === 'ar' ? 'اليوم' : lang === 'fr' ? "Aujourd'hui" : 'Today'}
                      </span>
                    )}
                    {isSunday && (
                      <button
                        type="button"
                        onClick={() => onToggleDay(iso, 'worked')}
                        title={lang === 'ar' ? 'تعديل عمل الأحد' : 'Basculer dimanche travaillé/repos'}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full transition-all active:scale-95 cursor-pointer ${
                          isWorked 
                            ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 font-extrabold hover:bg-emerald-200 dark:hover:bg-emerald-500/30' 
                            : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        {isWorked 
                          ? (lang === 'ar' ? '✓ الأحد (+100%)' : '✓ Dimanche (+100%)') 
                          : (lang === 'ar' ? 'الأحد (عطلة)' : 'Dimanche (Repos)')}
                      </button>
                    )}
                    {holiday && (
                      <button
                        type="button"
                        onClick={() => onToggleDay(iso, 'worked')}
                        title={lang === 'ar' ? 'تعديل عمل يوم العيد' : 'Basculer jour férié travaillé'}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full truncate max-w-[140px] transition-all active:scale-95 cursor-pointer ${
                          isWorked 
                            ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-900 dark:text-amber-300 font-extrabold hover:bg-amber-200 dark:hover:bg-amber-500/30' 
                            : 'bg-amber-100 dark:bg-amber-500/10 text-amber-800 dark:text-amber-400 hover:bg-amber-200 dark:hover:bg-amber-500/20'
                        }`}
                      >
                        {holiday} {isWorked ? '(+100%)' : ''}
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-gray-500 dark:text-slate-400 mt-1">
                    <Clock className="w-3.5 h-3.5 text-gray-400 dark:text-slate-500" />
                    <span dir="ltr" className="font-semibold text-gray-700 dark:text-slate-300 tabular-nums metric-ltr inline-block">{formatShiftRange13h(shift)}</span>
                    {isAbsence && (
                      <button
                        type="button"
                        onClick={() => onToggleDay(iso, 'absence')}
                        className="text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 px-2 py-0.5 rounded-md transition-all active:scale-95 cursor-pointer"
                      >
                        {lang === 'ar' ? 'غياب' : lang === 'fr' ? 'Absence' : 'Absence'}
                      </button>
                    )}
                    {isSunday && isWorked && (
                      <span dir="ltr" className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-0.5 rounded-md inline-block tabular-nums">
                        +100% {lang === 'ar' ? 'الأحد' : 'Dimanche'}
                      </span>
                    )}
                    {isHoliday && isWorked && !isSunday && (
                      <span dir="ltr" className="text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-2 py-0.5 rounded-md inline-block tabular-nums">
                        +100% {lang === 'ar' ? 'العيد' : 'Férié'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Right Shift Badge Button (Direct 1-tap change, with spring motion feedback) */}
                <div className="flex items-center gap-2">
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.06, y: -1 }}
                    whileTap={{ scale: 0.88, rotate: -2 }}
                    transition={{ type: "spring", stiffness: 450, damping: 20 }}
                    onClick={() => handleSetDayShift(iso, getNextShift(shift), isSunday, isHoliday)}
                    title={lang === 'ar' ? 'اضغط للتبديل الفوري للمناوبة' : lang === 'fr' ? 'Cliquer pour basculer de poste instantanément' : 'Click to cycle shift'}
                    className={`text-xs sm:text-sm font-black px-3.5 py-1.5 rounded-xl border tracking-wide uppercase transition-colors cursor-pointer shadow-2xs ${getShiftBadgeStyle(shift)}`}
                  >
                    {shift}
                  </motion.button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Sleek Shift Rotation Capsule */}
      <div className="flex items-center justify-center pt-1 pb-1">
        <div className="inline-flex items-center gap-1 p-1 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border border-gray-200/80 dark:border-slate-800 rounded-full shadow-2xs text-xs font-bold transition-colors">
          <span className="text-[10px] uppercase tracking-wider text-gray-400 dark:text-slate-500 font-extrabold px-2.5 select-none">
            {lang === 'ar' ? 'الدورة' : 'Cycle'}
          </span>
          {userData.shiftCycle.map((s, idx) => {
            const isCurrent = idx === activeCycleIndex;
            return (
              <div
                key={idx}
                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full transition-all select-none ${
                  isCurrent
                    ? 'bg-slate-900 dark:bg-purple-600 text-white shadow-xs'
                    : 'text-gray-500 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200'
                }`}
              >
                <span className={`text-[9px] ${isCurrent ? 'text-purple-300 dark:text-purple-100 font-black' : 'text-gray-400 dark:text-slate-500'}`}>
                  S{idx + 1}
                </span>
                <span className="font-black text-[10px]">{s}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default WeeklyPlanning;

