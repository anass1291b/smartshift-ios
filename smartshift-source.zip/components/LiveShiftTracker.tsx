import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Clock, 
  Sparkles, 
  Moon, 
  Sun, 
  Sunset, 
  Coffee, 
  Calendar, 
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { UserData, ShiftType } from '../types';
import { SHIFT_CONFIG } from '../constants';
import { getCurrentShiftInfo } from '../services/payrollEngine';
import { formatTime13h, formatShiftRange13h } from '../utils/dateUtils';
import { translations, TranslationKey } from '../translations';

interface LiveShiftTrackerProps {
  userData: UserData;
  onNavigateToPlanning?: () => void;
}

export const LiveShiftTracker: React.FC<LiveShiftTrackerProps> = ({
  userData,
  onNavigateToPlanning
}) => {
  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang]?.[key] || key;
  const isRTL = translations[lang]?.dir === 'rtl';

  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const shiftInfo = useMemo(() => {
    return getCurrentShiftInfo(userData);
  }, [userData, Math.floor(currentTime.getTime() / 15000)]);

  const hourlyRate = userData.salaryType === 'fixed' 
    ? ((userData.baseSalary && userData.baseSalary > 0 ? userData.baseSalary : 3422.72) / 191) 
    : (userData.hourlyRate && userData.hourlyRate > 0 ? userData.hourlyRate : 17.92);

  // Hourly multiplier for live session
  const effectiveRate = useMemo(() => {
    let multiplier = 1;
    if (shiftInfo.type === ShiftType.K3) multiplier += (userData.k3Rate || 0.20);
    const dayOfWeek = currentTime.getDay();
    if (dayOfWeek === 0 && userData.specialDaysWorked?.length) multiplier += (userData.sundayRate || 1.0);
    return hourlyRate * multiplier;
  }, [shiftInfo.type, userData, hourlyRate, currentTime]);

  // Compute session metrics
  const sessionData = useMemo(() => {
    if (!shiftInfo.active || !shiftInfo.start || !shiftInfo.end) {
      return null;
    }
    const totalDurationMs = shiftInfo.end.getTime() - shiftInfo.start.getTime();
    const elapsedMs = Math.max(0, Math.min(totalDurationMs, currentTime.getTime() - shiftInfo.start.getTime()));
    const remainingMs = Math.max(0, totalDurationMs - elapsedMs);
    const progress = Math.min(100, Math.max(0, (elapsedMs / totalDurationMs) * 100));

    const elapsedHours = elapsedMs / (1000 * 60 * 60);
    const earnedSessionMad = elapsedHours * effectiveRate;

    const elapsedHoursInt = Math.floor(elapsedHours);
    const elapsedMinutesInt = Math.floor((elapsedMs % (1000 * 60 * 60)) / (1000 * 60));
    const elapsedSecondsInt = Math.floor((elapsedMs % (1000 * 60)) / 1000);

    const remainingHoursInt = Math.floor(remainingMs / (1000 * 60 * 60));
    const remainingMinutesInt = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));

    return {
      progress,
      elapsedHoursInt,
      elapsedMinutesInt,
      elapsedSecondsInt,
      remainingHoursInt,
      remainingMinutesInt,
      earnedSessionMad
    };
  }, [shiftInfo, currentTime, effectiveRate]);

  // Calculate countdown to next shift if currently off
  const countdownToNext = useMemo(() => {
    if (shiftInfo.active || !shiftInfo.nextShiftStart) return null;
    const diffMs = shiftInfo.nextShiftStart.getTime() - currentTime.getTime();
    if (diffMs <= 0) return null;

    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return {
      hours: diffHours,
      minutes: diffMinutes
    };
  }, [shiftInfo, currentTime]);

  const getShiftIcon = (type: ShiftType) => {
    switch (type) {
      case ShiftType.K1:
        return <Sun className="w-4 h-4 text-amber-500" />;
      case ShiftType.K2:
        return <Sunset className="w-4 h-4 text-orange-500" />;
      case ShiftType.K3:
        return <Moon className="w-4 h-4 text-purple-400" />;
      default:
        return <Coffee className="w-4 h-4 text-slate-400" />;
    }
  };

  const getShiftLabel = (type: ShiftType) => {
    switch (type) {
      case ShiftType.K1:
        return lang === 'ar' ? 'صباحي (K1)' : lang === 'fr' ? 'Matin (K1)' : 'Morning (K1)';
      case ShiftType.K2:
        return lang === 'ar' ? 'مسائي (K2)' : lang === 'fr' ? 'Après-midi (K2)' : 'Afternoon (K2)';
      case ShiftType.K3:
        return lang === 'ar' ? 'ليلي (K3)' : lang === 'fr' ? 'Nuit (K3)' : 'Night (K3)';
      default:
        return lang === 'ar' ? 'راحة (OFF)' : lang === 'fr' ? 'Repos (OFF)' : 'Off';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      dir={isRTL ? 'rtl' : 'ltr'}
      className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-200/80 dark:border-slate-800 shadow-sm relative overflow-hidden"
    >
      {shiftInfo.active && sessionData ? (
        /* ACTIVE SHIFT VIEW */
        <div className="space-y-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="text-[11px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                {t('liveOps')} · {getShiftLabel(shiftInfo.type)}
              </span>
            </div>

            <span dir="ltr" className="text-xs font-mono tabular-nums text-gray-500 dark:text-slate-400 font-semibold inline-block metric-ltr">
              {formatShiftRange13h(SHIFT_CONFIG[shiftInfo.type])}
            </span>
          </div>

          {/* Live Progress Bar */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
              <span dir="ltr" className="text-gray-500 dark:text-slate-400 tabular-nums metric-ltr inline-block">
                {sessionData.elapsedHoursInt}h {String(sessionData.elapsedMinutesInt).padStart(2, '0')}m {t('hoursElapsed')}
              </span>
              <span dir="ltr" className="text-gray-900 dark:text-white font-mono tabular-nums font-bold inline-block metric-ltr">
                {Math.round(sessionData.progress)}%
              </span>
            </div>
            <div className="w-full bg-gray-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <motion.div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full"
                style={{ width: `${sessionData.progress}%` }}
                transition={{ ease: 'linear' }}
              />
            </div>
          </div>

          {/* Ticker Row: Real-time Accrued earnings & Remaining Time */}
          <div className="flex items-center justify-between pt-1 text-xs">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="text-gray-500 dark:text-slate-400">
                {lang === 'ar' ? 'مكتسب الحصة اليوم:' : lang === 'fr' ? 'Gains de ce poste :' : 'Session earnings:'}
              </span>
              <span dir="ltr" className="font-mono tabular-nums font-black text-gray-900 dark:text-white inline-block metric-ltr">
                +{sessionData.earnedSessionMad.toFixed(2)} {lang === 'ar' ? 'درهم' : 'MAD'}
              </span>
            </div>

            <div dir="ltr" className="text-gray-400 dark:text-slate-400 text-[11px] font-medium tabular-nums inline-block metric-ltr">
              {sessionData.remainingHoursInt}h {sessionData.remainingMinutesInt}m {t('hoursRemaining')}
            </div>
          </div>
        </div>
      ) : (
        /* OFF-SHIFT / REST PHASE VIEW */
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400 flex items-center justify-center shrink-0">
              <Coffee className="w-5 h-5" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-gray-500 dark:text-slate-400">
                  {t('restPhase')}
                </span>
                {shiftInfo.nextShiftIsSunday && (
                  <span className="text-[10px] font-extrabold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-500/10 px-1.5 py-0.5 rounded">
                    Dimanche (+100%)
                  </span>
                )}
                {shiftInfo.nextShiftIsHoliday && (
                  <span className="text-[10px] font-extrabold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10 px-1.5 py-0.5 rounded">
                    Férié (+100%)
                  </span>
                )}
              </div>

              {shiftInfo.nextShiftStart && shiftInfo.nextShiftType ? (
                <p className="text-xs sm:text-sm font-semibold text-gray-900 dark:text-white mt-0.5">
                  {t('nextShift')} : <span className="font-bold text-purple-600 dark:text-purple-400">{getShiftLabel(shiftInfo.nextShiftType)}</span>
                  {' · '}
                  <span dir="ltr" className="text-gray-500 dark:text-slate-400 font-mono tabular-nums inline-block">
                    {formatShiftRange13h(SHIFT_CONFIG[shiftInfo.nextShiftType])}
                  </span>
                  {countdownToNext && (
                    <span dir="ltr" className="text-gray-400 dark:text-slate-500 text-xs ms-1.5 inline-block">
                      ({lang === 'ar' ? `خلال ${countdownToNext.hours}س و ${countdownToNext.minutes}د` : `dans ${countdownToNext.hours}h ${countdownToNext.minutes}m`})
                    </span>
                  )}
                </p>
              ) : (
                <p className="text-xs text-gray-400 dark:text-slate-400 mt-0.5">
                  {lang === 'ar' ? 'لا توجد مناوبات مسجلة قادمة' : 'Aucun prochain quart programmé'}
                </p>
              )}
            </div>
          </div>

          {onNavigateToPlanning && (
            <button
              type="button"
              onClick={onNavigateToPlanning}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 py-1.5 px-3 rounded-xl bg-purple-50 dark:bg-purple-500/10 hover:bg-purple-100 dark:hover:bg-purple-500/20 transition-all cursor-pointer self-end sm:self-center"
            >
              <span>{lang === 'ar' ? 'عرض التخطيط' : 'Mon planning'}</span>
              <ArrowRight className={`w-3.5 h-3.5 ${isRTL ? 'rotate-180' : ''}`} />
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default LiveShiftTracker;
