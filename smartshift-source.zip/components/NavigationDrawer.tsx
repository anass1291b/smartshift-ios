import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Home, 
  CalendarDays, 
  Receipt, 
  Settings, 
  Printer, 
  X, 
  User, 
  ShieldCheck, 
  Globe, 
  Bus, 
  Clock, 
  ChevronRight,
  TrendingUp,
  Sparkles,
  Sun,
  Moon,
  Laptop
} from 'lucide-react';
import { UserData, Language, ThemeMode } from '../types';
import { translations, TranslationKey } from '../translations';
import YazakiLogo from './YazakiLogo';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  onSelectTab: (tab: 'home' | 'calendar' | 'payroll' | 'settings') => void;
  userData: UserData;
  onUpdateUserData: (data: UserData) => void;
  onOpenPrint: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activeTab,
  onSelectTab,
  userData,
  onUpdateUserData,
  onOpenPrint
}) => {
  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang][key] || key;
  const isRTL = translations[lang].dir === 'rtl';

  const menuItems = [
    { 
      id: 'home', 
      label: t('home'), 
      subtitle: lang === 'ar' ? 'لوحة القيادة والمؤشرات المباشرة' : lang === 'fr' ? 'Tableau de bord & métriques en direct' : 'Dashboard & live metrics', 
      icon: Home 
    },
    { 
      id: 'calendar', 
      label: t('matrix'), 
      subtitle: lang === 'ar' ? 'الجدول الزمني وتدوير المناوبات' : lang === 'fr' ? 'Planning et rotation des équipes' : 'Shift schedule & weekly rotation', 
      icon: CalendarDays 
    },
    { 
      id: 'payroll', 
      label: t('pay'), 
      subtitle: lang === 'ar' ? 'كشف الراتب والعلاوات' : lang === 'fr' ? 'Décompte de paie & primes' : 'Payroll statement & bonuses', 
      icon: Receipt 
    },
    { 
      id: 'settings', 
      label: t('setup'), 
      subtitle: lang === 'ar' ? 'ملف المشغل والبروتوكولات' : lang === 'fr' ? 'Profil opérateur & protocoles' : 'Operator profile & settings', 
      icon: Settings 
    },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" dir={isRTL ? 'rtl' : 'ltr'}>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
          />

          {/* Drawer Panel */}
          <div className={`fixed inset-y-0 ${isRTL ? 'left-0' : 'right-0'} max-w-full flex pl-10`}>
            <motion.div
              initial={{ x: isRTL ? -360 : 360 }}
              animate={{ x: 0 }}
              exit={{ x: isRTL ? -360 : 360 }}
              transition={{ type: 'spring', damping: 28, stiffness: 280 }}
              className="w-screen max-w-sm sm:max-w-md bg-slate-900 text-white shadow-2xl flex flex-col justify-between overflow-y-auto"
            >
              {/* Header */}
              <div className="p-6 border-b border-slate-800">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-[#111217] px-3.5 py-1.5 rounded-xl border border-white/10 shadow-sm inline-flex items-center">
                    <YazakiLogo size="sm" showSubtitle={false} />
                  </div>
                  <button
                    onClick={onClose}
                    className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors active:scale-95"
                    aria-label="Close menu"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Operator Profile Card in Drawer */}
                <div className="mt-4 p-4 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-800/60 border border-slate-700/80 flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white font-black text-lg shadow-lg flex-shrink-0">
                    {userData.name ? userData.name.charAt(0).toUpperCase() : 'Y'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-white text-sm truncate">{userData.name || 'Opérateur Yazaki'}</h4>
                      <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    </div>
                    <p className="text-[11px] text-slate-400 font-medium truncate">
                      {userData.salaryType === 'hourly' 
                        ? `${userData.hourlyRate.toFixed(2)} MAD/H` 
                        : `${userData.baseSalary.toFixed(0)} MAD Base`} • Rotation {userData.shiftCycle.join(' → ')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Navigation Links */}
              <div className="px-4 py-6 space-y-2 flex-1">
                <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 px-3 mb-2">
                  Navigation
                </p>
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  const isSelected = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id as any);
                        onClose();
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl flex items-center justify-between transition-all group ${
                        isSelected 
                          ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30' 
                          : 'hover:bg-slate-800/80 text-slate-300 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300 group-hover:bg-slate-700 group-hover:text-white'
                        }`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-bold text-sm leading-tight">{item.label}</p>
                          <p className={`text-[11px] mt-0.5 ${isSelected ? 'text-purple-100' : 'text-slate-400'}`}>
                            {item.subtitle}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-500 group-hover:text-slate-300'} ${isRTL ? 'rotate-180' : ''}`} />
                    </button>
                  );
                })}

                {/* Quick Action: Export / Print */}
                <div className="pt-4 mt-4 border-t border-slate-800">
                  <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 px-3 mb-2">
                    {lang === 'ar' ? 'إجراءات سريعة' : lang === 'fr' ? 'Actions Rapides' : 'Quick Actions'}
                  </p>
                  <button
                    onClick={() => {
                      onOpenPrint();
                      onClose();
                    }}
                    className="w-full text-left p-3.5 rounded-2xl flex items-center justify-between bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-all group"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                        <Printer className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-sm">{lang === 'ar' ? 'بيان الأجرة (PDF)' : 'Bulletin de Paie (PDF)'}</p>
                        <p className="text-[11px] text-slate-400">{lang === 'ar' ? 'توليد البيان الرسمي' : 'Générer le récapitulatif officiel'}</p>
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 text-slate-500 group-hover:text-slate-300 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Theme & Language Switcher & Footer */}
              <div className="p-6 border-t border-slate-800 bg-slate-950/50 space-y-4">
                {/* Theme Selector */}
                <div>
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-2">
                    <Moon className="w-4 h-4" />
                    <span>{t('displayTheme')}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'light', label: t('themeLight'), icon: Sun },
                      { id: 'dark', label: t('themeDark'), icon: Moon },
                      { id: 'system', label: t('themeSystem'), icon: Laptop },
                    ].map((item) => {
                      const isSelected = (userData.theme || 'light') === item.id;
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => onUpdateUserData({ ...userData, theme: item.id as ThemeMode })}
                          className={`py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            isSelected
                              ? 'bg-purple-600 text-white shadow-md'
                              : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5" />
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Language Selector */}
                <div>
                  <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold mb-2">
                    <Globe className="w-4 h-4" />
                    <span>Langue du Système / Language</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {(['fr', 'ar', 'en'] as Language[]).map((l) => (
                      <button
                        key={l}
                        onClick={() => onUpdateUserData({ ...userData, language: l })}
                        className={`py-2 rounded-xl text-xs font-bold transition-all ${
                          userData.language === l
                            ? 'bg-purple-600 text-white shadow-md'
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                        }`}
                      >
                        {l === 'fr' ? 'Français' : l === 'ar' ? 'العربية' : 'English'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="text-center pt-2">
                  <p className="text-[10px] font-extrabold text-slate-300 uppercase tracking-widest">
                    Yazaki SmartShift
                  </p>
                  <p className="text-[9px] text-slate-400 mt-0.5">
                    Conforme Code du Travail Marocain (Loi 65-99)
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default NavigationDrawer;
