import React, { useState } from 'react';
import { Download, X, Building2, CheckCircle2, Check, Copy, Printer } from 'lucide-react';
import { SalaryBreakdown, UserData } from '../types';
import { formatTime13h } from '../utils/dateUtils';
import { numberToFrenchWords } from '../utils/numberToWords';

interface PayrollReportProps {
  payroll: SalaryBreakdown;
  userData: UserData;
  month: number;
  year: number;
  onClose?: () => void;
}

export const PayrollReport: React.FC<PayrollReportProps> = ({ 
  payroll, 
  userData, 
  month, 
  year, 
  onClose 
}) => {
  const monthDate = new Date(year, month, 1);
  const monthNameFr = new Intl.DateTimeFormat('fr-FR', { month: 'long' }).format(monthDate);
  const monthNameAr = new Intl.DateTimeFormat('ar-MA', { month: 'long' }).format(monthDate);
  const lastDay = new Date(year, month + 1, 0).getDate();

  const now = new Date();
  const dateEmission = now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const heureEmission = formatTime13h(now);

  const rate = userData.salaryType === 'fixed' 
    ? ((userData.baseSalary && userData.baseSalary > 0 ? userData.baseSalary : 3422.72) / 191) 
    : (userData.hourlyRate && userData.hourlyRate > 0 ? userData.hourlyRate : 17.92);

  const operatorName = userData.name?.trim() ? userData.name.toUpperCase() : 'COLLABORATEUR YAZAKI';
  const matricule = userData.matricule?.trim() 
    ? userData.matricule.toUpperCase() 
    : `YZK-${userData.name ? userData.name.slice(0, 3).toUpperCase() : 'OPR'}-${String(year).slice(-2)}${String(month + 1).padStart(2, '0')}`;

  const lang = userData.language || 'fr';
  const currencyLabel = lang === 'ar' ? 'درهم' : 'MAD';

  const formatMAD = (amount: number | undefined) => {
    return (amount ?? 0).toLocaleString('fr-FR', { 
      minimumFractionDigits: 2, 
      maximumFractionDigits: 2 
    });
  };

  // 1. Detailed Earnings Rows
  const earningsRows = [
    {
      code: '100',
      label: 'Salaire de Base (Heures normales)',
      labelAr: 'الأجر الأساسي (ساعات عادية)',
      base: `${payroll.regularHours.toFixed(1)} H`,
      taux: `${rate.toFixed(2)} DH/H`,
      gain: payroll.regularPay,
      retenue: 0
    },
    ...(payroll.overtimeHours > 0 ? [{
      code: '110',
      label: `Heures Supplémentaires (+${(userData.overtimeRate * 100).toFixed(0)}%)`,
      labelAr: 'ساعات إضافية قانونية',
      base: `${payroll.overtimeHours.toFixed(1)} H`,
      taux: `+${(userData.overtimeRate * 100).toFixed(0)}%`,
      gain: payroll.overtimeBonus,
      retenue: 0
    }] : []),
    ...(payroll.k3Hours > 0 ? [{
      code: '120',
      label: `Majoration Équipe Nuit K3 (+${(userData.k3Rate * 100).toFixed(0)}%)`,
      labelAr: 'تعويض العمل الليلي K3',
      base: `${payroll.k3Hours.toFixed(1)} H`,
      taux: `+${(userData.k3Rate * 100).toFixed(0)}%`,
      gain: payroll.k3Bonus,
      retenue: 0
    }] : []),
    ...(payroll.sundayHours > 0 ? [{
      code: '130',
      label: `Majoration Dimanches Travaillés (+${(userData.sundayRate * 100).toFixed(0)}%)`,
      labelAr: 'تعويض عمل أيام الأحد',
      base: `${payroll.sundayHours.toFixed(1)} H`,
      taux: `+${(userData.sundayRate * 100).toFixed(0)}%`,
      gain: payroll.sundayPay,
      retenue: 0
    }] : []),
    ...(payroll.holidayDaysCount > 0 ? [{
      code: '140',
      label: 'Majoration Jours Fériés Chômés Travaillés (+100%)',
      labelAr: 'تعويض الأعياد والعطل الرسمية',
      base: `${payroll.holidayDaysCount} Jour(s)`,
      taux: '+100%',
      gain: payroll.holidayWorkedBonus,
      retenue: 0
    }] : []),
    ...(payroll.seniorityBonus > 0 ? [{
      code: '200',
      label: `Prime d'Ancienneté Légale (${(userData.seniorityRate * 100).toFixed(0)}%)`,
      labelAr: 'منحة الأقدمية القانونية',
      base: formatMAD(payroll.regularPay),
      taux: `${(userData.seniorityRate * 100).toFixed(0)}%`,
      gain: payroll.seniorityBonus,
      retenue: 0
    }] : []),
    ...(payroll.attendanceBonus > 0 ? [{
      code: '210',
      label: "Prime d'Assiduité Mensuelle (Présence)",
      labelAr: 'منحة المواظبة الشهرية',
      base: 'Mensuel',
      taux: '100%',
      gain: payroll.attendanceBonus,
      retenue: 0
    }] : []),
  ];

  // Custom bonuses
  const subTotalBeforeCustom = earningsRows.reduce((acc, r) => acc + r.gain, 0);
  const customBonusRows = (userData.customPercentageBonuses || []).map((cb, idx) => ({
    code: `25${idx}`,
    label: cb.label,
    labelAr: 'منحة إضافية',
    base: cb.type === 'percentage' ? formatMAD(subTotalBeforeCustom) : 'Forfait',
    taux: cb.type === 'percentage' ? `${(cb.value * 100).toFixed(1)}%` : 'Fixe',
    gain: cb.type === 'percentage' ? subTotalBeforeCustom * cb.value : cb.value,
    retenue: 0
  }));

  // 2. Deductions Rows
  const healthRatePercent = ((userData.healthInsuranceRate !== undefined ? userData.healthInsuranceRate : 0.018) * 100).toFixed(1);
  const cnssBase = Math.min(payroll.grossTotal, 6000);

  const legalDeductionsRows = [
    {
      code: '400',
      label: 'Cotisation C.N.S.S. (Prestations Sociales - Plafond 6 000 DH)',
      labelAr: 'الصندوق الوطني للضمان الاجتماعي',
      base: formatMAD(cnssBase),
      taux: '4,48%',
      gain: 0,
      retenue: payroll.cnssDeduction
    },
    {
      code: '410',
      label: `Assurance Maladie Groupe / Mutuelle Yazaki (${healthRatePercent}%)`,
      labelAr: 'التغطية الصحية التكميلية',
      base: formatMAD(payroll.grossTotal),
      taux: `${healthRatePercent}%`,
      gain: 0,
      retenue: payroll.healthInsuranceDeduction
    }
  ];

  const coreHoursBase = payroll.regularPay + payroll.sundayPay + payroll.holidayWorkedBonus + payroll.overtimeBonus;
  const customDeductionsRows = (userData.customDeductions || []).map((cd, idx) => ({
    code: `48${idx}`,
    label: cd.label,
    labelAr: 'اقتطاع خاص',
    base: cd.type === 'percentage' ? formatMAD(coreHoursBase) : 'Forfait',
    taux: cd.type === 'percentage' ? `${(cd.value * 100).toFixed(1)}%` : 'Fixe',
    gain: 0,
    retenue: cd.type === 'percentage' ? coreHoursBase * cd.value : cd.value
  }));

  const allTableRows = [
    ...earningsRows,
    ...customBonusRows,
    ...legalDeductionsRows,
    ...customDeductionsRows
  ];

  const netInWords = numberToFrenchWords(payroll.netTotal);
  const [copied, setCopied] = useState(false);

  const handleCopySummary = () => {
    const summary = `📄 BULLETIN DE PAIE YAZAKI MAROC
Période : ${monthNameFr.toUpperCase()} ${year}
Collaborateur : ${operatorName} (${userData.matricule || matricule})
Site : ${userData.plantSite || "Zone Franche de Tanger (TFZ)"}
----------------------------------
• Heures normales : ${payroll.regularHours.toFixed(1)}h (${formatMAD(payroll.regularPay)} MAD)
• Heures de Nuit K3 : ${payroll.k3Hours.toFixed(1)}h (${formatMAD(payroll.k3Bonus)} MAD)
• Dimanches travaillés : ${payroll.sundayDaysCount} j (${formatMAD(payroll.sundayPay)} MAD)
• Fériés travaillés (+100%) : ${payroll.holidayDaysCount} j (${formatMAD(payroll.holidayWorkedBonus)} MAD)
• Prime d'Assiduité : ${formatMAD(payroll.attendanceBonus)} MAD
----------------------------------
TOTAL BRUT : ${formatMAD(payroll.grossTotal)} MAD
- CNSS (4,48%) : ${formatMAD(payroll.cnssDeduction)} MAD
- Mutuelle Groupe : ${formatMAD(payroll.healthInsuranceDeduction)} MAD
----------------------------------
NET À PAYER : ${formatMAD(payroll.netTotal)} MAD`;
    try {
      navigator.clipboard.writeText(summary);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleDownloadStandalone = () => {
    const printDoc = document.getElementById('yazaki-payslip-document');
    if (!printDoc) return;

    const htmlContent = `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Bulletin_de_Paie_Yazaki_${year}_${month + 1}_${operatorName.replace(/\s+/g, '_')}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    @page { size: A4 portrait; margin: 8mm 10mm; }
    * { box-sizing: border-box; }
    body { font-family: 'Plus Jakarta Sans', Arial, sans-serif; margin: 0; padding: 20px; background: #fff; color: #111; }
    table { width: 100%; border-collapse: collapse; font-size: 11px; }
    th, td { border: 1px solid #d1d5db; padding: 6px 8px; }
    th { background: #f3f4f6; text-align: left; font-weight: 700; text-transform: uppercase; font-size: 10px; }
    .text-right { text-align: right; }
    .text-center { text-align: center; }
    .font-bold { font-weight: 700; }
    .text-rose { color: #dc2626; }
    .border-b-2 { border-bottom: 2px solid #111; }
    .bg-dark { background: #0f172a; color: #fff; }
    @media print {
      body { padding: 0; }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  ${printDoc.innerHTML}
  <script>
    window.onload = function() {
      setTimeout(function() { window.print(); }, 400);
    };
  </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Bulletin_Paie_Yazaki_${year}_${String(month + 1).padStart(2, '0')}_${operatorName.slice(0, 15).replace(/\s+/g, '_')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Top Action Bar (hidden when printing) */}
      <div className="no-print bg-slate-900 text-white rounded-2xl p-3.5 sm:p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-extrabold text-white">
              Bulletin de Paie Officiel — {monthNameFr.toUpperCase()} {year}
            </h4>
            <p className="text-[11px] text-slate-400">
              Conforme au Code du Travail Marocain (Loi 65-99) & Standard Yazaki Maroc
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={handleCopySummary}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer border border-slate-700"
            title="Copier un résumé formaté du bulletin"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copié !' : 'Copier Résumé'}</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-white text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer border border-slate-700"
            title="Imprimer directement le bulletin de paie"
          >
            <Printer className="w-4 h-4 text-slate-300" />
            <span>Imprimer</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadStandalone}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-purple-600/30 transition-all active:scale-95 cursor-pointer"
            title="Télécharger une copie imprimable (.html)"
          >
            <Download className="w-4 h-4" />
            <span>Télécharger</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors ml-1 cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Payslip A4 Sheet Container */}
      <div 
        id="yazaki-payslip-document" 
        className="bg-white text-gray-900 border border-gray-300 sm:rounded-2xl p-4 sm:p-8 md:p-10 shadow-xl max-w-4xl mx-auto print:border-none print:shadow-none print:p-0 print:m-0 font-sans text-xs"
        style={{ colorScheme: 'light' }}
      >
        {/* 1. Official Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-4 border-b-2 border-slate-900">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl sm:text-2xl font-black tracking-tight text-red-600 uppercase">
                YAZAKI
              </span>
              <span className="text-xs font-black text-slate-900 uppercase tracking-widest px-1.5 py-0.5 bg-gray-100 rounded">
                MOROCCO S.A.
              </span>
            </div>
            <p className="text-[11px] font-bold text-gray-700 leading-snug">
              Fabrication de Câblages & Composants Électriques Automobiles
            </p>
            <p className="text-[10px] text-gray-500 leading-tight">
              {userData.plantSite || "Zone Franche d'Exportation — Tanger (TFZ)"} // Direction des Ressources Humaines
            </p>
            <p className="text-[9px] text-gray-400 mt-1">
              RC: 1827463 | Patente: 21458900 | IF: 04928172 | CNSS: 2849102 | ICE: 001529841000088
            </p>
          </div>

          <div className="bg-slate-50 border border-gray-200 rounded-xl p-3 sm:p-4 text-right min-w-[220px] w-full sm:w-auto shadow-2xs">
            <h1 className="text-sm sm:text-base font-black text-slate-900 uppercase tracking-tight">
              BULLETIN DE PAIE
            </h1>
            <p className="text-[11px] font-extrabold text-purple-700 uppercase tracking-wider mt-0.5">
              {monthNameFr} {year} <span className="text-gray-400">/</span> {monthNameAr}
            </p>
            <div className="mt-2 pt-2 border-t border-gray-200 text-[10px] text-gray-600 space-y-0.5 font-medium">
              <p>Période: <span className="font-bold text-gray-900">01/{String(month + 1).padStart(2, '0')}/{year} au {lastDay}/{String(month + 1).padStart(2, '0')}/{year}</span></p>
              <p>Réf: <span className="font-mono font-bold text-gray-900">{matricule}</span></p>
              <p>Date d'édition: <span className="font-medium text-gray-800">{dateEmission} à {heureEmission}</span></p>
            </div>
          </div>
        </div>

        {/* 2. Employee Identity Box */}
        <div className="my-4 p-3.5 sm:p-4 bg-gray-50/70 border border-gray-200 rounded-xl grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Nom & Prénom</span>
            <span className="font-extrabold text-gray-900 text-xs sm:text-sm block truncate">{operatorName}</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Fonction / Emploi</span>
            <span className="font-bold text-gray-900 block truncate">Opérateur de Câblage</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Régime de Travail</span>
            <span className="font-bold text-gray-900 block">
              {userData.shiftMode === '2shifts' ? '2 Équipes (K1/K2)' : '3 Équipes (K1/K2/K3)'}
            </span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Mode de Règlement</span>
            <span className="font-bold text-gray-900 block">Virement Bancaire</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Taux Horaire Contractuel</span>
            <span className="font-mono font-bold text-gray-900 metric-ltr tabular-nums">{rate.toFixed(2)} {lang === 'ar' ? 'درهم/س' : 'MAD/H'}</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Base Mensuelle Normale</span>
            <span className="font-bold text-gray-900 metric-ltr tabular-nums">{payroll.regularHours.toFixed(1)} H / 191 H</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Ancienneté</span>
            <span className="font-bold text-gray-900">
              {userData.seniorityRate > 0 ? `${(userData.seniorityRate * 100).toFixed(0)}%` : 'Standard'}
            </span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase tracking-wider text-gray-400 block">Statut Validation</span>
            <span className="inline-flex items-center gap-1 font-extrabold text-emerald-700 text-[10px]">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>Conforme Code du Travail</span>
            </span>
          </div>
        </div>

        {/* 3. Detailed Regulatory Payroll Table */}
        <div className="overflow-x-auto border border-gray-300 rounded-xl mb-4">
          <table className="w-full text-left border-collapse text-[11px]">
            <thead>
              <tr className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-wider">
                <th className="py-2.5 px-3 border-r border-slate-700 w-12 text-center">Code</th>
                <th className="py-2.5 px-3 border-r border-slate-700">Désignation de la Rubrique</th>
                <th className="py-2.5 px-3 border-r border-slate-700 text-center w-28">Base / Unité</th>
                <th className="py-2.5 px-3 border-r border-slate-700 text-center w-24">Taux / Formule</th>
                <th className="py-2.5 px-3 border-r border-slate-700 text-right w-28 text-emerald-300">Gains ({currencyLabel})</th>
                <th className="py-2.5 px-3 text-right w-28 text-rose-300">Retenues ({currencyLabel})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 font-medium">
              {allTableRows.map((row, idx) => (
                <tr key={idx} className={idx % 2 === 1 ? 'bg-gray-50/50' : 'bg-white'}>
                  <td className="py-2 px-3 border-r border-gray-200 text-center font-mono text-[10px] text-gray-500">
                    {row.code}
                  </td>
                  <td className="py-2 px-3 border-r border-gray-200 font-bold text-gray-900">
                    {row.label}
                  </td>
                  <td className="py-2 px-3 border-r border-gray-200 text-center font-mono text-gray-600">
                    {row.base}
                  </td>
                  <td className="py-2 px-3 border-r border-gray-200 text-center font-mono text-gray-600">
                    {row.taux}
                  </td>
                  <td className="py-2 px-3 border-r border-gray-200 text-right font-mono font-bold text-gray-900">
                    {row.gain > 0 ? formatMAD(row.gain) : '—'}
                  </td>
                  <td className="py-2 px-3 text-right font-mono font-bold text-rose-600">
                    {row.retenue > 0 ? `-${formatMAD(row.retenue)}` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 4. Totals Recap Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4 bg-gray-100/90 border border-gray-300 rounded-xl p-3 text-[11px]">
          <div>
            <span className="text-[9px] font-black uppercase text-gray-500 block">Salaire Brut Global (SBG)</span>
            <span className="text-xs sm:text-sm font-black font-mono text-gray-900 metric-ltr tabular-nums">{formatMAD(payroll.grossTotal)} {currencyLabel}</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase text-gray-500 block">Total Cotisations & Retenues</span>
            <span className="text-xs sm:text-sm font-black font-mono text-rose-600 metric-ltr tabular-nums">-{formatMAD(payroll.totalDeductions)} {currencyLabel}</span>
          </div>

          <div>
            <span className="text-[9px] font-black uppercase text-gray-500 block">Net Imposable (SNI)</span>
            <span className="text-xs sm:text-sm font-black font-mono text-gray-900 metric-ltr tabular-nums">{formatMAD(payroll.taxableSalary)} {currencyLabel}</span>
          </div>

          <div className="bg-slate-900 text-white rounded-lg p-2 text-right">
            <span className="text-[9px] font-black uppercase text-amber-400 block tracking-wider">NET À PAYER</span>
            <span className="text-sm sm:text-base font-black font-mono text-white metric-ltr tabular-nums">{formatMAD(payroll.netTotal)} {currencyLabel}</span>
          </div>
        </div>

        {/* 5. Net Amount in Words (Disbursement clause) */}
        <div className="p-3 bg-purple-50/70 border border-purple-200/80 rounded-xl mb-4 text-[11px]">
          <span className="text-[9px] font-black uppercase tracking-wider text-purple-700 block mb-0.5">
            Arrêté de Paie en Toutes Lettres
          </span>
          <p className="font-bold text-purple-950 italic">
            « Arrêté le présent bulletin de paie à la somme nette à payer de : <span className="underline decoration-purple-400 font-extrabold">{netInWords}</span> »
          </p>
        </div>

        {/* 6. Legal Notice & Signatures */}
        <div className="pt-3 border-t border-gray-200 grid grid-cols-2 gap-4 text-[10px]">
          <div className="border border-gray-200 rounded-xl p-3 h-28 flex flex-col justify-between">
            <span className="font-extrabold uppercase text-gray-600 block">
              Pour l'Employeur : YAZAKI MOROCCO S.A.
            </span>
            <div className="text-[9px] text-gray-400 italic">
              Cachet & Signature DRH // Virement ordonnancé
            </div>
          </div>

          <div className="border border-gray-200 rounded-xl p-3 h-28 flex flex-col justify-between">
            <span className="font-extrabold uppercase text-gray-600 block">
              Émargement du Salarié (« Pour acquit »)
            </span>
            <div className="text-[9px] text-gray-400 italic">
              Signature du collaborateur
            </div>
          </div>
        </div>

        {/* 7. Footer mention */}
        <div className="mt-3 text-center text-[9px] text-gray-400">
          Document établi conformément aux articles 370 et suivants du Code du Travail marocain (Loi 65-99). À conserver sans limitation de durée.
        </div>
      </div>
    </div>
  );
};

export default PayrollReport;
