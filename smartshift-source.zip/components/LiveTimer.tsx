import React, { useState, useEffect } from 'react';
import { 
  Coffee, 
  TrendingUp, 
  ArrowRight,
  Clock,
  Sparkles
} from 'lucide-react';
import { getCurrentShiftInfo } from '../services/payrollEngine';
import { SHIFT_CONFIG } from '../constants';
import { ShiftType, UserData } from '../types';
import { translations, TranslationKey } from '../translations';
import { formatTime13h, formatShiftRange13h, getShiftForDate } from '../utils/dateUtils';

interface LiveTimerProps {
  hourlyRate: number;
  userData: UserData;
  onNavigateToPlanning?: () => void;
}

export const LiveTimer: React.FC<LiveTimerProps> = ({ 
  hourlyRate, 
  userData,
  onNavigateToPlanning 
}) => {
  const [shiftInfo, setShiftInfo] = useState(() => getCurrentShiftInfo(userData));
  const [liveEarnings, setLiveEarnings] = useState(0);
  const [now, setNow] = useState(() => new Date());
  
  // Clean sequential counter ticking +1 second every second
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const lang = userData.language || 'fr';
  const isRTL = translations[lang]?.dir === 'rtl';

  const baseRate = hourlyRate > 0 ? hourlyRate : (userData.hourlyRate > 0 ? userData.hourlyRate : 17.92);

  // Update shift info ticker every 1000ms
  useEffect(() => {
    const updateTicker = () => {
      const current = new Date();
      setNow(current);
      const info = getCurrentShiftInfo(userData);
      setShiftInfo(info);
      
      if (info.active && info.type !== ShiftType.OFF) {
        const elapsedMs = Math.max(0, current.getTime() - info.start.getTime());
        const totalSec = Math.floor(elapsedMs / 1000);
        const hoursInShift = Math.min(8, Math.max(0, totalSec / 3600));
        
        let currentHourlyRate = baseRate;
        if (info.type === ShiftType.K3) currentHourlyRate += baseRate * (userData.k3Rate || 0.20);
        currentHourlyRate += currentHourlyRate * (userData.seniorityRate || 0.05);
        const customMultiplier = userData.customPercentageBonuses.reduce((acc, b) => acc + (b.type === 'percentage' ? b.value : 0), 0);
        currentHourlyRate += currentHourlyRate * customMultiplier;
        
        setLiveEarnings(hoursInShift * currentHourlyRate);
      } else {
        setLiveEarnings(0);
      }
    };

    updateTicker();
    const timer = setInterval(updateTicker, 1000);
    return () => clearInterval(timer);
  }, [baseRate, userData]);

  // Today's regular schedule roster label (e.g. 'OFF / Repos' or '06h00 - 14h00')
  const todayScheduledShift = getShiftForDate(now, userData);
  const scheduleTag = todayScheduledShift === ShiftType.OFF 
    ? 'OFF / Repos' 
    : formatShiftRange13h(todayScheduledShift);

  // Determine whether to display the Active Shift (LIVE OPS) card or Rest Phase card
  const isActuallyActive = shiftInfo.active && shiftInfo.type !== ShiftType.OFF;
  const showActiveShift = isActuallyActive;

  // --- STATE 1: REST PHASE (Screenshot 2) ---
  if (!showActiveShift) {
    // Next shift info
    const nextType = shiftInfo.nextShiftType || ShiftType.K2;
    const nextConfig = SHIFT_CONFIG[nextType];
    const nextLabel = nextConfig?.label || (nextType === ShiftType.K1 ? 'Morning' : nextType === ShiftType.K2 ? 'Afternoon' : 'Night');

    // Countdown calculation to next shift with real-time live seconds
    let diffHours = 10;
    let diffMinutes = 12;
    let diffSeconds = 0;
    if (shiftInfo.nextShiftStart) {
      const diffMs = Math.max(0, shiftInfo.nextShiftStart.getTime() - now.getTime());
      const totalDiffSec = Math.floor(diffMs / 1000);
      diffHours = Math.floor(totalDiffSec / 3600);
      diffMinutes = Math.floor((totalDiffSec % 3600) / 60);
      diffSeconds = totalDiffSec % 60;
    }

    const countdownText = lang === 'fr' 
      ? `dans ${diffHours}h ${String(diffMinutes).padStart(2, '0')}m ${String(diffSeconds).padStart(2, '0')}s`
      : lang === 'ar'
      ? `في غضون ${diffHours} س و${diffMinutes} د و${diffSeconds} ث`
      : `in ${diffHours}h ${String(diffMinutes).padStart(2, '0')}m ${String(diffSeconds).padStart(2, '0')}s`;

    return (
      <div 
        className="bg-white dark:bg-slate-900 rounded-[22px] p-4 sm:p-5 border border-gray-100/90 dark:border-slate-800 shadow-xs relative overflow-hidden transition-colors" 
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            {/* Coffee Icon Badge */}
            <div 
              className="w-11 h-11 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center flex-shrink-0 text-slate-600 dark:text-slate-300 border border-slate-200/50 dark:border-slate-700/50"
            >
              <Coffee className="w-5 h-5 text-slate-600 dark:text-slate-300" />
            </div>

            {/* Rest Phase Details */}
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm sm:text-base font-extrabold text-slate-700 dark:text-slate-200 tracking-wide uppercase leading-tight">
                  REST PHASE
                </h4>
              </div>

              <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium mt-1 leading-snug">
                <span>{lang === 'ar' ? 'الوردية القادمة : ' : 'Next Shift : '}</span>
                <span className="text-[#9333ea] dark:text-purple-400 font-bold">
                  {nextLabel} ({nextType})
                </span>
                <span className="text-slate-500 dark:text-slate-400 font-medium"> · </span>
                <span dir="ltr" className="inline-block">{scheduleTag}</span>
                <span dir="ltr" className="text-slate-400 dark:text-slate-500 font-normal tabular-nums inline-block ms-1">
                  ({countdownText})
                </span>
              </div>
            </div>
          </div>

          {/* Action button: Mon planning -> */}
          <div className="w-full sm:w-auto flex items-center justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => onNavigateToPlanning?.()}
              className="bg-purple-50 hover:bg-purple-100/90 dark:bg-purple-500/15 dark:hover:bg-purple-500/25 text-purple-700 dark:text-purple-300 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer ms-auto sm:ms-0"
            >
              <span>{lang === 'ar' ? 'جدول عملي' : lang === 'fr' ? 'Mon planning' : 'My schedule'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- STATE 2: ACTIVE SHIFT (LIVE OPS - Screenshot 1) ---
  const activeShiftType = shiftInfo.type;
  const activeConfig = SHIFT_CONFIG[activeShiftType] || SHIFT_CONFIG[ShiftType.K3];
  const activeLabel = activeConfig.label || 'Night';

  // Times calculation with seconds:
  const elapsedMs = Math.max(0, now.getTime() - shiftInfo.start.getTime());
  const totalElapsedSec = Math.floor(elapsedMs / 1000);
  const elapsedHours = Math.floor(totalElapsedSec / 3600);
  const elapsedMinutes = Math.floor((totalElapsedSec % 3600) / 60);
  const elapsedSeconds = totalElapsedSec % 60;

  const remainingMs = Math.max(0, shiftInfo.end.getTime() - now.getTime());
  const totalRemainingSec = Math.floor(remainingMs / 1000);
  const remainingHours = Math.floor(totalRemainingSec / 3600);
  const remainingMinutes = Math.floor((totalRemainingSec % 3600) / 60);
  const remainingSeconds = totalRemainingSec % 60;

  const progressPercent = Math.min(100, Math.max(0, Math.round((totalElapsedSec / (8 * 3600)) * 100)));
  
  // Live session earnings in real active mode
  const totalElapsedHours = Math.min(8, totalElapsedSec / 3600);
  let currentHourlyRate = baseRate;
  if (shiftInfo.type === ShiftType.K3) currentHourlyRate += baseRate * (userData.k3Rate || 0.20);
  currentHourlyRate += currentHourlyRate * (userData.seniorityRate || 0.05);
  const customMultiplier = userData.customPercentageBonuses.reduce((acc, b) => acc + (b.type === 'percentage' ? b.value : 0), 0);
  currentHourlyRate += currentHourlyRate * customMultiplier;
  const currentSessionEarnings = totalElapsedHours * currentHourlyRate;

  return (
    <div 
      className="bg-white dark:bg-slate-900 rounded-[22px] p-4 sm:p-5 border border-gray-100/90 dark:border-slate-800 shadow-xs relative overflow-hidden transition-colors leading-[12px]" 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Row 1: Green Indicator Dot + LIVE OPS · NIGHT (K3) [Left] and OFF / Repos [Right] */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Green dot with subtle outer ring */}
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00c48c] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#00c48c]"></span>
          </span>

          <span className="text-sm sm:text-base font-extrabold text-[#00c48c] dark:text-[#00c48c] tracking-wide uppercase leading-[12px]">
            LIVE OPS · {activeLabel.toUpperCase()} ({activeShiftType})
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span dir="ltr" className="text-xs sm:text-sm font-semibold text-slate-500 dark:text-slate-400 leading-[15px] inline-block">
            {scheduleTag}
          </span>
        </div>
      </div>

      {/* Row 2: 5h 47m 23s Elapsed [Left] and 72% [Right] */}
      <div className="flex items-center justify-between text-sm sm:text-base font-semibold text-slate-700 dark:text-slate-200 mt-2.5">
        <span dir="ltr" className="tabular-nums leading-[15px] inline-block">
          {elapsedHours}h {String(elapsedMinutes).padStart(2, '0')}m {String(elapsedSeconds).padStart(2, '0')}s {lang === 'ar' ? 'منقضية' : 'Elapsed'}
        </span>
        <span dir="ltr" className="font-extrabold text-slate-900 dark:text-white tabular-nums inline-block">{progressPercent}%</span>
      </div>

      {/* Row 3: Rounded Progress Bar (Teal / Emerald Fill) */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 sm:h-3 rounded-full overflow-hidden my-2.5 leading-[9px]">
        <div 
          className="h-full rounded-full bg-[#00c48c] dark:bg-emerald-400 transition-all duration-500"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Row 4: Trending arrow + Session earnings: +127,482 MAD [Left] and 2h 12m 37s Remaining [Right] */}
      <div className="flex items-center justify-between text-xs sm:text-sm">
        <div className="flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-[#00c48c] flex-shrink-0" />
          <span className="text-slate-500 dark:text-slate-400 font-medium text-[11px] leading-[15px]">
            {lang === 'ar' ? 'أرباح الحصة:' : 'Session earnings:'}
          </span>
          <span dir="ltr" className="font-bold text-slate-900 dark:text-white tabular-nums text-[11px] leading-[15px] inline-block">
            +{currentSessionEarnings.toLocaleString('fr-FR', { minimumFractionDigits: 3, maximumFractionDigits: 3 })} {lang === 'ar' ? 'درهم' : 'MAD'}
          </span>
        </div>

        <span dir="ltr" className="text-slate-500 dark:text-slate-400 font-medium tabular-nums text-[11px] leading-[15px] inline-block">
          {remainingHours}h {String(remainingMinutes).padStart(2, '0')}m {String(remainingSeconds).padStart(2, '0')}s {lang === 'ar' ? 'متبقية' : 'Remaining'}
        </span>
      </div>
    </div>
  );
};

export default LiveTimer;
