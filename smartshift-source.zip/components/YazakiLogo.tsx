import React from 'react';

interface YazakiLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  subtitle?: string;
  asAppIcon?: boolean;
}

export const YazakiLogo: React.FC<YazakiLogoProps> = ({ 
  className = '', 
  size = 'md',
  showSubtitle = false,
  subtitle = 'SMARTSHIFT',
  asAppIcon = false
}) => {
  const heightClass = size === 'sm' 
    ? 'h-4 sm:h-5' 
    : size === 'lg' 
    ? 'h-7 sm:h-9' 
    : size === 'xl'
    ? 'h-9 sm:h-12'
    : 'h-5 sm:h-6';

  const subtitleSizeClass = size === 'sm'
    ? 'text-[8px] tracking-[0.24em] mt-0.5'
    : size === 'lg' || size === 'xl'
    ? 'text-[11px] sm:text-[12px] tracking-[0.28em] mt-1.5'
    : 'text-[9px] sm:text-[10px] tracking-[0.26em] mt-1';

  const logoSvg = (
    <svg 
      viewBox="0 0 602.25434 94.30215" 
      xmlns="http://www.w3.org/2000/svg"
      className={`${heightClass} w-auto max-w-full overflow-visible drop-shadow-xs`}
      aria-label="YAZAKI"
    >
      <g transform="translate(-63.98816,-483.85435)">
        <g transform="matrix(0.67987825,0,0,0.67987825,73.704242,173.51501)">
          <g transform="matrix(5.1539048,0,0,5.1539048,-694.56955,-721.08885)">
            {/* Yazaki Signature Red Arrowhead Motif */}
            <g transform="matrix(1.25,0,0,-1.25,131.99286,228.47763)">
              <path 
                style={{ fill: '#ED1C24', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="M 0,0 44.242,0 41.63,-1.359 41.625,-10.514 37.24,-18.708 38.912,-21.53 0,0" 
              />
            </g>
            {/* Y Letter */}
            <g transform="matrix(1.25,0,0,-1.25,213.63286,228.47763)">
              <path 
                style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="m 0,0 -5.104,0 -3.35,-4.442 -3.348,4.442 -5.103,0 6.427,-8.514 0,-4.132 3.954,0 0,4.132 L 0,0" 
              />
            </g>
            {/* A Letter (1st) */}
            <g transform="matrix(1.25,0,0,-1.25,222.43786,232.58138)">
              <path 
                style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="m 0,0 -0.052,0 -2.388,-4.427 4.743,0 L 0,0 m -3.835,-6.994 -1.047,-2.368 -5.373,0 6.476,12.606 7.229,0 6.649,-12.606 -5.399,0 -1.029,2.368 -7.506,0" 
              />
            </g>
            {/* Z Letter */}
            <g transform="matrix(1.25,0,0,-1.25,251.76661,232.15013)">
              <path 
                style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="m 0,0 0,2.898 -13.324,0 0,-2.657 7.368,0 -7.298,-6.948 0,-3.001 13.351,0 0,2.538 -7.25,0 L 0,0" 
              />
            </g>
            {/* A Letter (2nd) */}
            <g transform="matrix(1.25,0,0,-1.25,264.91661,232.58138)">
              <path 
                style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="m 0,0 -0.052,0 -2.388,-4.427 4.743,0 L 0,0 m -3.835,-6.994 -1.047,-2.368 -5.371,0 6.476,12.606 7.228,0 6.649,-12.606 -5.399,0 -1.029,2.368 -7.507,0" 
              />
            </g>
            {/* K Letter */}
            <g transform="matrix(1.25,0,0,-1.25,289.61286,228.52763)">
              <path 
                style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
                d="m 0,0 4.875,0 -5.069,-5.185 6.323,-7.421 -5.226,0 -6.589,7.407 -0.04,-1.94 0,-5.467 -3.931,0 0,12.606 3.931,0 0,-5.199 0.04,0 L 0,0" 
              />
            </g>
            {/* I Letter */}
            <path 
              style={{ fill: 'currentColor', fillOpacity: 1, fillRule: 'nonzero', stroke: 'none' }}
              d="m 298.87786,244.28513 4.98988,0 0,-15.75875 -4.98988,0 0,15.75875 z" 
            />
          </g>
        </g>
      </g>
    </svg>
  );

  // If requested as an App Icon (Screenshot 1: Squircle app icon)
  if (asAppIcon) {
    return (
      <div className={`relative inline-flex flex-col items-center justify-center bg-[#111217] rounded-[22px] p-4 sm:p-5 shadow-2xl border border-white/10 select-none overflow-hidden ${className}`}>
        <div className="absolute inset-0 bg-radial from-white/[0.04] to-transparent pointer-events-none" />
        <div className="text-white flex items-center justify-center">
          {logoSvg}
        </div>
        <span 
          style={{ width: '49.2812px' }}
          className="text-[10px] font-extrabold tracking-[0.28em] text-white/90 uppercase mt-2 inline-block text-center truncate w-[49.2812px]"
        >
          {subtitle}
        </span>
      </div>
    );
  }

  return (
    <div className={`inline-flex flex-col items-center justify-center select-none text-slate-800 dark:text-white transition-colors ${className}`}>
      {logoSvg}
      {showSubtitle && (
        <span className={`font-black text-center text-slate-500 dark:text-slate-400 uppercase select-none ${subtitleSizeClass}`}>
          {subtitle}
        </span>
      )}
    </div>
  );
};

export default YazakiLogo;
