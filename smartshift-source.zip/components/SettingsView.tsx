import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  RotateCw, 
  Percent, 
  Gift, 
  MinusCircle, 
  Calendar, 
  Globe, 
  Check, 
  Plus, 
  Trash2, 
  Sparkles, 
  ShieldCheck, 
  Clock,
  ArrowRight,
  Sun,
  Sunset,
  Moon,
  X,
  AlertTriangle,
  Layers,
  ArrowLeftRight
} from 'lucide-react';
import { UserData, ShiftType, Language, CustomBonus, CustomDeduction } from '../types';
import { translations, TranslationKey } from '../translations';
import { cleanExpiredExceptions } from '../services/storage';
import { computeShiftCycle, getCurrentMondayISO } from '../utils/dateUtils';

interface SettingsViewProps {
  userData: UserData;
  onUpdateUserData: (data: UserData) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  userData,
  onUpdateUserData
}) => {
  // Helper to determine shiftMode
  const activeMode: '2shifts' | '3shifts' = userData.shiftMode || (userData.shiftCycle?.length === 2 ? '2shifts' : '3shifts');
  
  // Helper to determine current shift (first item of cycle, or explicit currentShift)
  const activeCurrentShift: ShiftType = userData.currentShift || userData.shiftCycle?.[0] || ShiftType.K1;

  // Local text input states for smooth typing
  const [nameInput, setNameInput] = useState(userData.name || '');
  const [hourlyInput, setHourlyInput] = useState(userData.hourlyRate.toString().replace('.', ','));
  const [baseSalaryInput, setBaseSalaryInput] = useState(userData.baseSalary.toString().replace('.', ','));
  const [attendanceInput, setAttendanceInput] = useState(userData.attendanceBonusValue.toString().replace('.', ','));
  const [healthInsuranceInput, setHealthInsuranceInput] = useState(
    ((userData.healthInsuranceRate !== undefined ? userData.healthInsuranceRate : 0.018) * 100).toString().replace('.', ',')
  );

  const cleanNumericString = (val: string) => {
    // Keep digits and at most one decimal separator (. or ,)
    let cleaned = val.replace(/[^0-9.,]/g, '');
    const firstSep = cleaned.search(/[.,]/);
    if (firstSep !== -1) {
      cleaned = cleaned.slice(0, firstSep + 1) + cleaned.slice(firstSep + 1).replace(/[.,]/g, '');
    }
    return cleaned;
  };

  const parseToNumber = (val: string) => {
    if (!val) return 0;
    const normalized = val.replace(',', '.');
    const num = parseFloat(normalized);
    return isNaN(num) ? 0 : num;
  };

  // Sync inputs ONLY when external props change to values different from current inputs
  useEffect(() => {
    setNameInput(userData.name || '');
    if (parseToNumber(hourlyInput) !== userData.hourlyRate) {
      setHourlyInput(userData.hourlyRate.toString().replace('.', ','));
    }
    if (parseToNumber(baseSalaryInput) !== userData.baseSalary) {
      setBaseSalaryInput(userData.baseSalary.toString().replace('.', ','));
    }
    if (parseToNumber(attendanceInput) !== userData.attendanceBonusValue) {
      setAttendanceInput(userData.attendanceBonusValue.toString().replace('.', ','));
    }
    const currentHealth = parseToNumber(healthInsuranceInput) / 100;
    const targetHealth = userData.healthInsuranceRate !== undefined ? userData.healthInsuranceRate : 0.018;
    if (Math.abs(currentHealth - targetHealth) > 0.0001) {
      setHealthInsuranceInput((targetHealth * 100).toString().replace('.', ','));
    }
  }, [userData.name, userData.hourlyRate, userData.baseSalary, userData.attendanceBonusValue, userData.healthInsuranceRate]);

  // Custom Bonus form state
  const [newBonusLabel, setNewBonusLabel] = useState('');
  const [newBonusType, setNewBonusType] = useState<'percentage' | 'fixed'>('fixed');
  const [newBonusValue, setNewBonusValue] = useState('');

  // Custom Deduction form state
  const [newDeductionLabel, setNewDeductionLabel] = useState('');
  const [newDeductionType, setNewDeductionType] = useState<'percentage' | 'fixed'>('fixed');
  const [newDeductionValue, setNewDeductionValue] = useState('');

  // Exception form state
  const [excStart, setExcStart] = useState('');
  const [excEnd, setExcEnd] = useState('');
  const [excShift, setExcShift] = useState<ShiftType>(ShiftType.K1);

  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang]?.[key] || key;
  const isRTL = translations[lang]?.dir === 'rtl';

  // Handlers for Shift Mode & Current Shift Selection (Immediately saved)
  const handleSelectShiftMode = (mode: '2shifts' | '3shifts') => {
    let targetCurrentShift = activeCurrentShift;
    if (mode === '2shifts' && targetCurrentShift === ShiftType.K3) {
      targetCurrentShift = ShiftType.K1;
    }
    const newCycle = computeShiftCycle(mode, targetCurrentShift);
    onUpdateUserData({
      ...userData,
      shiftMode: mode,
      currentShift: targetCurrentShift,
      shiftCycle: newCycle,
      cycleAnchorMonday: getCurrentMondayISO(),
      currentWeekIndex: 0
    });
  };

  const handleSelectCurrentShift = (chosenShift: ShiftType) => {
    const targetMode = chosenShift === ShiftType.K3 ? '3shifts' : activeMode;
    const newCycle = computeShiftCycle(targetMode, chosenShift);
    onUpdateUserData({
      ...userData,
      shiftMode: targetMode,
      currentShift: chosenShift,
      shiftCycle: newCycle,
      cycleAnchorMonday: getCurrentMondayISO(),
      currentWeekIndex: 0
    });
  };

  // Custom Bonus handlers
  const handleAddBonus = () => {
    if (!newBonusLabel.trim()) return;
    const numVal = parseToNumber(newBonusValue);
    if (numVal <= 0) return;

    const newBonus: CustomBonus = {
      id: Date.now().toString(),
      label: newBonusLabel.trim(),
      type: newBonusType,
      value: newBonusType === 'percentage' ? numVal / 100 : numVal
    };

    onUpdateUserData({
      ...userData,
      customPercentageBonuses: [...(userData.customPercentageBonuses || []), newBonus]
    });

    setNewBonusLabel('');
    setNewBonusValue('');
  };

  const handleRemoveBonus = (id: string) => {
    onUpdateUserData({
      ...userData,
      customPercentageBonuses: (userData.customPercentageBonuses || []).filter(b => b.id !== id)
    });
  };

  // Custom Deduction handlers
  const handleAddDeduction = () => {
    if (!newDeductionLabel.trim()) return;
    const numVal = parseToNumber(newDeductionValue);
    if (numVal <= 0) return;

    const newDed: CustomDeduction = {
      id: Date.now().toString(),
      label: newDeductionLabel.trim(),
      type: newDeductionType,
      value: newDeductionType === 'percentage' ? numVal / 100 : numVal
    };

    onUpdateUserData({
      ...userData,
      customDeductions: [...(userData.customDeductions || []), newDed]
    });

    setNewDeductionLabel('');
    setNewDeductionValue('');
  };

  const handleRemoveDeduction = (id: string) => {
    onUpdateUserData({
      ...userData,
      customDeductions: (userData.customDeductions || []).filter(d => d.id !== id)
    });
  };

  // Exception handlers
  const handleApplyExceptions = () => {
    if (!excStart || !excEnd) {
      alert(lang === 'ar' ? 'يرجى تحديد تواريخ البداية والنهاية' : lang === 'fr' ? 'Veuillez sélectionner les dates' : 'Please select start and end dates');
      return;
    }
    const start = new Date(excStart);
    const end = new Date(excEnd);
    const next = { ...cleanExpiredExceptions(userData.shiftExceptions) };

    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const iso = d.toISOString().split('T')[0];
      next[iso] = excShift;
    }

    onUpdateUserData({
      ...userData,
      shiftExceptions: cleanExpiredExceptions(next)
    });

    setExcStart('');
    setExcEnd('');
  };

  // Clean active exceptions
  const activeExceptions = cleanExpiredExceptions(userData.shiftExceptions || {});

  // Compute active sequence for display
  const activeCycle = userData.shiftCycle && userData.shiftCycle.length > 0
    ? userData.shiftCycle
    : (activeMode === '2shifts' ? [ShiftType.K1, ShiftType.K2] : [ShiftType.K1, ShiftType.K3, ShiftType.K2]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className="space-y-4 sm:space-y-6 pb-20" 
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* 1. Language Configuration */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-5 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-gray-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-100 dark:border-indigo-500/20">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'لغة النظام' : lang === 'fr' ? "Langue de l'Application" : 'System Language'}
            </h3>
            <p className="text-xs text-gray-400 dark:text-slate-400 font-medium">
              {lang === 'ar' ? 'اختر اللغة المفضلة للواجهة' : lang === 'fr' ? 'Choisissez la langue de l’interface' : 'Choose interface display language'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {(['fr', 'ar', 'en'] as Language[]).map((l) => (
            <button
              key={l}
              type="button"
              onClick={() => onUpdateUserData({ ...userData, language: l })}
              className={`py-3 px-3 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                lang === l
                  ? 'bg-slate-900 dark:bg-purple-600 text-white border-slate-900 dark:border-purple-600 shadow-xs'
                  : 'bg-gray-50 dark:bg-slate-800/80 text-gray-700 dark:text-slate-300 border-gray-200 dark:border-slate-700 hover:bg-gray-100 dark:hover:bg-slate-800 hover:border-gray-300 dark:hover:border-slate-600'
              }`}
            >
              <span className="text-xs font-extrabold">
                {l === 'fr' ? 'Français' : l === 'ar' ? 'العربية' : 'English'}
              </span>
              <span className={`text-[10px] ${lang === l ? 'text-slate-300 dark:text-purple-100' : 'text-gray-400 dark:text-slate-500'}`}>
                {l === 'fr' ? 'Par défaut' : l === 'ar' ? 'عربي' : 'Default'}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Operator Profile & Identity */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-5 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-gray-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center border border-purple-100 dark:border-purple-500/20">
            <User className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'الملف الشخصي للمشغل' : lang === 'fr' ? 'Profil Opérateur Yazaki' : 'Operator Profile'}
            </h3>
            <p className="text-xs text-gray-400 dark:text-slate-400 font-medium">
              {lang === 'ar' ? 'المعلومات الشخصية ونظام الأجور' : lang === 'fr' ? 'Informations & contrat de travail' : 'Identity & wage contract'}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
              {lang === 'ar' ? 'اسم المشغل' : lang === 'fr' ? 'Nom du Collaborateur' : 'Operator Full Name'}
            </label>
            <input
              type="text"
              id="operator_full_name_input"
              name="operator_full_name_no_suggest"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
              value={nameInput}
              onChange={(e) => {
                setNameInput(e.target.value);
                onUpdateUserData({ ...userData, name: e.target.value });
              }}
              placeholder={lang === 'ar' ? 'أدخل اسم المشغل' : lang === 'fr' ? 'Saisir le nom du collaborateur' : 'Enter operator full name'}
              className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>

          {/* Salary Protocol Selector */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
              {lang === 'ar' ? 'نوع الأجر' : lang === 'fr' ? 'Structure de Rémunération' : 'Compensation Scheme'}
            </label>
            <div className="grid grid-cols-2 gap-2 bg-gray-100 dark:bg-slate-800 p-1 rounded-2xl">
              <button
                type="button"
                onClick={() => onUpdateUserData({ ...userData, salaryType: 'hourly' })}
                className={`py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  userData.salaryType === 'hourly'
                    ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-sm'
                    : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                {lang === 'ar' ? 'سعر بالساعة' : lang === 'fr' ? 'Taux Horaire' : 'Hourly Rate'}
              </button>
              <button
                type="button"
                onClick={() => onUpdateUserData({ ...userData, salaryType: 'fixed' })}
                className={`py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  userData.salaryType === 'fixed'
                    ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-sm'
                    : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                {lang === 'ar' ? 'راتب شهري ثابت' : lang === 'fr' ? 'Salaire Fixe Mensuel' : 'Fixed Monthly'}
              </button>
            </div>
          </div>

          {/* Wage Amount Input */}
          {userData.salaryType === 'hourly' ? (
            <div>
              <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                {lang === 'ar' ? 'السعر بالساعة (درهم/ساعة)' : lang === 'fr' ? 'Taux Horaire Contractuel' : 'Hourly Base Rate'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  inputMode="decimal"
                  dir="ltr"
                  value={hourlyInput}
                  placeholder="17,92"
                  onChange={(e) => {
                    const cleaned = cleanNumericString(e.target.value);
                    setHourlyInput(cleaned);
                    if (cleaned !== '' && !cleaned.endsWith('.') && !cleaned.endsWith(',')) {
                      onUpdateUserData({ ...userData, hourlyRate: parseToNumber(cleaned) });
                    }
                  }}
                  onBlur={() => {
                    const num = parseToNumber(hourlyInput);
                    onUpdateUserData({ ...userData, hourlyRate: num });
                  }}
                  className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-black text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-16 transition-colors tabular-nums metric-ltr"
                />
                <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-black text-gray-400 dark:text-slate-500 pointer-events-none">
                  {lang === 'ar' ? 'درهم/س' : 'MAD/H'}
                </span>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                {lang === 'ar' ? 'الراتب الأساسي (درهم)' : lang === 'fr' ? 'Salaire de Base Mensuel' : 'Monthly Base Salary'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  inputMode="decimal"
                  dir="ltr"
                  value={baseSalaryInput}
                  placeholder="3422,72"
                  onChange={(e) => {
                    const cleaned = cleanNumericString(e.target.value);
                    setBaseSalaryInput(cleaned);
                    if (cleaned !== '' && !cleaned.endsWith('.') && !cleaned.endsWith(',')) {
                      onUpdateUserData({ ...userData, baseSalary: parseToNumber(cleaned) });
                    }
                  }}
                  onBlur={() => {
                    const num = parseToNumber(baseSalaryInput);
                    onUpdateUserData({ ...userData, baseSalary: num });
                  }}
                  className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-black text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-14 transition-colors tabular-nums metric-ltr"
                />
                <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-black text-gray-400 dark:text-slate-500 pointer-events-none">
                  {lang === 'ar' ? 'درهم' : 'MAD'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Shift Configuration - 2 vs 3 Shifts & Current Shift Selection */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm space-y-3.5 transition-colors">
        <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-gray-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-50 dark:bg-sky-500/10 text-sky-600 dark:text-sky-400 flex items-center justify-center border border-sky-100 dark:border-sky-500/20 flex-shrink-0">
              <RotateCw className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-gray-900 dark:text-white">
                {lang === 'ar' ? 'نظام وتناوب الفرق' : lang === 'fr' ? 'Régime & Poste Actuel' : 'Shift System & Current Shift'}
              </h3>
              <p className="text-[11px] text-gray-400 dark:text-slate-400">
                {lang === 'ar' ? 'اختر نظام العمل (2 أو 3 مناوبات) ومناوبة هذا الأسبوع' : lang === 'fr' ? 'Choisissez le régime (2 ou 3 équipes) et votre poste actuel' : 'Choose shift mode (2 or 3 shifts) and current shift'}
              </p>
            </div>
          </div>

          <span className="text-[11px] font-black px-2 py-0.5 rounded-lg bg-sky-50 dark:bg-sky-500/10 text-sky-700 dark:text-sky-300 border border-sky-100 dark:border-sky-500/20">
            {activeCycle.join(' ➔ ')}
          </span>
        </div>

        {/* 2 Shifts vs 3 Shifts Mode Selector */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
            {lang === 'ar' ? 'نظام العمل في المعمل' : lang === 'fr' ? 'Régime de Travail' : 'Shift System'}
          </label>
          <div className="grid grid-cols-2 gap-1.5 bg-gray-100 dark:bg-slate-800 p-1 rounded-xl relative">
            <motion.button
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={() => handleSelectShiftMode('2shifts')}
              className={`py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeMode === '2shifts'
                  ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-xs ring-1 ring-black/5 dark:ring-white/10'
                  : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              {lang === 'ar' ? 'مناوبتان (2x8 : K1 & K2)' : lang === 'fr' ? '2 Équipes (2x8 : K1 & K2)' : '2 Shifts (2x8)'}
            </motion.button>
            <motion.button
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={() => handleSelectShiftMode('3shifts')}
              className={`py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${
                activeMode === '3shifts'
                  ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-xs ring-1 ring-black/5 dark:ring-white/10'
                  : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              {lang === 'ar' ? '3 مناوبات (3x8 : K1, K3 & K2)' : lang === 'fr' ? '3 Équipes (3x8 : K1, K3 & K2)' : '3 Shifts (3x8)'}
            </motion.button>
          </div>
        </div>

        {/* Compact Current Shift Buttons: K1, K2, (K3 if 3shifts) */}
        <div>
          <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
            {lang === 'ar' ? 'المناوبة الحالية (هذا الأسبوع)' : lang === 'fr' ? 'Poste Actuel (Cette Semaine)' : 'Current Shift (This Week)'}
          </label>
          <div className={`grid gap-2 ${activeMode === '2shifts' ? 'grid-cols-2' : 'grid-cols-3'}`}>
            {[
              { shift: ShiftType.K1, label: 'K1', icon: Sun },
              { shift: ShiftType.K2, label: 'K2', icon: Sunset },
              ...(activeMode === '3shifts' ? [{ shift: ShiftType.K3, label: 'K3', icon: Moon }] : [])
            ].map((item) => {
              const isSelected = activeCurrentShift === item.shift;
              const Icon = item.icon;
              return (
                <motion.button
                  key={item.shift}
                  type="button"
                  whileHover={{ scale: 1.03, y: -1 }}
                  whileTap={{ scale: 0.93 }}
                  transition={{ type: "spring", stiffness: 450, damping: 25 }}
                  onClick={() => handleSelectCurrentShift(item.shift)}
                  className={`h-10 sm:h-11 px-3 rounded-xl border text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 dark:bg-purple-600 text-white border-slate-900 dark:border-purple-600 shadow-xs ring-2 ring-slate-900/10 dark:ring-purple-500/20'
                      : 'bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-200 border-gray-200 dark:border-slate-700'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-sky-400' : 'text-gray-400 dark:text-slate-500'}`} />
                  <span>{item.label}</span>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Compact Automatic Rotation Flow */}
        <div className="bg-gray-50/80 dark:bg-slate-800/60 rounded-xl p-2.5 border border-gray-200/70 dark:border-slate-700/60">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-sky-600 dark:text-sky-400" />
              <span>{lang === 'ar' ? 'التناوب التلقائي' : lang === 'fr' ? 'Rotation Automatique' : 'Auto Rotation'}</span>
            </span>
            <span className="text-[10px] font-bold text-gray-400 dark:text-slate-400">
              {activeMode === '2shifts'
                ? (lang === 'ar' ? 'تكرار كل أسبوعين' : lang === 'fr' ? 'Cycle 2 semaines' : '2-week cycle')
                : (lang === 'ar' ? 'تناوب كل 3 أسابيع' : lang === 'fr' ? 'Cycle 3 semaines' : '3-week cycle')}
            </span>
          </div>

          <div className={`grid gap-1.5 ${activeMode === '2shifts' ? 'grid-cols-2' : 'grid-cols-3'}`}>
            {activeCycle.map((s, idx) => {
              const isCurrent = idx === 0;
              const weekLabel = idx === 0
                ? (lang === 'ar' ? 'الحالي' : lang === 'fr' ? 'Actuel' : 'Current')
                : idx === 1
                ? (lang === 'ar' ? '+1 أسبوع' : lang === 'fr' ? 'Sem. +1' : 'Wk +1')
                : (lang === 'ar' ? '+2 أسبوع' : lang === 'fr' ? 'Sem. +2' : 'Wk +2');

              return (
                <div
                  key={idx}
                  className={`py-1 px-1.5 rounded-lg border text-center flex items-center justify-center gap-1.5 ${
                    isCurrent
                      ? 'bg-white dark:bg-slate-700 border-sky-300 dark:border-sky-500 shadow-2xs'
                      : 'bg-white/60 dark:bg-slate-800 border-gray-200 dark:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-semibold text-gray-400 dark:text-slate-400">
                    {weekLabel}:
                  </span>
                  <span className={`text-[11px] font-black px-1.5 py-0.5 rounded ${
                    s === ShiftType.K1 ? 'bg-purple-100 dark:bg-purple-500/20 text-purple-800 dark:text-purple-300' :
                    s === ShiftType.K2 ? 'bg-sky-100 dark:bg-sky-500/20 text-sky-800 dark:text-sky-300' :
                    'bg-amber-100 dark:bg-amber-500/20 text-amber-800 dark:text-amber-300'
                  }`}>
                    {s}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Statutory Premium Multipliers */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-5 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-gray-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-100 dark:border-amber-500/20">
            <Percent className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'نسب العلاوات والتعويضات' : lang === 'fr' ? 'Majorations Légales & Primes' : 'Statutory Premium Rates'}
            </h3>
            <p className="text-xs text-gray-400 dark:text-slate-400 font-medium">
              {lang === 'ar' ? 'نسب الليل والأقدمية والساعات الإضافية' : lang === 'fr' ? 'Pourcentages conformes Yazaki Maroc' : 'Morocco manufacturing scale'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Seniority */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              {lang === 'ar' ? 'الأقدمية' : lang === 'fr' ? "Prime d'Ancienneté" : 'Seniority Rate'}
            </label>
            <div className="relative">
              <input
                type="number"
                dir="ltr"
                value={Math.round((userData.seniorityRate || 0.05) * 100)}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  onUpdateUserData({ ...userData, seniorityRate: val / 100 });
                }}
                className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-10 transition-colors tabular-nums"
              />
              <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">%</span>
            </div>
          </div>

          {/* K3 Night */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              {lang === 'ar' ? 'علاوة الليل (K3)' : lang === 'fr' ? 'Prime Nuit (K3)' : 'K3 Night Premium'}
            </label>
            <div className="relative">
              <input
                type="number"
                dir="ltr"
                value={Math.round((userData.k3Rate || 0.20) * 100)}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  onUpdateUserData({ ...userData, k3Rate: val / 100 });
                }}
                className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-10 transition-colors tabular-nums"
              />
              <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">%</span>
            </div>
          </div>

          {/* Overtime */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              {lang === 'ar' ? 'الساعات الإضافية' : lang === 'fr' ? 'Heures Supplémentaires' : 'Overtime Rate'}
            </label>
            <div className="relative">
              <input
                type="number"
                dir="ltr"
                value={Math.round((userData.overtimeRate || 0.25) * 100)}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  onUpdateUserData({ ...userData, overtimeRate: val / 100 });
                }}
                className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-10 transition-colors tabular-nums"
              />
              <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">%</span>
            </div>
          </div>

          {/* Sunday */}
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              {lang === 'ar' ? 'علاوة الأحد' : lang === 'fr' ? 'Majoration Dimanche' : 'Sunday Rate'}
            </label>
            <div className="relative">
              <input
                type="number"
                dir="ltr"
                value={Math.round((userData.sundayRate || 1.00) * 100)}
                onChange={(e) => {
                  const val = parseFloat(e.target.value) || 0;
                  onUpdateUserData({ ...userData, sundayRate: val / 100 });
                }}
                className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-10 transition-colors tabular-nums"
              />
              <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">%</span>
            </div>
          </div>
        </div>

        {/* Attendance Bonus */}
        <div className="mt-4 pt-4 border-t border-gray-100 dark:border-slate-800">
          <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
            {lang === 'ar' ? 'منحة المواظبة الشهرية (درهم)' : lang === 'fr' ? "Prime d'Assiduité Mensuelle" : 'Attendance Monthly Reward'}
          </label>
          <div className="relative">
            <input
              type="text"
              inputMode="decimal"
              dir="ltr"
              value={attendanceInput}
              onChange={(e) => {
                const cleaned = cleanNumericString(e.target.value);
                setAttendanceInput(cleaned);
                if (cleaned !== '' && !cleaned.endsWith('.') && !cleaned.endsWith(',')) {
                  onUpdateUserData({ ...userData, attendanceBonusValue: parseToNumber(cleaned) });
                }
              }}
              onBlur={() => {
                const num = parseToNumber(attendanceInput);
                onUpdateUserData({ ...userData, attendanceBonusValue: num });
              }}
              className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-14 transition-colors tabular-nums metric-ltr"
            />
            <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">
              {lang === 'ar' ? 'درهم' : 'MAD'}
            </span>
          </div>
        </div>

        {/* Custom Bonuses Management */}
        <div className="mt-5 pt-4 border-t border-gray-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xs font-bold text-gray-900 dark:text-white">
                {lang === 'ar' ? 'المنح والمكافآت الإضافية المخصصة' : lang === 'fr' ? 'Primes & Gratifications Personnalisées' : 'Custom Bonuses & Allowances'}
              </p>
              <p className="text-[11px] text-gray-400 dark:text-slate-400">
                {lang === 'ar' ? 'منحة السلة، الإنتاجية، منحة النقل...' : lang === 'fr' ? 'Prime de panier, prime de rendement, etc.' : 'Basket, productivity, or transport allowance'}
              </p>
            </div>
            <div className="w-7 h-7 rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Gift className="w-4 h-4" />
            </div>
          </div>

          {/* List of Custom Bonuses */}
          {userData.customPercentageBonuses && userData.customPercentageBonuses.length > 0 && (
            <div className="space-y-2 mb-3">
              {userData.customPercentageBonuses.map((bonus) => (
                <div
                  key={bonus.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-800/40 text-xs font-bold text-gray-800 dark:text-slate-200"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>{bonus.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-500/20 text-amber-800 dark:text-amber-300 text-[11px] font-extrabold metric-ltr tabular-nums">
                      {bonus.type === 'percentage' ? `+${(bonus.value * 100).toFixed(1)}%` : `+${bonus.value} ${lang === 'ar' ? 'درهم' : 'MAD'}`}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleRemoveBonus(bonus.id)}
                      className="text-gray-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 p-1 transition-colors cursor-pointer"
                      title={lang === 'ar' ? 'حذف' : 'Supprimer'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add Custom Bonus Form */}
          <div className="p-3 bg-gray-50/80 dark:bg-slate-800/60 rounded-xl border border-gray-200/80 dark:border-slate-700 space-y-2.5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                placeholder={lang === 'ar' ? 'اسم المكافأة (مثال: منحة السلة)' : lang === 'fr' ? 'Nom de la prime (ex: Panier)' : 'Bonus name'}
                value={newBonusLabel}
                onChange={(e) => setNewBonusLabel(e.target.value)}
                className="w-full bg-white dark:bg-slate-700/80 border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:border-amber-500"
              />
              <div className="flex items-center gap-2">
                <div className="flex rounded-lg bg-gray-200 dark:bg-slate-700 p-0.5 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setNewBonusType('fixed')}
                    className={`px-2.5 py-1.5 rounded-md transition-all cursor-pointer ${
                      newBonusType === 'fixed' ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-xs' : 'text-gray-600 dark:text-slate-300'
                    }`}
                  >
                    {lang === 'ar' ? 'درهم' : 'MAD'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewBonusType('percentage')}
                    className={`px-2.5 py-1.5 rounded-md transition-all cursor-pointer ${
                      newBonusType === 'percentage' ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-xs' : 'text-gray-600 dark:text-slate-300'
                    }`}
                  >
                    %
                  </button>
                </div>
                <input
                  type="text"
                  inputMode="decimal"
                  placeholder={newBonusType === 'fixed' ? '200' : '5'}
                  value={newBonusValue}
                  onChange={(e) => setNewBonusValue(cleanNumericString(e.target.value))}
                  className="w-full bg-white dark:bg-slate-700/80 border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
            <button
              type="button"
              onClick={handleAddBonus}
              disabled={!newBonusLabel.trim() || !newBonusValue.trim()}
              className="w-full py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 shadow-xs active:scale-98 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'إضافة المكافأة' : lang === 'fr' ? 'Ajouter la prime' : 'Add Bonus'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5. Assurance Maladie Privée & Cotisations Sociales */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-5 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-gray-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-100 dark:border-rose-500/20">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'التغطية الصحية الخاصة والاقتطاعات' : lang === 'fr' ? 'Assurance Maladie Privée & Déductions' : 'Private Health & Deductions'}
            </h3>
            <p className="text-xs text-gray-400 dark:text-slate-400 font-medium">
              {lang === 'ar' ? 'تأمين خاص للشركة (1.8%)، CNSS (4.48%) والاقتطاعات المخصصة' : lang === 'fr' ? 'Contrat groupe entreprise (1.8%), CNSS & retenues' : 'Company group insurance (1.8%), CNSS & custom deductions'}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              {lang === 'ar' ? 'نسبة اقتطاع التأمين الصحي الخاص (%)' : lang === 'fr' ? "Taux de Cotisation d'Assurance Privée (%)" : 'Private Insurance Deduction Rate (%)'}
            </label>
            <div className="relative">
              <input
                type="text"
                inputMode="decimal"
                dir="ltr"
                value={healthInsuranceInput}
                onChange={(e) => {
                  const cleaned = cleanNumericString(e.target.value);
                  setHealthInsuranceInput(cleaned);
                  const parsedVal = parseToNumber(cleaned);
                  onUpdateUserData({ ...userData, healthInsuranceType: 'private', healthInsuranceRate: parsedVal / 100 });
                }}
                className="w-full bg-gray-50/70 dark:bg-slate-800/80 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm font-bold text-gray-900 dark:text-white focus:outline-none focus:border-purple-500 pe-10 transition-colors tabular-nums"
              />
              <span className="absolute end-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400 dark:text-slate-500 pointer-events-none">%</span>
            </div>
            <p className="text-[11px] text-gray-400 dark:text-slate-400 mt-1">
              {lang === 'ar' ? 'المعدل المعتمد للشركة: 1.8% من قاعدة الأجر الخاضعة للاقتطاع.' : lang === 'fr' ? "Taux groupe entreprise appliqué : 1,8% sur la base cotisable." : 'Default company group rate: 1.8% on core wages.'}
            </p>
          </div>

          {/* Custom Deductions Management */}
          <div className="pt-4 border-t border-gray-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs font-bold text-gray-900 dark:text-white">
                  {lang === 'ar' ? 'الاقتطاعات والخصومات المخصصة' : lang === 'fr' ? 'Déductions & Retenues Personnalisées' : 'Custom Deductions'}
                </p>
                <p className="text-[11px] text-gray-400 dark:text-slate-400">
                  {lang === 'ar' ? 'تسبيق على الأجر، مساهمة صندوق، اقتطاعات أخرى...' : lang === 'fr' ? 'Avance sur salaire, cotisation association, etc.' : 'Salary advance, association fee, etc.'}
                </p>
              </div>
              <div className="w-7 h-7 rounded-lg bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center">
                <MinusCircle className="w-4 h-4" />
              </div>
            </div>

            {/* List of Custom Deductions */}
            {userData.customDeductions && userData.customDeductions.length > 0 && (
              <div className="space-y-2 mb-3">
                {userData.customDeductions.map((ded) => (
                  <div
                    key={ded.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-800/40 text-xs font-bold text-gray-800 dark:text-slate-200"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-rose-500" />
                      <span>{ded.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-rose-100 dark:bg-rose-500/20 text-rose-800 dark:text-rose-300 text-[11px] font-extrabold metric-ltr tabular-nums">
                        {ded.type === 'percentage' ? `-${(ded.value * 100).toFixed(1)}%` : `-${ded.value} ${lang === 'ar' ? 'درهم' : 'MAD'}`}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveDeduction(ded.id)}
                        className="text-gray-400 dark:text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 p-1 transition-colors cursor-pointer"
                        title={lang === 'ar' ? 'حذف' : 'Supprimer'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add Custom Deduction Form */}
            <div className="p-3 bg-gray-50/80 dark:bg-slate-800/60 rounded-xl border border-gray-200/80 dark:border-slate-700 space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder={lang === 'ar' ? 'اسم الاقتطاع (مثال: تسبيق)' : lang === 'fr' ? 'Nom de la retenue (ex: Avance)' : 'Deduction name'}
                  value={newDeductionLabel}
                  onChange={(e) => setNewDeductionLabel(e.target.value)}
                  className="w-full bg-white dark:bg-slate-700/80 border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:border-rose-500"
                />
                <div className="flex items-center gap-2">
                  <div className="flex rounded-lg bg-gray-200 dark:bg-slate-700 p-0.5 text-[11px] font-bold">
                    <button
                      type="button"
                      onClick={() => setNewDeductionType('fixed')}
                      className={`px-2.5 py-1.5 rounded-md transition-all cursor-pointer ${
                        newDeductionType === 'fixed' ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-xs' : 'text-gray-600 dark:text-slate-300'
                      }`}
                    >
                      {lang === 'ar' ? 'درهم' : 'MAD'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewDeductionType('percentage')}
                      className={`px-2.5 py-1.5 rounded-md transition-all cursor-pointer ${
                        newDeductionType === 'percentage' ? 'bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-xs' : 'text-gray-600 dark:text-slate-300'
                      }`}
                    >
                      %
                    </button>
                  </div>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder={newDeductionType === 'fixed' ? '150' : '2'}
                    value={newDeductionValue}
                    onChange={(e) => setNewDeductionValue(cleanNumericString(e.target.value))}
                    className="w-full bg-white dark:bg-slate-700/80 border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-xs font-bold text-gray-900 dark:text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>
              <button
                type="button"
                onClick={handleAddDeduction}
                disabled={!newDeductionLabel.trim() || !newDeductionValue.trim()}
                className="w-full py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 shadow-xs active:scale-98 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? 'إضافة الاقتطاع' : lang === 'fr' ? 'Ajouter la retenue' : 'Add Deduction'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 6. Shift Exceptions & Overrides Manager (Auto-cleaning expired exceptions) */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-5 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        <div className="flex items-center gap-3 pb-4 mb-4 border-b border-gray-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center border border-purple-100 dark:border-purple-500/20">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'استثناءات المناوبات' : lang === 'fr' ? 'Exceptions de Planning' : 'Shift Exceptions'}
            </h3>
            <p className="text-xs text-gray-400 dark:text-slate-400 font-medium">
              {lang === 'ar' ? 'تعديل مناوبة لفترة معينة (تحذف تلقائياً فور انقضائها)' : lang === 'fr' ? 'Affectation temporaire (supprimée automatiquement après expiration)' : 'Temporary overrides (auto-purged after expiry)'}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 mb-1">
                {lang === 'ar' ? 'من:' : lang === 'fr' ? 'Date début :' : 'Start Date:'}
              </label>
              <input
                type="date"
                value={excStart}
                onChange={(e) => setExcStart(e.target.value)}
                className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-gray-500 dark:text-slate-400 mb-1">
                {lang === 'ar' ? 'إلى:' : lang === 'fr' ? 'Date fin :' : 'End Date:'}
              </label>
              <input
                type="date"
                value={excEnd}
                onChange={(e) => setExcEnd(e.target.value)}
                className="w-full bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5 pt-1">
            {[ShiftType.K1, ShiftType.K2, ...(activeMode === '3shifts' ? [ShiftType.K3] : []), ShiftType.OFF].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setExcShift(s)}
                className={`flex-1 py-2 rounded-xl text-xs font-black border transition-all cursor-pointer ${
                  excShift === s
                    ? 'bg-slate-900 dark:bg-purple-600 text-white border-slate-900 dark:border-purple-600 shadow-sm'
                    : 'bg-gray-50 dark:bg-slate-800 text-gray-700 dark:text-slate-200 border-gray-200 dark:border-slate-700 hover:bg-gray-100 dark:hover:bg-slate-700'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleApplyExceptions}
            className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
          >
            {lang === 'ar' ? 'تطبيق الاستثناءات' : lang === 'fr' ? 'Appliquer les exceptions' : 'Apply Exceptions'}
          </button>

          {/* Active Exceptions List */}
          {Object.keys(activeExceptions).length > 0 && (
            <div className="pt-3 border-t border-gray-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-gray-500 dark:text-slate-400">
                  {lang === 'ar' ? 'الاستثناءات السارية' : lang === 'fr' ? 'Exceptions Actives' : 'Active Exceptions'}
                </span>
                <button
                  type="button"
                  onClick={() => onUpdateUserData({ ...userData, shiftExceptions: {} })}
                  className="text-[11px] font-bold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
                >
                  {lang === 'ar' ? 'مسح الكل' : lang === 'fr' ? 'Effacer tout' : 'Clear All'}
                </button>
              </div>

              <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                {Object.entries(activeExceptions).sort().map(([date, s]) => (
                  <div
                    key={date}
                    className="flex items-center justify-between p-2 rounded-lg bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 text-xs font-bold"
                  >
                    <span className="text-gray-700 dark:text-slate-200">{date}</span>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${
                        s === ShiftType.K1 ? 'bg-purple-100 dark:bg-purple-500/20 text-purple-700 dark:text-purple-300' :
                        s === ShiftType.K2 ? 'bg-sky-100 dark:bg-sky-500/20 text-sky-700 dark:text-sky-300' :
                        s === ShiftType.K3 ? 'bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-300' :
                        'bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-slate-300'
                      }`}>
                        {s}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const next = { ...activeExceptions };
                          delete next[date];
                          onUpdateUserData({ ...userData, shiftExceptions: next });
                        }}
                        className="text-rose-500 hover:text-rose-700 dark:hover:text-rose-400 px-1 cursor-pointer"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

    </motion.div>
  );
};

export default SettingsView;
