import React, { useState } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'framer-motion';
import { 
  CheckCircle2, 
  Clock, 
  Moon, 
  Award, 
  Calendar, 
  TrendingUp, 
  Receipt, 
  ShieldCheck, 
  AlertCircle, 
  Printer, 
  FileText,
  ChevronDown
} from 'lucide-react';
import { SalaryBreakdown, UserData, ShiftType } from '../types';
import { translations, TranslationKey } from '../translations';
import { getShiftForDate } from '../utils/dateUtils';

interface EarningsDetailsProps {
  payroll: SalaryBreakdown;
  userData: UserData;
  onOpenPrint?: () => void;
}

type FilterType = 'all' | 'in_progress' | 'validated';

export const EarningsDetails: React.FC<EarningsDetailsProps> = ({ 
  payroll, 
  userData,
  onOpenPrint 
}) => {
  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang][key] || key;
  const isRTL = translations[lang].dir === 'rtl';
  const currencyLabel = lang === 'ar' ? 'درهم' : 'MAD';

  const [activeFilter, setActiveFilter] = useState<FilterType>('all');

  // Check if current active shift / rotation week is K3 (Night shift)
  const currentShiftThisWeek = getShiftForDate(new Date(), userData);
  const isK3ShiftWeek = currentShiftThisWeek === ShiftType.K3;

  const earningsItems = [
    { 
      id: 'base',
      label: lang === 'ar' ? 'الراتب الأساسي' : lang === 'fr' ? 'Salaire de Base' : 'Base Workforce Pay',
      value: payroll.regularPay, 
      desc: lang === 'ar'
        ? `${payroll.regularHours.toFixed(1)} س @ ${userData.salaryType === 'fixed' ? (userData.baseSalary / 191).toFixed(2) : userData.hourlyRate.toFixed(2)} درهم/ساعة (يشمل الأعياد القانونية)`
        : `${payroll.regularHours.toFixed(1)}h @ ${userData.salaryType === 'fixed' ? (userData.baseSalary / 191).toFixed(2) : userData.hourlyRate.toFixed(2)} MAD/h (inclut fériés légaux)`,
      icon: Clock,
      status: payroll.regularHours >= 191 ? 'validated' : 'in_progress',
      statusLabel: payroll.regularHours >= 191 ? (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done') : (lang === 'ar' ? 'قيد الإنجاز' : lang === 'fr' ? 'En cours' : 'In Progress'),
      category: 'earning'
    },
    { 
      id: 'holiday_worked',
      label: lang === 'ar' ? 'علاوة العمل يوم العيد (+100%)' : lang === 'fr' ? 'Majoration Férié Travaillé (+100%)' : 'Holiday Worked Premium (+100%)',
      value: payroll.holidayWorkedBonus, 
      desc: lang === 'ar'
        ? `${payroll.holidayDaysCount} يوم عيد رسمي تم العمل فيه بنسبة مضاعفة +100%`
        : `${payroll.holidayDaysCount} jour(s) férié(s) travaillé(s) à +100%`,
      icon: Award,
      status: payroll.holidayWorkedBonus > 0 ? 'validated' : 'in_progress',
      statusLabel: payroll.holidayWorkedBonus > 0 ? (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done') : (lang === 'ar' ? 'في الانتظار' : lang === 'fr' ? 'En attente' : 'Pending'),
      category: 'earning'
    },
    { 
      id: 'k3',
      label: lang === 'ar' ? 'منحة العمل الليلي (K3)' : lang === 'fr' ? 'Prime Vacation Nuit (K3)' : 'K3 Night Shift Premium',
      value: payroll.k3Bonus, 
      desc: lang === 'ar'
        ? `${payroll.k3Hours.toFixed(1)} س ليلية بنسبة +${(userData.k3Rate * 100).toFixed(0)}%`
        : `${payroll.k3Hours.toFixed(1)}h à +${(userData.k3Rate * 100).toFixed(0)}%`,
      icon: Moon,
      status: isK3ShiftWeek ? 'in_progress' : 'validated',
      statusLabel: isK3ShiftWeek 
        ? (lang === 'ar' ? 'قيد الإنجاز' : lang === 'fr' ? 'En cours' : 'In Progress') 
        : (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done'),
      category: 'earning'
    },
    { 
      id: 'sunday',
      label: lang === 'ar' ? 'علاوة العمل يوم الأحد' : lang === 'fr' ? 'Majoration Dimanche' : 'Sunday Special Rate',
      value: payroll.sundayPay, 
      desc: lang === 'ar'
        ? `${payroll.sundayHours.toFixed(1)} س عمل يوم الأحد بنسبة +${(userData.sundayRate * 100).toFixed(0)}%`
        : `${payroll.sundayHours.toFixed(1)}h à +${(userData.sundayRate * 100).toFixed(0)}%`,
      icon: Calendar,
      status: payroll.sundayPay > 0 ? 'validated' : 'in_progress',
      statusLabel: payroll.sundayPay > 0 ? (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done') : (lang === 'ar' ? 'في الانتظار' : lang === 'fr' ? 'En attente' : 'Pending'),
      category: 'earning'
    },
    { 
      id: 'overtime',
      label: lang === 'ar' ? 'الساعات الإضافية' : lang === 'fr' ? 'Heures Supplémentaires' : 'Overtime Excess Pay',
      value: payroll.overtimeBonus, 
      desc: lang === 'ar'
        ? `${payroll.overtimeHours.toFixed(1)} س فوق الساعات القانونية 191 س (+${(userData.overtimeRate * 100).toFixed(0)}%)`
        : `${payroll.overtimeHours.toFixed(1)}h au-delà de 191h (+${(userData.overtimeRate * 100).toFixed(0)}%)`,
      icon: TrendingUp,
      status: payroll.overtimeHours > 0 ? 'validated' : 'in_progress',
      statusLabel: payroll.overtimeHours > 0 ? (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done') : (lang === 'ar' ? 'قيد الإنجاز' : lang === 'fr' ? 'En cours' : 'In Progress'),
      category: 'earning'
    },
    { 
      id: 'seniority',
      label: lang === 'ar' ? 'منحة الأقدمية' : lang === 'fr' ? "Prime d'Ancienneté" : 'Seniority Loyalty Bonus',
      value: payroll.seniorityBonus, 
      desc: lang === 'ar'
        ? `${(userData.seniorityRate * 100).toFixed(0)}% محسوبة على الراتب الأساسي`
        : `${(userData.seniorityRate * 100).toFixed(0)}% sur le salaire de base`,
      icon: Award,
      status: 'validated',
      statusLabel: lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done',
      category: 'earning'
    },
    { 
      id: 'attendance',
      label: lang === 'ar' ? 'منحة المواظبة الشاملة' : lang === 'fr' ? "Prime d'Assiduité" : 'Attendance Compliance Reward',
      value: payroll.attendanceBonus, 
      desc: lang === 'ar'
        ? 'تمنح للمواظبة التامة بدون أي غياب غير مبرر'
        : 'Accordée pour zéro absence injustifiée',
      icon: ShieldCheck,
      status: payroll.attendanceBonus > 0 ? 'validated' : 'in_progress',
      statusLabel: payroll.attendanceBonus > 0 ? (lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done') : (lang === 'ar' ? 'غير مستحق' : lang === 'fr' ? 'Non éligible' : 'Ineligible'),
      category: 'earning'
    },
  ];

  const subTotalBeforeCustom = earningsItems.reduce((acc, item) => acc + item.value, 0);

  const customBonusItems = userData.customPercentageBonuses.map(cb => ({
    id: `custom-bonus-${cb.id}`,
    label: cb.label,
    value: cb.type === 'percentage' ? subTotalBeforeCustom * cb.value : cb.value,
    desc: cb.type === 'percentage' 
      ? (lang === 'ar' ? `نسبة مئوية (${(cb.value * 100).toFixed(1)}%)` : `Taux composite (${(cb.value * 100).toFixed(1)}%)`)
      : (lang === 'ar' ? 'منحة بمبلغ قار' : 'Prime forfaitaire'),
    icon: Receipt,
    status: 'validated',
    statusLabel: lang === 'ar' ? 'مؤكد' : lang === 'fr' ? 'Validé' : 'Done',
    category: 'earning'
  }));

  const coreHoursBase = payroll.regularPay + payroll.sundayPay + payroll.holidayWorkedBonus + payroll.overtimeBonus;

  const customDeductionItems = userData.customDeductions.map(cd => ({
    id: `custom-ded-${cd.id}`,
    label: cd.label,
    value: cd.type === 'percentage' ? coreHoursBase * cd.value : cd.value,
    desc: cd.type === 'percentage'
      ? (lang === 'ar' ? `نسبة اقتطاع (${(cd.value * 100).toFixed(1)}%)` : `Taux (${(cd.value * 100).toFixed(1)}%)`)
      : (lang === 'ar' ? 'اقتطاع بمبلغ قار' : 'Retenue fixe'),
    icon: AlertCircle,
    status: 'validated',
    statusLabel: lang === 'ar' ? 'مقتطع' : lang === 'fr' ? 'Déduit' : 'Deducted',
    category: 'deduction'
  }));

  const healthInsuranceRatePercent = ((userData.healthInsuranceRate !== undefined ? userData.healthInsuranceRate : 0.018) * 100).toFixed(1);

  const legalDeductionItems = [
    { 
      id: 'cnss',
      label: lang === 'ar' ? 'الصندوق الوطني للضمان الاجتماعي (CNSS)' : 'CNSS (Sécurité Sociale)', 
      value: payroll.cnssDeduction, 
      desc: lang === 'ar' ? '4.48% (سقف الاشتراك 6,000 درهم)' : '4.48% (Plafonné à 6 000 MAD)',
      icon: AlertCircle,
      status: 'validated',
      statusLabel: lang === 'ar' ? 'مقتطع' : lang === 'fr' ? 'Déduit' : 'Deducted',
      category: 'deduction'
    },
    { 
      id: 'health_insurance',
      label: lang === 'ar' ? `تأمين صحي خاص (${healthInsuranceRatePercent}%)` : `Assurance Maladie Privée (Mutuelle)`, 
      value: payroll.healthInsuranceDeduction, 
      desc: lang === 'ar' ? `${healthInsuranceRatePercent}% عقد التأمين الصحي الجماعي للشركة` : `${healthInsuranceRatePercent}% contrat groupe entreprise`,
      icon: AlertCircle,
      status: 'validated',
      statusLabel: lang === 'ar' ? 'مقتطع' : lang === 'fr' ? 'Déduit' : 'Deducted',
      category: 'deduction'
    },
  ];

  const allItems = [...earningsItems, ...customBonusItems].filter(item => {
    // If the operator is currently on K3 night shift week, show K3 under In Progress even if early in the week
    if (item.id === 'k3' && isK3ShiftWeek) return true;
    return item.value > 0;
  });

  const filteredItems = allItems.filter(item => {
    if (activeFilter === 'all') return true;
    return item.status === activeFilter;
  });

  return (
    <div className="space-y-4 sm:space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* 1. Optibus Filter Tab Bar with Fluid Black Navigating Pill */}
      <LayoutGroup id="earnings-filter-tabs">
        <div className="bg-white dark:bg-slate-900 rounded-[22px] p-1.5 border border-gray-100 dark:border-slate-800 shadow-sm flex items-center gap-1.5 relative isolate transition-colors">
          {[
            { id: 'all' as FilterType, label: lang === 'ar' ? 'الكل' : lang === 'fr' ? 'Tous' : 'All', count: allItems.length },
            { id: 'in_progress' as FilterType, label: lang === 'ar' ? 'قيد الإنجاز' : lang === 'fr' ? 'En cours' : 'In Progress', count: allItems.filter(i => i.status === 'in_progress').length },
            { id: 'validated' as FilterType, label: lang === 'ar' ? 'تم تأكيده' : lang === 'fr' ? 'Validé' : 'Validated', count: allItems.filter(i => i.status === 'validated').length },
          ].map((tab) => {
            const isActive = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveFilter(tab.id)}
                className={`relative flex-1 py-2.5 px-3 rounded-[18px] text-xs font-black transition-colors duration-200 flex items-center justify-center gap-2 cursor-pointer select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-900 ${
                  isActive ? 'text-white' : 'text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="earningFilterActivePill"
                    className="absolute inset-0 bg-slate-900 dark:bg-purple-600 rounded-[18px] shadow-md shadow-slate-900/25 z-0"
                    transition={{
                      type: 'spring',
                      stiffness: 450,
                      damping: 35,
                      mass: 0.8
                    }}
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
                <span className={`relative z-10 text-[10px] px-2 py-0.5 rounded-full font-black transition-colors duration-200 ${
                  isActive ? 'bg-white/20 text-white' : 'bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>
      </LayoutGroup>

      {/* 2. Gross Earnings Items (Optibus Claims Card format) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <p className="text-[11px] font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-widest">
            {lang === 'ar' ? 'عناصر الراتب الإجمالي' : lang === 'fr' ? 'Éléments de Gains Bruts' : 'Gross Earnings Breakdown'}
          </p>
          <span className="text-xs font-extrabold text-gray-900 dark:text-white metric-ltr tabular-nums" dir="ltr">
            Total: {(payroll?.grossTotal ?? 0).toLocaleString('fr-FR', { minimumFractionDigits: 2 })} {currencyLabel}
          </span>
        </div>

        <motion.div 
          className="space-y-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {filteredItems.map((item, idx) => {
            const Icon = item.icon;
            const isValidated = item.status === 'validated';

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.03, type: 'spring', stiffness: 350, damping: 25 }}
                whileHover={{ scale: 1.01 }}
                className="bg-white dark:bg-slate-900 rounded-[18px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm flex items-start sm:items-center justify-between gap-3.5 hover:border-gray-200 dark:hover:border-slate-700 transition-all"
              >
                <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                  <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-0 ${
                    isValidated 
                    ? 'bg-purple-50 dark:bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-100 dark:border-purple-500/20' 
                    : 'bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-500/20'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white leading-snug break-words">
                        {item.label}
                      </h4>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md border flex-shrink-0 whitespace-nowrap ${
                        isValidated 
                          ? 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/30' 
                          : 'bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-500/30'
                      }`}>
                        {item.statusLabel}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-slate-400 font-medium mt-1 leading-relaxed break-words">
                      {item.desc}
                    </p>
                  </div>
                </div>

                <div className="text-end flex-shrink-0 self-start sm:self-center pl-1 sm:pl-2 metric-ltr" dir="ltr">
                  <span dir="ltr" className="text-base sm:text-lg font-black text-gray-900 dark:text-white tracking-tight block whitespace-nowrap tabular-nums metric-ltr">
                    +{item.value.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className="text-[10px] font-bold text-gray-400 dark:text-slate-500">{currencyLabel}</span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>

      {/* 3. Deductions Breakdown */}
      <div className="space-y-3 pt-2">
        <p className="text-[11px] font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-widest px-1">
          {lang === 'ar' ? 'الخصومات والاقتطاعات القانونية' : lang === 'fr' ? 'Cotisations & Retenues' : 'Deductions & Social Security'}
        </p>

        {[...legalDeductionItems, ...customDeductionItems].filter(i => i.value > 0).map((item) => (
          <div
            key={item.id}
            className="bg-white dark:bg-slate-900 rounded-[18px] p-4 sm:p-5 border border-rose-100/70 dark:border-rose-900/40 shadow-sm flex items-start sm:items-center justify-between gap-3.5 bg-rose-50/10 dark:bg-rose-950/10"
          >
            <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center flex-shrink-0 border border-rose-100 dark:border-rose-500/20 mt-0.5 sm:mt-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h4 className="text-sm sm:text-base font-bold text-gray-900 dark:text-white leading-snug break-words">
                    {item.label}
                  </h4>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md border flex-shrink-0 whitespace-nowrap bg-rose-50 dark:bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-500/30">
                    {item.statusLabel}
                  </span>
                </div>
                <p className="text-xs text-gray-500 dark:text-slate-400 font-medium mt-1 leading-relaxed break-words">
                  {item.desc}
                </p>
              </div>
            </div>

            <div className="text-end flex-shrink-0 self-start sm:self-center pl-1 sm:pl-2 metric-ltr" dir="ltr">
              <span dir="ltr" className="text-base sm:text-lg font-black text-rose-600 dark:text-rose-400 tracking-tight block whitespace-nowrap tabular-nums metric-ltr">
                -{item.value.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] font-bold text-gray-400 dark:text-slate-500">{currencyLabel}</span>
            </div>
          </div>
        ))}
      </div>

      {/* 4. Final Net Summary Hero (SOLDE NET FINAL) */}
      <motion.div 
        whileHover={{ y: -3, scale: 1.008 }}
        transition={{ type: "spring", stiffness: 350, damping: 25 }}
        className="bg-slate-900 rounded-[22px] p-5 sm:p-7 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 relative overflow-hidden group"
      >
        {/* Subtle decorative purple glow */}
        <div className="absolute -right-16 -top-16 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-700" />

        <div className="relative z-10">
          <span className="text-[11px] font-extrabold text-purple-400 uppercase tracking-widest block">
            {lang === 'ar' ? 'الصافي للدفع' : lang === 'fr' ? 'SOLDE NET À PAYER' : 'FINAL NET PAYABLE'}
          </span>
          <div className="flex items-baseline gap-2 mt-1 metric-ltr tabular-nums" dir="ltr">
            <motion.span 
              key={payroll?.netTotal}
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="text-3xl sm:text-5xl font-black text-white tracking-tight tabular-nums metric-ltr"
            >
              {(payroll?.netTotal ?? 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </motion.span>
            <span className="text-sm font-bold text-purple-400">{currencyLabel}</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {lang === 'ar' ? 'محسوب وفق القانون 65-99' : lang === 'fr' ? 'Certifié conforme Code du Travail Marocain' : 'Calculated per Moroccan Labor Code'}
          </p>
        </div>

        {onOpenPrint && (
          <motion.button
            whileHover={{ scale: 1.04, y: -1 }}
            whileTap={{ scale: 0.94 }}
            onClick={onOpenPrint}
            className="w-full sm:w-auto px-5 py-3.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-colors flex-shrink-0 relative z-10 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{lang === 'ar' ? 'طباعة بيان الأجرة' : lang === 'fr' ? 'Imprimer Bulletin (PDF)' : 'Print Payroll Statement'}</span>
          </motion.button>
        )}
      </motion.div>
    </div>
  );
};

export default EarningsDetails;
