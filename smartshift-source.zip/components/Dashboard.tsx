import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  TrendingUp, 
  Percent, 
  Clock, 
  Moon, 
  Calendar, 
  Award,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { SalaryBreakdown, UserData } from '../types';
import { translations, TranslationKey } from '../translations';
import { getCurrentShiftInfo, calculatePayroll } from '../services/payrollEngine';
import LiveTimer from './LiveTimer';

interface DashboardProps {
  payroll: SalaryBreakdown;
  userData: UserData;
  onNavigateToTab?: (tab: 'calendar' | 'payroll') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  payroll, 
  userData,
  onNavigateToTab 
}) => {
  const lang = userData.language || 'fr';
  const isRTL = translations[lang].dir === 'rtl';
  const currencyLabel = lang === 'ar' ? 'درهم' : 'MAD';

  // Live real-time tick state: updates every second
  const [liveTimestamp, setLiveTimestamp] = useState<number>(() => Date.now());

  // Determine current active shift info
  const shiftInfo = useMemo(() => {
    return getCurrentShiftInfo(userData);
  }, [userData, Math.floor(liveTimestamp / 15000)]);

  // Live timer interval: ticks every 1 second (1000ms)
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveTimestamp(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Dynamic payroll calculation with real-time updates
  const currentPayroll = useMemo(() => {
    if (!shiftInfo.active) return payroll;
    const now = new Date();
    return calculatePayroll(now.getFullYear(), now.getMonth(), userData);
  }, [payroll, userData, shiftInfo.active, Math.floor(liveTimestamp / 1000)]);

  const liveNetSalary = currentPayroll?.netSalary ?? payroll?.netSalary ?? payroll?.netTotal ?? 0;

  // Format with normal 2 decimal places e.g. "3 423.50"
  const formattedSalary = liveNetSalary.toLocaleString('fr-FR', { 
    minimumFractionDigits: 2, 
    maximumFractionDigits: 2 
  });
  const parts = formattedSalary.split(/[,.]/);
  const integerPart = parts.length > 1 ? parts.slice(0, -1).join(' ') : parts[0];
  const decimalPart = parts.length > 1 ? parts[parts.length - 1] : '00';

  const yieldPercent = Math.min(100, Math.round((currentPayroll.regularHours / 191) * 100));

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 12 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 350, damping: 25 } }
  };

  return (
    <motion.div 
      className="space-y-4 sm:space-y-6" 
      dir={isRTL ? 'rtl' : 'ltr'}
      variants={containerVariants}
      initial="hidden"
      animate="show"
    >
      {/* Live Shift Operations Widget (LIVE OPS / REST PHASE) */}
      <motion.div variants={itemVariants}>
        <LiveTimer 
          userData={userData}
          hourlyRate={userData.hourlyRate}
          onNavigateToPlanning={() => onNavigateToTab?.('calendar')}
        />
      </motion.div>

      {/* 1. Hero Summary Card (SALAIRE NET ESTIMÉ) */}
      <motion.div 
        variants={itemVariants}
        className="bg-white dark:bg-slate-900 rounded-[22px] p-5 sm:p-7 border border-gray-100/90 dark:border-slate-800 shadow-sm hover:shadow-md transition-all relative overflow-hidden group"
      >
        {/* Subtle clean ambient backdrop */}
        <div className="absolute -right-20 -top-20 w-56 h-56 bg-slate-900/[0.03] dark:bg-purple-500/[0.05] rounded-full blur-3xl pointer-events-none" />

        {/* Top Header inside Hero */}
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-bold text-gray-500 dark:text-slate-400 uppercase tracking-widest">
              {userData.name ? userData.name.toUpperCase() : 'COLLABORATEUR'}
            </span>
          </div>

          <motion.button 
            type="button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.94 }}
            className="w-10 h-10 rounded-2xl bg-slate-900 dark:bg-purple-600 text-white flex items-center justify-center shadow-md cursor-pointer hover:bg-slate-800 dark:hover:bg-purple-700 transition-colors"
            onClick={() => onNavigateToTab?.('payroll')}
            title={lang === 'ar' ? 'عرض تفاصيل الأجرة' : lang === 'fr' ? 'Détails de paie' : 'Payroll details'}
          >
            <Wallet className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Main Solde Amount */}
        <div className="mt-4 relative z-10">
          <div className="flex items-center gap-2">
            <h2 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-gray-400 dark:text-slate-400">
              {lang === 'ar' ? 'صافي الأجرة التقديري' : lang === 'fr' ? 'SALAIRE NET ESTIMÉ' : 'NET ESTIMATED SALARY'}
            </h2>
            {shiftInfo.active && (
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-[10px] font-extrabold text-emerald-700 dark:text-emerald-400 border border-emerald-200/90 dark:border-emerald-500/20 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>{lang === 'ar' ? 'مباشر' : lang === 'fr' ? 'En Direct' : 'Live'}</span>
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1 mt-1 metric-ltr tabular-nums" dir="ltr">
            <span className="text-4xl sm:text-6xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
              {integerPart}
            </span>
            <span className="text-2xl sm:text-4xl font-black text-purple-600 dark:text-purple-400 tracking-tight tabular-nums">
              .{decimalPart}
            </span>
            <span className="text-base sm:text-xl font-black text-gray-400 dark:text-slate-500 ms-1.5">{currencyLabel}</span>
          </div>
        </div>

        {/* Secondary Metrics Bar (Projeté & Rendement) */}
        <div className="mt-6 pt-5 border-t border-gray-100 dark:border-slate-800 grid grid-cols-2 gap-4 relative z-10">
          <motion.div 
            whileHover={{ y: -2 }}
            className="bg-gray-50/80 dark:bg-slate-800/70 p-3.5 rounded-2xl border border-gray-100 dark:border-slate-700/60 transition-all hover:border-purple-200 dark:hover:border-purple-500/30"
          >
            <div className="flex items-center gap-1.5 text-gray-400 dark:text-slate-400 font-bold mb-1">
              <TrendingUp className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
              <span className="text-[12px] leading-[16px]">{lang === 'ar' ? 'المتوقع نهاية الشهر' : lang === 'fr' ? 'PROJETÉ FIN DE MOIS' : 'PROJECTED'}</span>
            </div>
            <p className="text-lg sm:text-xl font-extrabold text-gray-900 dark:text-white tabular-nums flex items-baseline gap-1 metric-ltr" dir="ltr">
              <span>{(currentPayroll?.projectedNetSalary ?? currentPayroll?.projectedGrossTotal ?? 0).toLocaleString('fr-FR', { maximumFractionDigits: 0 })}</span>
              <span className="text-xs font-bold text-gray-400 dark:text-slate-500">{currencyLabel}</span>
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ y: -2 }}
            className="bg-gray-50/80 dark:bg-slate-800/70 p-3.5 rounded-2xl border border-gray-100 dark:border-slate-700/60 transition-all hover:border-emerald-200 dark:hover:border-emerald-500/30"
          >
            <div className="flex items-center gap-1.5 text-gray-400 dark:text-slate-400 font-bold mb-1">
              <Percent className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="text-[12px] leading-[16px]">{lang === 'ar' ? 'المردودية (191H)' : lang === 'fr' ? 'RENDEMENT (191H)' : 'YIELD'}</span>
            </div>
            <p className="text-lg sm:text-xl font-extrabold text-gray-900 dark:text-white flex items-baseline metric-ltr tabular-nums" dir="ltr">
              <span>{yieldPercent}%</span>
            </p>
          </motion.div>
        </div>
      </motion.div>

      {/* 2. Two-Column Metric Cards with Motion Hover & Progress Graphics */}
      <div className="grid grid-cols-2 gap-3.5 sm:gap-4">
        {/* Heures Travaillées */}
        <motion.div 
          variants={itemVariants}
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm hover:shadow-md relative overflow-hidden transition-all"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
              {lang === 'ar' ? 'ساعات العمل' : lang === 'fr' ? 'HEURES TRAVAILLÉES' : 'HOURS WORKED'}
            </span>
            <Clock className="w-4 h-4 text-slate-700 dark:text-slate-300" />
          </div>

          <div className="flex items-baseline gap-1 mt-1 metric-ltr tabular-nums" dir="ltr">
            <span className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
              {currentPayroll.regularHours.toFixed(1)}
            </span>
            <span className="text-xs font-bold text-gray-400 dark:text-slate-500">/ 191H</span>
          </div>

          {/* Animated dark status bar indicator */}
          <div className="mt-3.5 w-full bg-gray-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((currentPayroll.regularHours / 191) * 100, 100)}%` }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="bg-slate-900 dark:bg-purple-500 h-full rounded-full"
            />
          </div>
        </motion.div>

        {/* Heures de Nuit (K3) */}
        <motion.div 
          variants={itemVariants}
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm hover:shadow-md relative overflow-hidden transition-all"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
              {lang === 'ar' ? 'ساعات الليل (K3)' : lang === 'fr' ? 'HEURES DE NUIT (K3)' : 'NIGHT HOURS (K3)'}
            </span>
            <Moon className="w-4 h-4 text-amber-500" />
          </div>

          <div className="flex items-baseline gap-1 mt-1 metric-ltr tabular-nums" dir="ltr">
            <span className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
              {currentPayroll.k3Hours.toFixed(1)}
            </span>
            <span className="text-xs font-bold text-gray-400 dark:text-slate-500">H</span>
          </div>

          {/* Animated orange status bar indicator */}
          <div className="mt-3.5 w-full bg-gray-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((currentPayroll.k3Hours / 64) * 100, 100)}%` }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="bg-amber-500 h-full rounded-full"
            />
          </div>
        </motion.div>

        {/* Majorations Dimanche */}
        <motion.div 
          variants={itemVariants}
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm hover:shadow-md relative overflow-hidden transition-all"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
              {lang === 'ar' ? 'علاوة الأحد' : lang === 'fr' ? 'MAJORATIONS DIMANCHE' : 'SUNDAY RATE'}
            </span>
            <Calendar className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </div>

          <div className="flex items-baseline gap-1 mt-1 metric-ltr tabular-nums" dir="ltr">
            <span className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
              {currentPayroll.sundayDaysCount}
            </span>
            <span className="text-xs font-bold text-gray-400 dark:text-slate-500">
              {lang === 'ar' ? 'أيام' : lang === 'fr' ? 'Jours' : 'Days'}
            </span>
          </div>

          <p className="text-[11px] font-bold text-purple-600 dark:text-purple-400 mt-2 truncate metric-ltr tabular-nums" dir="ltr">
            {currentPayroll.sundayPay > 0 
              ? `+${currentPayroll.sundayPay.toFixed(0)} ${currencyLabel}` 
              : (lang === 'ar' ? 'لا يوجد يوم أحد' : lang === 'fr' ? 'Aucun dimanche pointé' : 'No Sunday logged')}
          </p>
        </motion.div>

        {/* Jours Fériés */}
        <motion.div 
          variants={itemVariants}
          whileHover={{ y: -4, scale: 1.015 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
          onClick={() => onNavigateToTab?.('calendar')}
          className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm relative overflow-hidden cursor-pointer hover:border-emerald-200 dark:hover:border-emerald-500/40 hover:shadow-md transition-all"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] sm:text-xs font-extrabold text-gray-400 dark:text-slate-400 uppercase tracking-wider">
              {lang === 'ar' ? 'الأعياد والعطل' : lang === 'fr' ? 'JOURS FÉRIÉS' : 'PAID HOLIDAYS'}
            </span>
            <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>

          <div className="flex items-baseline gap-1 mt-1 metric-ltr tabular-nums" dir="ltr">
            <span className="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white tracking-tight tabular-nums">
              {payroll.holidayDaysCount}
            </span>
            <span className="text-xs font-bold text-gray-400 dark:text-slate-500">
              {lang === 'ar' ? 'أيام' : lang === 'fr' ? 'Jours' : 'Days'}
            </span>
          </div>

          <p className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 mt-2 truncate metric-ltr tabular-nums" dir="ltr">
            {payroll.holidayWorkedBonus > 0 
              ? `+${payroll.holidayWorkedBonus.toFixed(0)} ${currencyLabel} (+100%)` 
              : (lang === 'ar' ? 'مؤدى عنها 100%' : lang === 'fr' ? 'Majoré à +100%' : '+100% Statutory')}
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;
