import React from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Award,
  Clock,
  RotateCcw,
  FileText
} from 'lucide-react';
import { ShiftType, UserData } from '../types';
import { getShiftForDate, getHolidayName, formatDateISO, getDaysInMonth, formatTime13h } from '../utils/dateUtils';
import { SHIFT_CONFIG } from '../constants';
import { translations, TranslationKey } from '../translations';

interface CalendarProps {
  year: number;
  month: number;
  userData: UserData;
  onToggleDay: (date: string, type: 'worked' | 'absence') => void;
  onPrevMonth: () => void;
  onNextMonth: () => void;
  onResetMonth?: () => void;
  onShowMonthPayroll?: (year: number, month: number) => void;
  onSwitchToWeekly?: () => void;
  onSwitchToMonthly?: () => void;
}

export const Calendar: React.FC<CalendarProps> = ({ 
  year, 
  month, 
  userData, 
  onToggleDay, 
  onPrevMonth, 
  onNextMonth,
  onResetMonth,
  onShowMonthPayroll,
  onSwitchToWeekly
}) => {
  const lang = userData.language || 'fr';
  const t = (key: TranslationKey) => translations[lang][key] || key;
  const isRTL = translations[lang].dir === 'rtl';
  const localeStr = lang === 'ar' ? 'ar-MA' : lang === 'fr' ? 'fr-FR' : 'en-US';

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = new Date(year, month, 1).getDay();
  const monthName = new Intl.DateTimeFormat(localeStr, { month: 'long' }).format(new Date(year, month));
  const now = new Date();
  const todayISO = formatDateISO(now);
  const isCurrentMonth = now.getFullYear() === year && now.getMonth() === month;

  const currentMonthHolidays: { day: number, name: string }[] = [];
  for (let d = 1; d <= daysInMonth; d++) {
    const hName = getHolidayName(new Date(year, month, d), lang);
    if (hName) currentMonthHolidays.push({ day: d, name: hName });
  }

  // Weekday labels in the user's selected language
  const weekDayLabels = lang === 'ar'
    ? ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
    : lang === 'fr'
    ? ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
    : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Month date range label (e.g., 01 - 31 Août 2026)
  const monthRangeLabel = `${lang === 'ar' ? `1 - ${daysInMonth}` : `01 - ${daysInMonth}`} ${monthName} ${year}`;

  // Formatted "Updated at" timestamp in 13h format
  const updatedDateStr = now.toLocaleDateString(localeStr, { day: '2-digit', month: '2-digit', year: 'numeric' });
  const updatedTimestamp = `${updatedDateStr} à ${formatTime13h(now)}`;

  const renderDay = (d: number) => {
    const date = new Date(year, month, d);
    const iso = formatDateISO(date);
    const shift = getShiftForDate(date, userData);
    const holiday = getHolidayName(date, lang);
    const isSunday = date.getDay() === 0;
    const isWorked = userData.specialDaysWorked.includes(iso) || userData.holidaysWorked.includes(iso);
    const isAbsence = userData.absences.includes(iso);
    const isToday = todayISO === iso;
    const isFuture = date > now && !isToday;

    const shiftInfo = SHIFT_CONFIG[shift];

    let cellBg = 'bg-white dark:bg-slate-800/80';
    let borderStyle = 'border-gray-100 dark:border-slate-700/70';
    let textColor = 'text-gray-900 dark:text-white';
    
    if (isToday) {
      cellBg = 'bg-purple-600 dark:bg-purple-600';
      borderStyle = 'border-purple-600 shadow-md scale-105 z-10';
      textColor = 'text-white';
    } else if (holiday) {
      cellBg = 'bg-amber-50/70 dark:bg-amber-950/30';
      borderStyle = 'border-amber-200 dark:border-amber-700/50';
      textColor = 'text-amber-900 dark:text-amber-300';
    } else if (isAbsence) {
      cellBg = 'bg-rose-50/70 dark:bg-rose-950/30';
      borderStyle = 'border-rose-200 dark:border-rose-700/50';
      textColor = 'text-rose-900 dark:text-rose-300';
    }

    return (
      <motion.div 
        key={d} 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => onToggleDay(iso, (isSunday || !!holiday) ? 'worked' : 'absence')}
        className={`relative flex flex-col items-center justify-between py-1.5 sm:py-2 aspect-square border transition-all duration-150 cursor-pointer rounded-xl sm:rounded-2xl min-h-[46px] sm:min-h-[56px]
          ${cellBg} ${borderStyle} 
          group
          ${isFuture ? 'opacity-40' : 'opacity-100'}
          hover:shadow-md hover:border-gray-300 dark:hover:border-slate-600
        `}
      >
        <div className="w-full px-1.5 flex justify-between items-center">
          <span className={`text-[8px] font-black uppercase tracking-wider ${isToday ? 'text-purple-200' : isSunday ? 'text-rose-500' : 'text-gray-400 dark:text-slate-500'}`}>
            {isSunday ? (lang === 'ar' ? 'أ' : 'D') : ''}
          </span>
          <div className="flex gap-0.5">
            {isWorked && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-xs"></div>}
            {isAbsence && !isWorked && <div className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-xs"></div>}
          </div>
        </div>

        <div className="flex flex-col items-center">
          <span className={`text-xs sm:text-base font-extrabold tracking-tight ${textColor}`}>
            {d}
          </span>
          {holiday && (
            <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-0.5 animate-pulse"></div>
          )}
        </div>

        <div className="w-full flex justify-center pb-1 px-1">
          {shift !== ShiftType.OFF ? (
            <div className={`px-1 py-0.5 rounded-md border flex items-center justify-center gap-1 shadow-2xs transition-transform ${isToday ? 'bg-white/20 border-white/30 text-white' : 'bg-gray-100/80 dark:bg-slate-700/80 border-gray-200/60 dark:border-slate-600 text-gray-800 dark:text-slate-200'}`}>
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: isToday ? '#fff' : shiftInfo.color }}></div>
              <span className="text-[8px] font-black uppercase tracking-wider">{shift}</span>
            </div>
          ) : (
            <div className="h-2.5 sm:h-3" />
          )}
        </div>
      </motion.div>
    );
  };

  const days = [];
  for (let i = 0; i < firstDay; i++) {
    days.push(<div key={`empty-${i}`} className="aspect-square"></div>);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    days.push(renderDay(d));
  }

  return (
    <div className="space-y-4 sm:space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Top Unified Switcher Bar */}
      <div className="flex bg-gray-100/90 dark:bg-slate-900/90 p-1 rounded-2xl border border-gray-200/70 dark:border-slate-800 shadow-2xs transition-colors">
        <button
          type="button"
          onClick={onSwitchToWeekly}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white cursor-pointer"
        >
          <Clock className="w-3.5 h-3.5 text-gray-400 dark:text-slate-500" />
          <span>{lang === 'ar' ? 'تخطيطي الأسبوعي' : lang === 'fr' ? 'Mon Planning Hebdo' : 'My Weekly Planning'}</span>
        </button>
        <button
          type="button"
          className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all bg-white dark:bg-slate-800 text-gray-900 dark:text-white shadow-sm border border-gray-200/70 dark:border-slate-700"
        >
          <CalendarIcon className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
          <span>{lang === 'ar' ? 'شبكة الشهر' : lang === 'fr' ? 'Grille Mensuelle' : 'Month Grid'}</span>
        </button>
      </div>

      {/* 1. Month Navigator Card (Separated from the grid, identical to Weekly Planning) */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        {/* Month Navigator Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-slate-800">
          <button 
            onClick={onPrevMonth} 
            className="w-10 h-10 rounded-xl bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-200 flex items-center justify-center transition-colors active:scale-95 border border-gray-200/70 dark:border-slate-700 cursor-pointer"
            aria-label="Previous month"
          >
            <ChevronLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </button>
          
          <div className="text-center">
            <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white leading-tight capitalize">
              {monthName}, {year}
            </h2>
            <p className="text-xs font-semibold text-gray-400 dark:text-slate-400 mt-0.5">
              <span dir="ltr" className="inline-block tabular-nums metric-ltr">{lang === 'ar' ? `1 - ${daysInMonth}` : `01 - ${daysInMonth}`}</span> {monthName} {year}
            </p>
          </div>

          <button 
            onClick={onNextMonth} 
            className="w-10 h-10 rounded-xl bg-gray-50 dark:bg-slate-800 hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-700 dark:text-slate-200 flex items-center justify-center transition-colors active:scale-95 border border-gray-200/70 dark:border-slate-700 cursor-pointer"
            aria-label="Next month"
          >
            <ChevronRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Section Title & Subtitle */}
        <div className="pt-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-gray-900 dark:text-white">
              {lang === 'ar' ? 'شبكة الشهر الكاملة' : lang === 'fr' ? 'Grille Mensuelle Complète' : 'Full Month Grid'}
            </h3>
            <p className="text-[11px] font-medium text-gray-400 dark:text-slate-400">
              {lang === 'ar' ? 'تم التحديث في' : lang === 'fr' ? 'Mis à jour le' : 'Updated at'} {updatedTimestamp}
            </p>
          </div>

          {!isCurrentMonth && (
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
              {onResetMonth && (
                <button
                  type="button"
                  onClick={onResetMonth}
                  className="text-[11px] font-bold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-500/10 hover:bg-purple-100 dark:hover:bg-purple-500/20 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 border border-purple-200/70 dark:border-purple-500/30 shadow-2xs cursor-pointer active:scale-95"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'هذا الشهر' : lang === 'fr' ? 'Mois actuel' : 'Current Month'}</span>
                </button>
              )}

              {onShowMonthPayroll && (
                <button
                  type="button"
                  onClick={() => onShowMonthPayroll(year, month)}
                  className="text-[11px] font-bold text-white bg-slate-900 dark:bg-purple-600 hover:bg-slate-800 dark:hover:bg-purple-700 px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 shadow-sm cursor-pointer active:scale-95"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>
                    {lang === 'ar' 
                      ? 'عرض بيان راتب هذا الشهر' 
                      : lang === 'fr' 
                      ? 'Afficher le bulletin de ce mois' 
                      : 'Show this month payroll statement'}
                  </span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 2. Main Month Grid Card */}
      <div className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-6 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors">
        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-3 text-center">
          {weekDayLabels.map((day, i) => (
            <div key={i} className={`text-[10px] font-extrabold uppercase py-1 ${i === 0 ? 'text-rose-500' : 'text-gray-400 dark:text-slate-500'}`}>
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {days}
        </div>

        {/* Footer Hint */}
        <div className="mt-4 pt-3 border-t border-gray-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-gray-400 dark:text-slate-500">
          <span>{lang === 'ar' ? '💡 انقر على أي يوم لتعديل الحالة (غياب / عمل)' : lang === 'fr' ? '💡 Touchez un jour pour basculer (absence / travail)' : '💡 Tap any day to toggle status (absence / worked)'}</span>
          <span className="hidden sm:inline font-semibold">{daysInMonth} {lang === 'ar' ? 'أيام' : 'jours'}</span>
        </div>
      </div>

      {/* 3. Holidays List for Current Month (if any) */}
      {currentMonthHolidays.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-900 rounded-[20px] p-4 sm:p-5 border border-gray-100 dark:border-slate-800 shadow-sm transition-colors"
        >
          <div className="flex items-center gap-2 mb-3 pb-3 border-b border-gray-100 dark:border-slate-800">
            <Award className="w-4 h-4 text-amber-500" />
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-gray-900 dark:text-white">
              {lang === 'ar' ? 'الأعياد والعطل الرسمية لهذا الشهر' : lang === 'fr' ? 'Jours Fériés & Fêtes du Mois' : 'Monthly Public & Religious Holidays'}
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {currentMonthHolidays.map((h, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ scale: 1.02 }}
                className="flex items-center gap-3 p-3 bg-amber-50/60 dark:bg-amber-950/20 rounded-xl border border-amber-100 dark:border-amber-800/40"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white font-black text-xs flex items-center justify-center flex-shrink-0 shadow-xs">
                  {h.day}
                </div>
                <div>
                  <p className="text-xs font-bold text-gray-900 dark:text-white">{h.name}</p>
                  <p className="text-[10px] text-amber-800 dark:text-amber-400 font-semibold">{t('publicHoliday')}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default Calendar;
