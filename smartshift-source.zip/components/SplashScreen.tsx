import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import YazakiLogo from './YazakiLogo';

interface SplashScreenProps {
  onComplete: () => void;
  durationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ 
  onComplete, 
  durationMs = 1800 
}) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / durationMs) * 100));
      setProgress(pct);

      if (elapsed >= durationMs) {
        clearInterval(interval);
        setTimeout(onComplete, 150);
      }
    }, 30);

    return () => clearInterval(interval);
  }, [durationMs, onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.99 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      onClick={onComplete}
      className="fixed inset-0 z-50 bg-[#111217] text-white flex flex-col items-center justify-center select-none cursor-pointer overflow-hidden"
    >
      {/* Subtle ambient corporate red/dark glow in center background */}
      <div className="absolute w-72 h-72 rounded-full bg-[#ED1C24]/[0.04] blur-3xl pointer-events-none" />

      {/* Main Centered Launch Brandmark (Matches Screenshot 2) */}
      <motion.div
        initial={{ opacity: 0, y: 8, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center justify-center text-center px-6 relative z-10"
      >
        {/* Yazaki Full Logo with Red Arrowhead (Matches Screenshot 2) */}
        <div className="transform scale-110 sm:scale-125">
          <YazakiLogo size="lg" showSubtitle={false} />
        </div>
      </motion.div>

      {/* Bottom Subtle Loading Bar */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="absolute bottom-10 sm:bottom-14 left-0 right-0 flex flex-col items-center px-8 text-center"
      >
        <div className="w-24 h-[2px] bg-slate-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-[#ED1C24] rounded-full transition-all duration-75"
            style={{ width: `${progress}%` }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SplashScreen;
