
import { ShiftType } from './types';

export const DEFAULT_HOURLY_RATE = 17.92;
export const ATTENDANCE_BONUS = 300;
export const OVERTIME_THRESHOLD = 191;
export const SENIORITY_RATE = 0.05;
export const K3_BONUS_RATE = 0.20;
export const SUNDAY_MULTIPLIER = 2.0;

export const SHIFT_CONFIG = {
  [ShiftType.K1]: { start: 6, end: 14, color: '#FFB800', label: 'Morning' }, // Gold/Yellow
  [ShiftType.K2]: { start: 14, end: 22, color: '#3182CE', label: 'Afternoon' }, // Blue
  [ShiftType.K3]: { start: 22, end: 6, color: '#9F7AEA', label: 'Night' }, // Light Purple
  [ShiftType.OFF]: { start: 0, end: 0, color: '#4A5568', label: 'OFF' },
};

export interface HolidayEntry {
  fr: string;
  ar: string;
  en: string;
  isReligious?: boolean;
}

// Official Moroccan National & Civil Annual Holidays (Fêtes Nationales et Civiles au Maroc)
export const MOROCCAN_FIXED_HOLIDAYS: Record<string, HolidayEntry> = {
  '01-01': { fr: 'Nouvel An', ar: 'رأس السنة الميلادية', en: "New Year's Day" },
  '01-11': { fr: "Manifeste de l'Indépendance", ar: 'تقديم وثيقة الاستقلال', en: 'Independence Manifesto' },
  '01-14': { fr: 'Nouvel An Amazigh (Yennayer)', ar: 'رأس السنة الأمازيغية', en: 'Amazigh New Year' },
  '05-01': { fr: 'Fête du Travail', ar: 'عيد الشغل', en: 'Labor Day' },
  '07-30': { fr: 'Fête du Trône', ar: 'عيد العرش المجيد', en: 'Throne Day' },
  '08-14': { fr: "Allégeance Oued Ed-Dahab", ar: 'استرجاع واد الذهب', en: 'Oued Ed-Dahab Allegiance Day' },
  '08-20': { fr: 'Révolution du Roi et du Peuple', ar: 'ثورة الملك والشعب', en: 'Revolution of King and People' },
  '08-21': { fr: 'Fête de la Jeunesse', ar: 'عيد الشباب المجيد', en: 'Youth Day' },
  '11-06': { fr: 'Anniversaire de la Marche Verte', ar: 'ذكرى المسيرة الخضراء', en: 'Green March Day' },
  '11-18': { fr: "Fête de l'Indépendance", ar: 'عيد الاستقلال', en: 'Independence Day' },
};

// Official Moroccan Religious Paid Public Holidays (Fêtes Religieuses Légales au Maroc - Dahir/Décret)
// Dates mapped for 2025, 2026, 2027 based on official Ministry of Islamic Affairs astronomical calendar
export const MOROCCAN_RELIGIOUS_HOLIDAYS: Record<string, HolidayEntry> = {
  // 2025
  '2025-03-31': { fr: 'Aïd Al-Fitr (1er jour)', ar: 'عيد الفطر المبارك (اليوم 1)', en: 'Eid Al-Fitr (Day 1)', isReligious: true },
  '2025-04-01': { fr: 'Aïd Al-Fitr (2ème jour)', ar: 'ثاني أيام عيد الفطر', en: 'Eid Al-Fitr (Day 2)', isReligious: true },
  '2025-06-06': { fr: 'Aïd Al-Adha (1er jour)', ar: 'عيد الأضحى المبارك (اليوم 1)', en: 'Eid Al-Adha (Day 1)', isReligious: true },
  '2025-06-07': { fr: 'Aïd Al-Adha (2ème jour)', ar: 'ثاني أيام عيد الأضحى', en: 'Eid Al-Adha (Day 2)', isReligious: true },
  '2025-06-26': { fr: '1er Moharram (Nouvel An Hégirien)', ar: 'فاتح محرم (رأس السنة الهجرية)', en: '1st Moharram (Islamic New Year)', isReligious: true },
  '2025-09-05': { fr: 'Aïd Al-Mawlid An-Nabawi (1er jour)', ar: 'عيد المولد النبوي الشريف (اليوم 1)', en: 'Mawlid An-Nabawi (Day 1)', isReligious: true },
  '2025-09-06': { fr: 'Aïd Al-Mawlid An-Nabawi (2ème jour)', ar: 'عيد المولد النبوي الشريف (اليوم 2)', en: 'Mawlid An-Nabawi (Day 2)', isReligious: true },

  // 2026
  '2026-03-20': { fr: 'Aïd Al-Fitr (1er jour)', ar: 'عيد الفطر المبارك (اليوم 1)', en: 'Eid Al-Fitr (Day 1)', isReligious: true },
  '2026-03-21': { fr: 'Aïd Al-Fitr (2ème jour)', ar: 'ثاني أيام عيد الفطر', en: 'Eid Al-Fitr (Day 2)', isReligious: true },
  '2026-05-27': { fr: 'Aïd Al-Adha (1er jour)', ar: 'عيد الأضحى المبارك (اليوم 1)', en: 'Eid Al-Adha (Day 1)', isReligious: true },
  '2026-05-28': { fr: 'Aïd Al-Adha (2ème jour)', ar: 'ثاني أيام عيد الأضحى', en: 'Eid Al-Adha (Day 2)', isReligious: true },
  '2026-06-17': { fr: '1er Moharram (Nouvel An Hégirien)', ar: 'فاتح محرم (رأس السنة الهجرية)', en: '1st Moharram (Islamic New Year)', isReligious: true },
  '2026-08-26': { fr: 'Aïd Al-Mawlid An-Nabawi (1er jour)', ar: 'عيد المولد النبوي الشريف (اليوم 1)', en: 'Mawlid An-Nabawi (Day 1)', isReligious: true },
  '2026-08-27': { fr: 'Aïd Al-Mawlid An-Nabawi (2ème jour)', ar: 'عيد المولد النبوي الشريف (اليوم 2)', en: 'Mawlid An-Nabawi (Day 2)', isReligious: true },

  // 2027
  '2027-03-10': { fr: 'Aïd Al-Fitr (1er jour)', ar: 'عيد الفطر المبارك (اليوم 1)', en: 'Eid Al-Fitr (Day 1)', isReligious: true },
  '2027-03-11': { fr: 'Aïd Al-Fitr (2ème jour)', ar: 'ثاني أيام عيد الفطر', en: 'Eid Al-Fitr (Day 2)', isReligious: true },
  '2027-05-17': { fr: 'Aïd Al-Adha (1er jour)', ar: 'عيد الأضحى المبارك (اليوم 1)', en: 'Eid Al-Adha (Day 1)', isReligious: true },
  '2027-05-18': { fr: 'Aïd Al-Adha (2ème jour)', ar: 'ثاني أيام عيد الأضحى', en: 'Eid Al-Adha (Day 2)', isReligious: true },
  '2027-06-06': { fr: '1er Moharram (Nouvel An Hégirien)', ar: 'فاتح محرم (رأس السنة الهجرية)', en: '1st Moharram (Islamic New Year)', isReligious: true },
  '2027-08-15': { fr: 'Aïd Al-Mawlid An-Nabawi (1er jour)', ar: 'عيد المولد النبوي الشريف (اليوم 1)', en: 'Mawlid An-Nabawi (Day 1)', isReligious: true },
  '2027-08-16': { fr: 'Aïd Al-Mawlid An-Nabawi (2ème jour)', ar: 'عيد المولد النبوي الشريف (اليوم 2)', en: 'Mawlid An-Nabawi (Day 2)', isReligious: true },
};

// Backward-compatible dictionary with default French labels
export const MOROCCAN_HOLIDAYS: Record<string, string> = Object.entries(MOROCCAN_FIXED_HOLIDAYS).reduce(
  (acc, [key, val]) => {
    acc[key] = val.fr;
    return acc;
  },
  {} as Record<string, string>
);

// Rotation: K1 -> K3 -> K2 -> K1
export const SHIFT_ROTATION = [ShiftType.K1, ShiftType.K3, ShiftType.K2];

// Start of the rotation cycle relative to a known Monday (Feb 2, 2026 is a Monday)
export const REFERENCE_DATE = new Date(2026, 1, 2); 
export const REFERENCE_SHIFT_INDEX = 0; // Starts with K1
