import { ThemeMode } from '../types';

export const getSystemTheme = (): 'dark' | 'light' => {
  if (typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }
  return 'light';
};

export const applyTheme = (theme: ThemeMode | 'luxury' | undefined) => {
  if (typeof document === 'undefined') return;

  const mode = theme === 'dark' || theme === 'light' || theme === 'system' ? theme : 'light';
  const effectiveTheme = mode === 'system' ? getSystemTheme() : mode;

  const root = document.documentElement;
  const body = document.body;

  if (effectiveTheme === 'dark') {
    root.classList.add('dark');
    body.classList.add('dark');
    // Update theme-color meta tag for mobile browsers and PWA
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', '#090d16');
    }
  } else {
    root.classList.remove('dark');
    body.classList.remove('dark');
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', '#f8f9fa');
    }
  }
};
