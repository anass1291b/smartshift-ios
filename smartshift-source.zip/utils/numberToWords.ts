/**
 * Utility to convert numbers to French words for Moroccan payroll bulletins.
 * Example: 3422.75 -> "Trois mille quatre cent vingt-deux Dirhams et soixante-quinze Centimes"
 */

const UNITS = ['', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf'];
const TEENS = ['dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
const TENS = ['', 'dix', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante', 'soixante-dix', 'quatre-vingts', 'quatre-vingt-dix'];

function convertUnder1000(n: number): string {
  if (n === 0) return '';
  
  let result = '';
  const hundreds = Math.floor(n / 100);
  const remainder = n % 100;

  if (hundreds > 0) {
    if (hundreds === 1) {
      result += 'cent ';
    } else {
      result += UNITS[hundreds] + ' cent ';
    }
  }

  if (remainder > 0) {
    if (remainder < 10) {
      result += UNITS[remainder];
    } else if (remainder < 20) {
      result += TEENS[remainder - 10];
    } else {
      const ten = Math.floor(remainder / 10);
      const unit = remainder % 10;
      
      if (ten === 7) {
        result += 'soixante-' + TEENS[unit];
      } else if (ten === 9) {
        result += 'quatre-vingt-' + TEENS[unit];
      } else {
        result += TENS[ten];
        if (unit > 0) {
          result += (unit === 1 && ten !== 8 ? ' et un' : '-' + UNITS[unit]);
        }
      }
    }
  }

  return result.trim();
}

export function numberToFrenchWords(amount: number): string {
  if (isNaN(amount) || amount === 0) return 'Zéro Dirham';

  const integerPart = Math.floor(Math.abs(amount));
  const decimalPart = Math.round((Math.abs(amount) - integerPart) * 100);

  let words = '';

  const millions = Math.floor(integerPart / 1000000);
  const thousands = Math.floor((integerPart % 1000000) / 1000);
  const remainder = integerPart % 1000;

  if (millions > 0) {
    words += convertUnder1000(millions) + (millions > 1 ? ' millions ' : ' million ');
  }

  if (thousands > 0) {
    if (thousands === 1) {
      words += 'mille ';
    } else {
      words += convertUnder1000(thousands) + ' mille ';
    }
  }

  if (remainder > 0) {
    words += convertUnder1000(remainder);
  }

  words = words.trim();
  if (!words) words = 'zéro';

  // Capitalize first letter
  words = words.charAt(0).toUpperCase() + words.slice(1);
  words += ' Dirhams';

  if (decimalPart > 0) {
    const decWords = convertUnder1000(decimalPart);
    words += ' et ' + decWords + ' Centimes';
  }

  return words;
}
