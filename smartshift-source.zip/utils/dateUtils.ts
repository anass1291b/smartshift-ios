
import { ShiftType, UserData } from '../types';
import { 
  MOROCCAN_HOLIDAYS, 
  MOROCCAN_FIXED_HOLIDAYS, 
  MOROCCAN_RELIGIOUS_HOLIDAYS, 
  HolidayEntry, 
  SHIFT_CONFIG 
} from '../constants';

/**
 * Formats a Date object or hour/minute numbers in Moroccan 13h industrial format (e.g., 13h00, 06h00, 14h30).
 */
export const formatTime13h = (dateOrHour: Date | number, minute: number = 0): string => {
  if (dateOrHour instanceof Date) {
    const h = String(dateOrHour.getHours()).padStart(2, '0');
    const m = String(dateOrHour.getMinutes()).padStart(2, '0');
    return `${h}h${m}`;
  }
  const h = String(Math.floor(dateOrHour)).padStart(2, '0');
  const m = String(Math.floor(minute)).padStart(2, '0');
  return `${h}h${m}`;
};

/**
 * Returns formatted 13h time interval for a shift (e.g. "06h00 - 14h00", "14h00 - 22h00", "22h00 - 06h00").
 */
export const formatShiftRange13h = (shift: ShiftType): string => {
  switch (shift) {
    case ShiftType.K1:
      return '06h00 - 14h00';
    case ShiftType.K2:
      return '14h00 - 22h00';
    case ShiftType.K3:
      return '22h00 - 06h00';
    case ShiftType.OFF:
    default:
      return 'OFF / Repos';
  }
};

/**
 * Calculates the shift for a given date based on a week-based rotation.
 */
export const getShiftForDate = (date: Date, userData: UserData): ShiftType => {
  const iso = formatDateISO(date);
  if (userData.shiftExceptions && userData.shiftExceptions[iso]) {
    return userData.shiftExceptions[iso];
  }

  const cycle = userData.shiftCycle;
  if (!cycle || cycle.length === 0) return ShiftType.OFF;
  
  // Find the Monday of the week containing the given date
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const dayOffset = d.getDay() === 0 ? 6 : d.getDay() - 1;
  const targetMonday = new Date(d);
  targetMonday.setDate(d.getDate() - dayOffset);
  targetMonday.setHours(0, 0, 0, 0);
  
  // Use a stable anchor Monday
  const anchorISO = userData.cycleAnchorMonday || '2026-07-06';
  const [ay, am, ad] = anchorISO.split('-').map(Number);
  const anchorMonday = new Date(ay, am - 1, ad);
  anchorMonday.setHours(0, 0, 0, 0);
  
  // Difference in weeks (using Math.round to handle DST cleanly)
  const diffWeeks = Math.round((targetMonday.getTime() - anchorMonday.getTime()) / (7 * 24 * 60 * 60 * 1000));
  
  const cycleLength = cycle.length;
  const startIndex = userData.currentWeekIndex || 0;
  // Use diffWeeks and startIndex to index into the cycle
  const rotationIndex = (((diffWeeks + startIndex) % cycleLength) + cycleLength) % cycleLength;
  const regularWeekShift = cycle[rotationIndex] || ShiftType.K1;

  // Sundays in Moroccan manufacturing context:
  // If the operator has marked this Sunday as worked / planned overtime (specialDaysWorked),
  // it runs on the regular week's shift (e.g. K1 or K2 or K3) unless an exception is specified.
  const dayOfWeek = date.getDay();
  if (dayOfWeek === 0) {
    if (userData.specialDaysWorked && userData.specialDaysWorked.includes(iso)) {
      return regularWeekShift;
    }
    return ShiftType.OFF;
  }

  return regularWeekShift;
};

export const getShiftDayForTime = (time: Date): string => {
  const effectiveDate = new Date(time);
  // Shifts starting at 22:00 belong to the day they started even after midnight
  if (time.getHours() < 6) {
    effectiveDate.setDate(effectiveDate.getDate() - 1);
  }
  return formatDateISO(effectiveDate);
};

export const getHolidayEntry = (date: Date): HolidayEntry | undefined => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  const fullIso = `${y}-${m}-${d}`;
  const monthDay = `${m}-${d}`;

  // 1. Check religious holidays first (year-specific like Mawlid An-Nabawi, Aid Al-Fitr, Aid Al-Adha)
  if (MOROCCAN_RELIGIOUS_HOLIDAYS[fullIso]) {
    return MOROCCAN_RELIGIOUS_HOLIDAYS[fullIso];
  }

  // 2. Check fixed annual civil & national holidays
  if (MOROCCAN_FIXED_HOLIDAYS[monthDay]) {
    return MOROCCAN_FIXED_HOLIDAYS[monthDay];
  }

  return undefined;
};

export const getHolidayName = (date: Date, lang: 'ar' | 'fr' | 'en' = 'fr'): string | undefined => {
  const entry = getHolidayEntry(date);
  if (!entry) return undefined;
  return entry[lang] || entry.fr || entry.en;
};

export const isReligiousHoliday = (date: Date): boolean => {
  const entry = getHolidayEntry(date);
  return !!entry?.isReligious;
};

export const formatDateISO = (date: Date) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

export const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();

/**
 * Returns ISO date of current week's Monday (YYYY-MM-DD)
 */
export const getCurrentMondayISO = (baseDate: Date = new Date()): string => {
  const d = new Date(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate());
  const dayOffset = d.getDay() === 0 ? 6 : d.getDay() - 1;
  d.setDate(d.getDate() - dayOffset);
  return formatDateISO(d);
};

/**
 * Calculates the exact shift rotation cycle based on shift mode and chosen current shift:
 * - 2-shift mode (2x8): K1 <-> K2 alternation
 * - 3-shift mode (3x8): strict sequence K1 -> K3 -> K2 -> K1 -> K3 -> K2...
 */
export const computeShiftCycle = (
  mode: '2shifts' | '3shifts',
  currentShift: ShiftType
): ShiftType[] => {
  if (mode === '2shifts') {
    if (currentShift === ShiftType.K2) {
      return [ShiftType.K2, ShiftType.K1];
    }
    return [ShiftType.K1, ShiftType.K2];
  } else {
    // 3-shift mode: Yazaki sequence: K1 -> K3 -> K2
    if (currentShift === ShiftType.K3) {
      return [ShiftType.K3, ShiftType.K2, ShiftType.K1];
    } else if (currentShift === ShiftType.K2) {
      return [ShiftType.K2, ShiftType.K1, ShiftType.K3];
    }
    return [ShiftType.K1, ShiftType.K3, ShiftType.K2];
  }
};

