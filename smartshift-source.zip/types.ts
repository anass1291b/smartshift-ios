
export enum ShiftType {
  K1 = 'K1', // Morning: 06:00-14:00
  K2 = 'K2', // Afternoon: 14:00-22:00
  K3 = 'K3', // Night: 22:00-06:00
  OFF = 'OFF'
}

export type Language = 'en' | 'fr' | 'ar';
export type ThemeMode = 'light' | 'dark' | 'system';

export interface CustomBonus {
  id: string;
  label: string;
  type: 'percentage' | 'fixed';
  value: number;
}

export interface CustomDeduction {
  id: string;
  label: string;
  type: 'percentage' | 'fixed';
  value: number;
}

export interface UserData {
  onboarded: boolean;
  name: string;
  language: Language;
  salaryType: 'hourly' | 'fixed';
  baseSalary: number;
  hourlyRate: number;
  attendanceBonusValue: number;
  healthInsuranceType?: 'private' | 'amo';
  healthInsuranceRate?: number; // e.g. 0.018 for 1.8% private insurance
  shiftMode?: '2shifts' | '3shifts'; // '2shifts' (K1/K2) or '3shifts' (K1/K3/K2)
  currentShift?: ShiftType; // currently active shift this week (K1, K2, or K3)
  shiftCycle: ShiftType[];
  shiftExceptions: Record<string, ShiftType>; // ISO date -> ShiftType
  cycleAnchorMonday?: string;
  currentWeekIndex: number;
  specialDaysWorked: string[];
  holidaysWorked: string[];
  absences: string[];
  nextMonthDays: string[];
  customPercentageBonuses: CustomBonus[];
  customDeductions: CustomDeduction[];
  k3Rate: number;
  seniorityRate: number;
  overtimeRate: number;
  sundayRate: number;
  theme: ThemeMode | 'luxury';
  matricule?: string;
  cin?: string;
  cnssNumber?: string;
  plantSite?: string;
  department?: string;
  paymentMethod?: string;
}

export interface SalaryBreakdown {
  regularHours: number;
  regularPay: number;
  holidayBasePay: number;
  k3Hours: number;
  k3Bonus: number;
  sundayHours: number;
  sundayPay: number;
  sundayDaysCount: number;
  holidayWorkedBonus: number;
  holidayDaysCount: number;
  overtimeHours: number;
  overtimeBonus: number;
  seniorityBase: number;
  seniorityBonus: number;
  attendanceBonus: number;
  customBonusTotal: number;
  customDeductionTotal: number;
  grossTotal: number;
  cnssDeduction: number;
  amoDeduction: number; // kept for backwards-compatibility
  healthInsuranceDeduction: number;
  healthInsuranceRate: number;
  healthInsuranceLabel: string;
  netTotal: number;
  netSalary: number;
  projectedGrossTotal: number;
  projectedNetSalary: number;
  projectedHours: number;
}

export interface ShiftInfo {
  type: ShiftType;
  start: Date;
  end: Date;
  active: boolean;
  progress: number;
  nextShiftStart?: Date;
  nextShiftType?: ShiftType;
  nextShiftIsSunday?: boolean;
  nextShiftIsHoliday?: boolean;
  nextShiftHolidayName?: string;
  nextShiftDateStr?: string;
}

